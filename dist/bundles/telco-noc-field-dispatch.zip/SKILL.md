---
name: telco-noc-field-dispatch
description: "Suppresses downstream network alarm storms via parent-child topology graph correlation, validates technician climbing/safety certifications and van/depot spares prior to field dispatch, and classifies B2B enterprise provisioning order fallout by queue and MRC-at-risk. Use when routing or executing Telecom NOC & Field Network Dispatch workflows (noc-outage-topology-correlator, field-dispatch-spares-prep, b2b-order-fallout-resolver). Don't use for unrelated domains outside telco-noc-field-dispatch or automated external mutations without explicit user confirmation."
created_by: gemini-agent-plugins
---

# Telecom NOC & Field Network Dispatch (Department Bundle)

Suppresses downstream network alarm storms via parent-child topology graph correlation, validates technician climbing/safety certifications and van/depot spares prior to field dispatch, and classifies B2B enterprise provisioning order fallout by queue and MRC-at-risk.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `noc-outage-topology-correlator` | `references/workflows/noc-outage-topology-correlator.md` | `scripts/alarm_topology_correlator.py` | Traces upstream parent-child network graphs to suppress downstream alarm storms and roll up impacted subscribers and VIP circuits. |
| `field-dispatch-spares-prep` | `references/workflows/field-dispatch-spares-prep.md` | `scripts/dispatch_readiness_matcher.py` | Validates technician skills and non-expired safety certs as of dispatch date alongside depot/van spare kit stock before truck rolls. |
| `b2b-order-fallout-resolver` | `references/workflows/b2b-order-fallout-resolver.md` | `scripts/order_fallout_classifier.py` | Classifies stuck B2B DIA/MPLS/SIP orders into deterministic remediation queues and quantifies Monthly Recurring Charge (MRC) at risk. |

## Step 1 — Fetch Data via Live `/work` Connectors or Attached Files

Probe enabled Gemini Enterprise connectors first before falling back to user-attached exports:

- **Built-in Managed 1P Connectors:** `ServiceNow`, `BigQuery`, `Postgres`, `Google Drive`, `Google Sheets`, `Google Docs`.
- **Optional Customer BYO-MCP Servers:** `NMS Alarm Topology & Field Service Dispatch MCP server` (discover exposed tools via `remote_cli mcp <connector> list-tools`).
- **Fetch Guidance:** Fetch live network alarm graphs, technician safety certifications, depot spare inventory, and B2B provisioning fallout orders from ServiceNow, BigQuery, Postgres, or customer NMS/Dispatch MCP servers via remote_cli mcp before Python BFS and readiness checks.
- **Connected Docs & Attached File Fallback:** Fetch Google Docs (`includeTabsContent=true`), Google Sheets (`UNFORMATTED_VALUE`), Shared Drives (`supportsAllDrives=true`), and SharePoint/OneDrive workbooks (`@odata.nextLink`), or read chat-attached `.xlsx`, `.docx`, `.csv`, `.tsv`, `.json`, and `.jsonl` snapshots via `view_file` and `scripts/enterprise_io.py`.

## Step 2 — Inspect & Shape Custom Customer Fields in `pyrepl`

Customer exports and live connector responses often use custom tab names or column headers. Check the matching workflow guide from the Workflow Router Matrix above for canonical keys and inspect the real source shape in `pyrepl` before computing:

- **Inspect Real Headers & Shape:** Read attached files via `scripts/enterprise_io.py` (`read_xlsx_workbook`, `read_docx`, `read_csv_tsv`, `read_json_or_jsonl`) or inspect connector JSON keys directly in `pyrepl` so you see actual tab names, headers, and sample rows first.
- **Normalize in Python (`payload`):** Shape messy customer headers or nested JSON objects in 5-10 lines of Python into a canonical `payload` dict and call `analyze(payload, config=cfg_path)` (pass file paths directly when headers already match canonical names). Call `ask_question` only when two source columns remain genuinely ambiguous.

## Step 3 — Run Deterministic Python Engine in `pyrepl` (or CLI)

1. Read `references/config.json` using `view_file` and check `org_configured`.
2. When `org_configured` is `false`, apply the bundled starter rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`
3. Resolve `SKILL_DIR` dynamically under `/workspace/skills/` so both `pyrepl` and shell CLI invocations work regardless of install root, and enforce every bundled baseline (`references/baselines/itsm-sla-severity-baseline.md`, `references/baselines/finance-materiality-baseline.md`) and trap sheet (`references/traps/servicenow-jira-itsm-traps.md`, `references/traps/absent-is-not-zero.md`, `references/traps/untrusted-content-and-pii.md`, `references/traps/bigquery-sap-erp-traps.md`).

Bundled baseline rubrics:
- `references/baselines/itsm-sla-severity-baseline.md`
- `references/baselines/finance-materiality-baseline.md`

Bundled API and analytical trap guides:
- `references/traps/servicenow-jira-itsm-traps.md`
- `references/traps/absent-is-not-zero.md`
- `references/traps/untrusted-content-and-pii.md`
- `references/traps/bigquery-sap-erp-traps.md`

Using persistent `pyrepl`:

```python
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/telco-noc-field-dispatch"),
            Path("skills/user-skills/telco-noc-field-dispatch"),
            Path("skills/noc-outage-topology-correlator"),
            Path("skills/user-skills/noc-outage-topology-correlator"),
            Path("."),
        )
        if (p / "scripts/alarm_topology_correlator.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/alarm_topology_correlator.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.enterprise_io import read_xlsx_workbook, read_docx, read_csv_tsv, read_json_or_jsonl
from scripts.alarm_topology_correlator import analyze, render_markdown

cfg_path = SKILL_DIR / "references" / "config.json"

# If headers differ from canonical names, inspect in Python first and normalize:
# wb = read_xlsx_workbook(Path("customer_export.xlsx"))
# print({tab: (list(rows[0].keys()) if rows else []) for tab, rows in wb.items()})
# payload = { ...shape customer columns into canonical keys... }
payload = source_path_or_dict
result = analyze(payload, config=cfg_path)
print(render_markdown(result))
```

CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/telco-noc-field-dispatch skills/user-skills/telco-noc-field-dispatch skills/*; do
  [ -f "$d/scripts/alarm_topology_correlator.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/alarm_topology_correlator.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/dispatch_readiness_matcher.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/order_fallout_classifier.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/alarm_topology_correlator.py" --help
python3 "$SKILL_DIR/scripts/dispatch_readiness_matcher.py" --help
python3 "$SKILL_DIR/scripts/order_fallout_classifier.py" --help
```

## Step 4 — Write-Back Governance (`Auto-Guardian`) & Conversational Scheduling (`schedule_task`)

- **Read-Only & Local Draft Actions:** Connector reads via `remote_cli mcp`, file inspection via `view_file`, `pyrepl` scoring, interactive Canvas (`emit_a2ui`), and saving local deliverables via `write_to_file` run without mutating external systems.
- **Agent Gateway (`Auto-Guardian`) & Explicit User Confirmation:** External write-backs executed via authorized connectors are protected by Agent Gateway (`Auto-Guardian`) and require explicit user confirmation prior to execution:
  - Dispatching field truck rolls and reserving depot spares in customer Field Service MCP
  - Bulk-closing or linking correlated child alarms in ServiceNow / NMS MCP
- **Code-Enforced Python Guardrails (`scripts/*.py`):**
  - Visited-set BFS optical ring correlation preventing infinite topology loops while deduplicating downstream child alarms
  - Hard dispatch block whenever tower-climb/electrical safety certs are expired or required depot spares are unavailable
  - Revenue-weighted MRC escalation prioritization on aged B2B order fallout
- **Conversational Scheduling (`schedule_task`):** Only when the user asks to automate recurring monitoring, invoke `schedule_task(title="Hourly B2B Provisioning Fallout Watch", cron_expression="0 * * * *", time_zone="UTC", instruction="Run the hourly B2B provisioning fallout sweep via scripts/order_fallout_classifier.py and highlight P1 executive escalations where aged MRC breaches SLA.")`.
