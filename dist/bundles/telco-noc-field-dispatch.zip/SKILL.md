---
name: telco-noc-field-dispatch
description: "Suppresses downstream network alarm storms via parent-child topology graph correlation, validates technician climbing/safety certifications and van/depot spares prior to field dispatch, and classifies B2B enterprise provisioning order fallout by queue and MRC-at-risk. Use when routing or executing Telecom NOC & Field Network Dispatch workflows (noc-outage-topology-correlator, field-dispatch-spares-prep, b2b-order-fallout-resolver). Don't use for unrelated domains outside telco-noc-field-dispatch or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# Telecom NOC & Field Network Dispatch (Department Bundle)

Suppresses downstream network alarm storms via parent-child topology graph correlation, validates technician climbing/safety certifications and van/depot spares prior to field dispatch, and classifies B2B enterprise provisioning order fallout by queue and MRC-at-risk.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `noc-outage-topology-correlator` | [noc-outage-topology-correlator.md](references/workflows/noc-outage-topology-correlator.md) | [alarm_topology_correlator.py](scripts/alarm_topology_correlator.py) | Traces upstream parent-child network graphs to suppress downstream alarm storms and roll up impacted subscribers and VIP circuits. |
| `field-dispatch-spares-prep` | [field-dispatch-spares-prep.md](references/workflows/field-dispatch-spares-prep.md) | [dispatch_readiness_matcher.py](scripts/dispatch_readiness_matcher.py) | Validates technician skills and non-expired safety certs as of dispatch date alongside depot/van spare kit stock before truck rolls. |
| `b2b-order-fallout-resolver` | [b2b-order-fallout-resolver.md](references/workflows/b2b-order-fallout-resolver.md) | [order_fallout_classifier.py](scripts/order_fallout_classifier.py) | Classifies stuck B2B DIA/MPLS/SIP orders into deterministic remediation queues and quantifies Monthly Recurring Charge (MRC) at risk. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `noc_nms_fsm_and_oss` | servicenow_table_api, bigquery_sql_api | Google Sheets, Google Docs, Google Drive (Read Active NOC Alarm Export Sheets, Tech Certification Rosters, and B2B Order Fallout Sheets in Network Ops Drives.) | .json, .csv |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [itsm-sla-severity-baseline.md](references/baselines/itsm-sla-severity-baseline.md)
- [finance-materiality-baseline.md](references/baselines/finance-materiality-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Inspect outputs and optionally visualize metrics with `emit_a2ui` or automate via `schedule_task`.

Using persistent `pyrepl`:

```python
import json
from scripts.alarm_topology_correlator import analyze
with open('references/config.json') as f:
    cfg = json.load(f)
# Pass loaded Mode A/B/C records in RAM without flooding context tokens
```

Using CLI fallback (`python3`):

```bash
python3 scripts/alarm_topology_correlator.py --help
python3 scripts/dispatch_readiness_matcher.py --help
python3 scripts/order_fallout_classifier.py --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [servicenow-jira-itsm-traps.md](references/traps/servicenow-jira-itsm-traps.md)
- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [untrusted-content-and-pii.md](references/traps/untrusted-content-and-pii.md)
- [bigquery-sap-erp-traps.md](references/traps/bigquery-sap-erp-traps.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `servicenow_read_em_alerts`, `fsm_read_tech_certs_and_spares`, `oss_read_b2b_fallout`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `servicenow_draft_parent_incident`, `docs_create_noc_sitrep`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `fsm_dispatch_truck_roll` (scope: `explicit_per_call`) — Dispatching field technicians and releasing depot spares requires Dispatch Coordinator HITL approval.
  - `servicenow_bulk_suppress_child_alerts` (scope: `explicit_per_call`) — Bulk-closing or linking NOC alerts requires Duty NOC Incident Commander sign-off.
