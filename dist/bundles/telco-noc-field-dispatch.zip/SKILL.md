---
name: telco-noc-field-dispatch
description: "Suppresses downstream network alarm storms via parent-child topology graph correlation, validates technician climbing/safety certifications and van/depot spares prior to field dispatch, and classifies B2B enterprise provisioning order fallout by queue and MRC-at-risk. Use when routing or executing Telecom NOC & Field Network Dispatch workflows (noc-outage-topology-correlator, field-dispatch-spares-prep, b2b-order-fallout-resolver). Don't use for unrelated domains outside telco-noc-field-dispatch or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# Telecom NOC & Field Network Dispatch (Department Bundle)

Suppresses downstream network alarm storms via parent-child topology graph correlation, validates technician climbing/safety certifications and van/depot spares prior to field dispatch, and classifies B2B enterprise provisioning order fallout by queue and MRC-at-risk.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `noc-outage-topology-correlator` | `references/workflows/noc-outage-topology-correlator.md` | `scripts/alarm_topology_correlator.py` | Traces upstream parent-child network graphs to suppress downstream alarm storms and roll up impacted subscribers and VIP circuits. |
| `field-dispatch-spares-prep` | `references/workflows/field-dispatch-spares-prep.md` | `scripts/dispatch_readiness_matcher.py` | Validates technician skills and non-expired safety certs as of dispatch date alongside depot/van spare kit stock before truck rolls. |
| `b2b-order-fallout-resolver` | `references/workflows/b2b-order-fallout-resolver.md` | `scripts/order_fallout_classifier.py` | Classifies stuck B2B DIA/MPLS/SIP orders into deterministic remediation queues and quantifies Monthly Recurring Charge (MRC) at risk. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `noc_nms_fsm_and_oss` | servicenow_table_api, bigquery_sql_api | Google Sheets, Google Docs, Google Drive (Read Active NOC Alarm Export Sheets, Tech Certification Rosters, and B2B Order Fallout Sheets in Network Ops Drives.) | .json, .csv |

## Org Configuration & Starter Baseline Rule

1. Read `references/config.json` using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- `references/baselines/itsm-sla-severity-baseline.md`
- `references/baselines/finance-materiality-baseline.md`

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Because runtime shells start in `/workspace` while bundles and individual skills unpack under `skills/<slug>/` or `skills/user-skills/<slug>/`, always resolve `SKILL_DIR` dynamically before importing scripts or reading references.

- **Zero-dependency enterprise ingestion:** Every engine uses `scripts/enterprise_io.py` to parse multi-tab `.xlsx`/`.xlsm` workbooks (1900/1904 dates, inline/shared strings, formula cached values), `.docx` documents (sections, headings, embedded tables, footnotes/comments), UTF-8 BOM `.csv`/`.tsv`, `.json`, and `.jsonl` directly from `--input` without needing `openpyxl` or `python-docx`. Pass `--sheet <TabNameOrIndex>` (or `sheet='...'` in `analyze()`) to analyze a specific worksheet by tab name or 0-based index.

Using persistent `pyrepl`:

```python
import json
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/telco-noc-field-dispatch"),
            Path("skills/user-skills/telco-noc-field-dispatch"),
            Path("skills/noc-outage-topology-correlator"),
            Path("skills/user-skills/noc-outage-topology-correlator"),
            Path("."),
        )
        if (p / "scripts/alarm_topology_correlator.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/alarm_topology_correlator.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.alarm_topology_correlator import analyze, render_markdown

cfg = json.loads((SKILL_DIR / "references" / "config.json").read_text(encoding="utf-8"))
# Pass loaded Mode A/B/C payload in RAM without flooding prompt tokens:
# result = analyze(payload, config=SKILL_DIR / "references" / "config.json")
# print(render_markdown(result))
```

Using CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/telco-noc-field-dispatch skills/user-skills/telco-noc-field-dispatch skills/*; do
  [ -f "$d/scripts/alarm_topology_correlator.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/alarm_topology_correlator.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/dispatch_readiness_matcher.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/order_fallout_classifier.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
# Or pass .xlsx / .docx / .csv directly (optional --sheet "TabName" or --sheet 0):
# python3 "$SKILL_DIR/scripts/alarm_topology_correlator.py" --input workbook.xlsx --config "$SKILL_DIR/references/config.json" --format markdown
# Inspect CLI flags directly:
python3 "$SKILL_DIR/scripts/alarm_topology_correlator.py" --help
python3 "$SKILL_DIR/scripts/dispatch_readiness_matcher.py" --help
python3 "$SKILL_DIR/scripts/order_fallout_classifier.py" --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- `references/traps/servicenow-jira-itsm-traps.md`
- `references/traps/absent-is-not-zero.md`
- `references/traps/untrusted-content-and-pii.md`
- `references/traps/bigquery-sap-erp-traps.md`

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `servicenow_read_em_alerts`, `fsm_read_tech_certs_and_spares`, `oss_read_b2b_fallout`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `servicenow_draft_parent_incident`, `docs_create_noc_sitrep`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `fsm_dispatch_truck_roll` (scope: `explicit_per_call`) — Dispatching field technicians and releasing depot spares requires Dispatch Coordinator HITL approval.
  - `servicenow_bulk_suppress_child_alerts` (scope: `explicit_per_call`) — Bulk-closing or linking NOC alerts requires Duty NOC Incident Commander sign-off.
