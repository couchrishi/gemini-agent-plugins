---
name: legal-contract-desk
description: "Redlines commercial NDAs, MSAs, and DPAs against 1/3/9 risk playbooks, calculates exact auto-renewal opt-out deadlines and escalator caps from executed contracts, and maps regulatory articles against internal control inventories. Use when routing or executing Legal Contract Desk & Regulatory Compliance workflows (contract-playbook-redliner, executed-obligation-extractor, regulatory-change-mapper). Don't use for unrelated domains outside legal-contract-desk or automated external mutations without explicit user confirmation."
created_by: gemini-agent-plugins
---

# Legal Contract Desk & Regulatory Compliance (Department Bundle)

Redlines commercial NDAs, MSAs, and DPAs against 1/3/9 risk playbooks, calculates exact auto-renewal opt-out deadlines and escalator caps from executed contracts, and maps regulatory articles against internal control inventories.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `contract-playbook-redliner` | `references/workflows/contract-playbook-redliner.md` | `scripts/clause_risk_matrix.py` | Scores commercial contract clauses on a 1/3/9 risk scale against playbook rules, flags walk-away blockers, and generates fallback redlines. |
| `executed-obligation-extractor` | `references/workflows/executed-obligation-extractor.md` | `scripts/obligation_calendar_builder.py` | Calculates exact notice deadlines prior to auto-renewal, flags CPI escalator breaches, and builds executed obligation calendars. |
| `regulatory-change-mapper` | `references/workflows/regulatory-change-mapper.md` | `scripts/control_gap_mapper.py` | Maps regulatory articles against internal controls to detect uncovered mandates, stale test evidence, and prioritized remediation queues. |

## Step 1 — Fetch Data via Live `/work` Connectors or Attached Files

Probe enabled Gemini Enterprise connectors first before falling back to user-attached exports:

- **Built-in Managed 1P Connectors:** `Google Drive`, `Google Docs`, `Google Sheets`, `Microsoft 365 (SharePoint, OneDrive, Outlook, Teams)`, `Box`, `ServiceNow`, `Gmail`.
- **Connector Tool Discovery:** Query enabled 1P/MCP servers via `remote_cli mcp <connector> list-tools` before calling Python engines.
- **Fetch Guidance:** Fetch counterparty MSAs/DPAs, multi-tab Google Docs playbooks, executed contract registers, and GRC regulatory control sheets from Drive, SharePoint, Box, or ServiceNow via remote_cli mcp before running Python clause and obligation engines.
- **Connected Docs & Attached File Fallback:** Fetch Google Docs (`includeTabsContent=true`), Google Sheets (`UNFORMATTED_VALUE`), Shared Drives (`supportsAllDrives=true`), and SharePoint/OneDrive workbooks (`@odata.nextLink`), or read chat-attached `.xlsx`, `.docx`, `.csv`, `.tsv`, `.json`, and `.jsonl` snapshots via `view_file` and `scripts/enterprise_io.py`.

## Step 2 — Inspect & Shape Custom Customer Fields in `pyrepl`

Customer exports and live connector responses often use custom tab names or column headers. Check the matching workflow guide from the Workflow Router Matrix above for canonical keys and inspect the real source shape in `pyrepl` before computing:

- **Inspect Real Headers & Shape:** Read attached files via `scripts/enterprise_io.py` (`read_xlsx_workbook`, `read_docx`, `read_csv_tsv`, `read_json_or_jsonl`) or inspect connector JSON keys directly in `pyrepl` so you see actual tab names, headers, and sample rows first.
- **Normalize in Python (`payload`):** Shape messy customer headers or nested JSON objects in 5-10 lines of Python into a canonical `payload` dict and call `analyze(payload, config=cfg_path)` (pass file paths directly when headers already match canonical names). Call `ask_question` only when two source columns remain genuinely ambiguous.

## Step 3 — Run Deterministic Python Engine in `pyrepl` (or CLI)

1. Read `references/config.json` using `view_file` and check `org_configured`.
2. When `org_configured` is `false`, apply the bundled starter rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`
3. Resolve `SKILL_DIR` dynamically under `/workspace/skills/` so both `pyrepl` and shell CLI invocations work regardless of install root, and enforce every bundled baseline (`references/baselines/commercial-contract-baseline.md`) and trap sheet (`references/traps/absent-is-not-zero.md`, `references/traps/google-workspace-traps.md`, `references/traps/sharepoint-onedrive-kql-traps.md`, `references/traps/untrusted-content-and-pii.md`).

Bundled baseline rubrics:
- `references/baselines/commercial-contract-baseline.md`

Bundled API and analytical trap guides:
- `references/traps/absent-is-not-zero.md`
- `references/traps/google-workspace-traps.md`
- `references/traps/sharepoint-onedrive-kql-traps.md`
- `references/traps/untrusted-content-and-pii.md`

Using persistent `pyrepl`:

```python
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/legal-contract-desk"),
            Path("skills/user-skills/legal-contract-desk"),
            Path("skills/contract-playbook-redliner"),
            Path("skills/user-skills/contract-playbook-redliner"),
            Path("."),
        )
        if (p / "scripts/clause_risk_matrix.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/clause_risk_matrix.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.enterprise_io import read_xlsx_workbook, read_docx, read_csv_tsv, read_json_or_jsonl
from scripts.clause_risk_matrix import analyze, render_markdown

cfg_path = SKILL_DIR / "references" / "config.json"

# If headers differ from canonical names, inspect in Python first and normalize:
# wb = read_xlsx_workbook(Path("customer_export.xlsx"))
# print({tab: (list(rows[0].keys()) if rows else []) for tab, rows in wb.items()})
# payload = { ...shape customer columns into canonical keys... }
payload = source_path_or_dict
result = analyze(payload, config=cfg_path)
print(render_markdown(result))
```

CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/legal-contract-desk skills/user-skills/legal-contract-desk skills/*; do
  [ -f "$d/scripts/clause_risk_matrix.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/clause_risk_matrix.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/obligation_calendar_builder.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/control_gap_mapper.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/clause_risk_matrix.py" --help
python3 "$SKILL_DIR/scripts/obligation_calendar_builder.py" --help
python3 "$SKILL_DIR/scripts/control_gap_mapper.py" --help
```

## Step 4 — Write-Back Governance (`Auto-Guardian`) & Conversational Scheduling (`schedule_task`)

- **Read-Only & Local Draft Actions:** Connector reads via `remote_cli mcp`, file inspection via `view_file`, `pyrepl` scoring, interactive Canvas (`emit_a2ui`), and saving local deliverables via `write_to_file` run without mutating external systems.
- **Agent Gateway (`Auto-Guardian`) & Explicit User Confirmation:** External write-backs executed via authorized connectors are protected by Agent Gateway (`Auto-Guardian`) and require explicit user confirmation prior to execution:
  - Sending redlined contract drafts or counter-proposals to external counterparty counsel via Gmail/Outlook
  - Updating GRC compliance control statuses or legal approval records in ServiceNow
- **Code-Enforced Python Guardrails (`scripts/*.py`):**
  - Unilateral Score 9 walk-away blocker detection (AI training carve-outs, uncapped liability, shortened breach notice)
  - Indirect prompt-injection directive quarantine inside contract footnotes and exhibits
  - Deterministic opt-out notice deadline calculation (renewal_date - notice_days) and uncapped CPI escalation flags
- **Conversational Scheduling (`schedule_task`):** Only when the user asks to automate recurring monitoring, invoke `schedule_task(title="Weekly Renewal & Notice Deadline Watch", cron_expression="0 8 * * 1", time_zone="UTC", instruction="Run the weekly executed contract renewal and obligation watch via scripts/obligation_calendar_builder.py. Compute exact opt-out notice deadlines (`renewal_date - notice_days`), surface urgent <=30 day windows and uncapped CPI escalators, and generate a draft reminder pack without emailing counterparties.")`.
