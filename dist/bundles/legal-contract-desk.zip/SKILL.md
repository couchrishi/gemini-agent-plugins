---
name: legal-contract-desk
description: "Redlines commercial NDAs, MSAs, and DPAs against 1/3/9 risk playbooks, calculates exact auto-renewal opt-out deadlines and escalator caps from executed contracts, and maps regulatory articles against internal control inventories. Use when routing or executing Legal Contract Desk & Regulatory Compliance workflows (contract-playbook-redliner, executed-obligation-extractor, regulatory-change-mapper). Don't use for unrelated domains outside legal-contract-desk or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# Legal Contract Desk & Regulatory Compliance (Department Bundle)

Redlines commercial NDAs, MSAs, and DPAs against 1/3/9 risk playbooks, calculates exact auto-renewal opt-out deadlines and escalator caps from executed contracts, and maps regulatory articles against internal control inventories.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `contract-playbook-redliner` | [contract-playbook-redliner.md](references/workflows/contract-playbook-redliner.md) | [clause_risk_matrix.py](scripts/clause_risk_matrix.py) | Scores commercial contract clauses on a 1/3/9 risk scale against playbook rules, flags walk-away blockers, and generates fallback redlines. |
| `executed-obligation-extractor` | [executed-obligation-extractor.md](references/workflows/executed-obligation-extractor.md) | [obligation_calendar_builder.py](scripts/obligation_calendar_builder.py) | Calculates exact notice deadlines prior to auto-renewal, flags CPI escalator breaches, and builds executed obligation calendars. |
| `regulatory-change-mapper` | [regulatory-change-mapper.md](references/workflows/regulatory-change-mapper.md) | [control_gap_mapper.py](scripts/control_gap_mapper.py) | Maps regulatory articles against internal controls to detect uncovered mandates, stale test evidence, and prioritized remediation queues. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `clm_and_contract_repository` | google_drive_api, microsoft_graph_sharepoint | Google Docs, Google Sheets, Google Drive (Inspect Legal Playbook Docs (all child tabs) and Executed Contract Registry Sheets in Legal Shared Drives.) | .json, .csv, .md, .txt |
| `compliance_control_register` | servicenow_grc_api | Google Sheets, Google Drive (Read Control Register & Audit Evidence Sheets in Compliance Shared Drives.) | .json, .csv |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [commercial-contract-baseline.md](references/baselines/commercial-contract-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Inspect outputs and optionally visualize metrics with `emit_a2ui` or automate via `schedule_task`.

Using persistent `pyrepl`:

```python
import json
from scripts.clause_risk_matrix import analyze
with open('references/config.json') as f:
    cfg = json.load(f)
# Pass loaded Mode A/B/C records in RAM without flooding context tokens
```

Using CLI fallback (`python3`):

```bash
python3 scripts/clause_risk_matrix.py --help
python3 scripts/obligation_calendar_builder.py --help
python3 scripts/control_gap_mapper.py --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [google-workspace-traps.md](references/traps/google-workspace-traps.md)
- [sharepoint-onedrive-kql-traps.md](references/traps/sharepoint-onedrive-kql-traps.md)
- [untrusted-content-and-pii.md](references/traps/untrusted-content-and-pii.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `drive_read_contract`, `docs_read_tabs`, `sharepoint_read_library`, `servicenow_grc_read`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `docs_create_redline_memo_draft`, `calendar_create_private_reminder`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `clm_send_external_redline` (scope: `explicit_per_call`) — Transmitting contract redlines to external counterparties requires Legal counsel approval.
  - `clm_execute_or_approve_contract` (scope: `explicit_per_call`) — Executing or signing legal agreements always requires explicit human sign-off.
  - `grc_update_control_status` (scope: `task_sticky`) — Modifying compliance control register mappings requires Compliance Officer confirmation.
