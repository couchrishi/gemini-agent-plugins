---
name: retail-store-merchandising
description: "Ranks store shrink loss and phantom inventory (zero-scan anomalies) while skipping unpolled POS stores, attributes promotional unit/margin lift net of cannibalization and basket halo, and audits supplier OTIF scorecards, chargebacks, and carrier detention. Use when routing or executing Retail & CPG Store Ops + Merchandising workflows (store-ops-shrink-copilot, merchandising-assortment-planner, supplier-otif-chargeback-auditor). Don't use for unrelated domains outside retail-store-merchandising or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# Retail & CPG Store Ops + Merchandising (Department Bundle)

Ranks store shrink loss and phantom inventory (zero-scan anomalies) while skipping unpolled POS stores, attributes promotional unit/margin lift net of cannibalization and basket halo, and audits supplier OTIF scorecards, chargebacks, and carrier detention.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `store-ops-shrink-copilot` | [store-ops-shrink-copilot.md](references/workflows/store-ops-shrink-copilot.md) | [store_shrink_task_ranker.py](scripts/store_shrink_task_ranker.py) | Ranks store physical shrink loss $, detects zero-scan phantom inventory cleanly, and prioritizes store floor cycle counts. |
| `merchandising-assortment-planner` | [merchandising-assortment-planner.md](references/workflows/merchandising-assortment-planner.md) | [promo_lift_analyzer.py](scripts/promo_lift_analyzer.py) | Normalizes baseline vs promo durations, deducts sibling cannibalization, adds basket halo, and computes net promo margin ROI. |
| `supplier-otif-chargeback-auditor` | [supplier-otif-chargeback-auditor.md](references/workflows/supplier-otif-chargeback-auditor.md) | [otif_detention_calculator.py](scripts/otif_detention_calculator.py) | Scores PO On-Time and In-Full compliance, honors weather/buyer exclusions, and computes vendor chargebacks vs detention fees. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `retail_pos_wms_and_erp` | bigquery_sql_api, sap_odata_api | Google Sheets, Google Docs, Google Drive (Read Store Shrink Cycle-Count Sheets (`UNFORMATTED_VALUE`), Promo Recap Decks/Sheets, and DC Receiving Logs in Retail Ops Drives.) | .json, .csv |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [finance-materiality-baseline.md](references/baselines/finance-materiality-baseline.md)
- [itsm-sla-severity-baseline.md](references/baselines/itsm-sla-severity-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Because runtime shells start in `/workspace` while bundles and individual skills unpack under `skills/<slug>/` or `skills/user-skills/<slug>/`, always resolve `SKILL_DIR` dynamically before importing scripts or reading references.

- **Zero-dependency enterprise ingestion:** Every engine uses [enterprise_io.py](scripts/enterprise_io.py) to parse multi-tab `.xlsx`/`.xlsm` workbooks (1900/1904 dates, inline/shared strings, formula cached values), `.docx` documents (sections, headings, embedded tables, footnotes/comments), UTF-8 BOM `.csv`/`.tsv`, `.json`, and `.jsonl` directly from `--input` without needing `openpyxl` or `python-docx`. Pass `--sheet <TabNameOrIndex>` (or `sheet='...'` in `analyze()`) to analyze a specific worksheet by tab name or 0-based index.

Using persistent `pyrepl`:

```python
import json
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/retail-store-merchandising"),
            Path("skills/user-skills/retail-store-merchandising"),
            Path("skills/store-ops-shrink-copilot"),
            Path("skills/user-skills/store-ops-shrink-copilot"),
            Path("."),
        )
        if (p / "scripts/store_shrink_task_ranker.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/store_shrink_task_ranker.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.store_shrink_task_ranker import analyze, render_markdown

cfg = json.loads((SKILL_DIR / "references" / "config.json").read_text(encoding="utf-8"))
# Pass loaded Mode A/B/C payload in RAM without flooding prompt tokens:
# result = analyze(payload, config=SKILL_DIR / "references" / "config.json")
# print(render_markdown(result))
```

Using CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/retail-store-merchandising skills/user-skills/retail-store-merchandising skills/*; do
  [ -f "$d/scripts/store_shrink_task_ranker.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/store_shrink_task_ranker.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/promo_lift_analyzer.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/otif_detention_calculator.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
# Or pass .xlsx / .docx / .csv directly (optional --sheet "TabName" or --sheet 0):
# python3 "$SKILL_DIR/scripts/store_shrink_task_ranker.py" --input workbook.xlsx --config "$SKILL_DIR/references/config.json" --format markdown
# Inspect CLI flags directly:
python3 "$SKILL_DIR/scripts/store_shrink_task_ranker.py" --help
python3 "$SKILL_DIR/scripts/promo_lift_analyzer.py" --help
python3 "$SKILL_DIR/scripts/otif_detention_calculator.py" --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [chain-denominator-seams.md](references/traps/chain-denominator-seams.md)
- [bigquery-sap-erp-traps.md](references/traps/bigquery-sap-erp-traps.md)
- [sharepoint-onedrive-kql-traps.md](references/traps/sharepoint-onedrive-kql-traps.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `bigquery_query_pos_inventory`, `sap_read_po_receipts`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `sheets_draft_store_task_list`, `docs_create_vendor_scorecard`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `erp_post_inventory_writeoff` (scope: `explicit_per_call`) — Posting perpetual inventory write-offs alters financial COGS and requires Store/Inventory Controller approval.
  - `ap_issue_vendor_chargeback_debit` (scope: `explicit_per_call`) — Issuing vendor OTIF debit memos requires Merchandising & Vendor Ops HITL sign-off.
