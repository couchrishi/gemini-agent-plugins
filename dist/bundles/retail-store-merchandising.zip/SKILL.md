---
name: retail-store-merchandising
description: "Ranks store shrink loss and phantom inventory (zero-scan anomalies) while skipping unpolled POS stores, attributes promotional unit/margin lift net of cannibalization and basket halo, and audits supplier OTIF scorecards, chargebacks, and carrier detention. Use when routing or executing Retail & CPG Store Ops + Merchandising workflows (store-ops-shrink-copilot, merchandising-assortment-planner, supplier-otif-chargeback-auditor). Don't use for unrelated domains outside retail-store-merchandising or automated external mutations without explicit user confirmation."
created_by: gemini-agent-plugins
---

# Retail & CPG Store Ops + Merchandising (Department Bundle)

Ranks store shrink loss and phantom inventory (zero-scan anomalies) while skipping unpolled POS stores, attributes promotional unit/margin lift net of cannibalization and basket halo, and audits supplier OTIF scorecards, chargebacks, and carrier detention.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `store-ops-shrink-copilot` | `references/workflows/store-ops-shrink-copilot.md` | `scripts/store_shrink_task_ranker.py` | Ranks store physical shrink loss $, detects zero-scan phantom inventory cleanly, and prioritizes store floor cycle counts. |
| `merchandising-assortment-planner` | `references/workflows/merchandising-assortment-planner.md` | `scripts/promo_lift_analyzer.py` | Normalizes baseline vs promo durations, deducts sibling cannibalization, adds basket halo, and computes net promo margin ROI. |
| `supplier-otif-chargeback-auditor` | `references/workflows/supplier-otif-chargeback-auditor.md` | `scripts/otif_detention_calculator.py` | Scores PO On-Time and In-Full compliance, honors weather/buyer exclusions, and computes vendor chargebacks vs detention fees. |

## Step 1 — Fetch Data via Live `/work` Connectors or Attached Files

Probe enabled Gemini Enterprise connectors first before falling back to user-attached exports:

- **Built-in Managed 1P Connectors:** `BigQuery`, `Snowflake`, `Google Drive`, `Google Sheets`, `Google Docs`.
- **Optional Customer BYO-MCP Servers:** `SAP Retail ERP & POS Store Telemetry MCP server` (discover exposed tools via `remote_cli mcp <connector> list-tools`).
- **Fetch Guidance:** Pull store perpetual inventory, POS terminal polling health, promo elasticity tables, and ASN/POD Dock timestamps from BigQuery/Snowflake or customer SAP Retail / POS MCP servers via remote_cli mcp before Python shrink and OTIF math.
- **Connected Docs & Attached File Fallback:** Fetch Google Docs (`includeTabsContent=true`), Google Sheets (`UNFORMATTED_VALUE`), Shared Drives (`supportsAllDrives=true`), and SharePoint/OneDrive workbooks (`@odata.nextLink`), or read chat-attached `.xlsx`, `.docx`, `.csv`, `.tsv`, `.json`, and `.jsonl` snapshots via `view_file` and `scripts/enterprise_io.py`.

## Step 2 — Inspect & Shape Custom Customer Fields in `pyrepl`

Customer exports and live connector responses often use custom tab names or column headers. Check the matching workflow guide from the Workflow Router Matrix above for canonical keys and inspect the real source shape in `pyrepl` before computing:

- **Inspect Real Headers & Shape:** Read attached files via `scripts/enterprise_io.py` (`read_xlsx_workbook`, `read_docx`, `read_csv_tsv`, `read_json_or_jsonl`) or inspect connector JSON keys directly in `pyrepl` so you see actual tab names, headers, and sample rows first.
- **Normalize in Python (`payload`):** Shape messy customer headers or nested JSON objects in 5-10 lines of Python into a canonical `payload` dict and call `analyze(payload, config=cfg_path)` (pass file paths directly when headers already match canonical names). Call `ask_question` only when two source columns remain genuinely ambiguous.

## Step 3 — Run Deterministic Python Engine in `pyrepl` (or CLI)

1. Read `references/config.json` using `view_file` and check `org_configured`.
2. When `org_configured` is `false`, apply the bundled starter rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`
3. Resolve `SKILL_DIR` dynamically under `/workspace/skills/` so both `pyrepl` and shell CLI invocations work regardless of install root, and enforce every bundled baseline (`references/baselines/finance-materiality-baseline.md`, `references/baselines/itsm-sla-severity-baseline.md`) and trap sheet (`references/traps/absent-is-not-zero.md`, `references/traps/chain-denominator-seams.md`, `references/traps/bigquery-sap-erp-traps.md`, `references/traps/sharepoint-onedrive-kql-traps.md`).

Bundled baseline rubrics:
- `references/baselines/finance-materiality-baseline.md`
- `references/baselines/itsm-sla-severity-baseline.md`

Bundled API and analytical trap guides:
- `references/traps/absent-is-not-zero.md`
- `references/traps/chain-denominator-seams.md`
- `references/traps/bigquery-sap-erp-traps.md`
- `references/traps/sharepoint-onedrive-kql-traps.md`

Using persistent `pyrepl`:

```python
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/retail-store-merchandising"),
            Path("skills/user-skills/retail-store-merchandising"),
            Path("skills/store-ops-shrink-copilot"),
            Path("skills/user-skills/store-ops-shrink-copilot"),
            Path("."),
        )
        if (p / "scripts/store_shrink_task_ranker.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/store_shrink_task_ranker.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.enterprise_io import read_xlsx_workbook, read_docx, read_csv_tsv, read_json_or_jsonl
from scripts.store_shrink_task_ranker import analyze, render_markdown

cfg_path = SKILL_DIR / "references" / "config.json"

# If headers differ from canonical names, inspect in Python first and normalize:
# wb = read_xlsx_workbook(Path("customer_export.xlsx"))
# print({tab: (list(rows[0].keys()) if rows else []) for tab, rows in wb.items()})
# payload = { ...shape customer columns into canonical keys... }
payload = source_path_or_dict
result = analyze(payload, config=cfg_path)
print(render_markdown(result))
```

CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/retail-store-merchandising skills/user-skills/retail-store-merchandising skills/*; do
  [ -f "$d/scripts/store_shrink_task_ranker.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/store_shrink_task_ranker.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/promo_lift_analyzer.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/otif_detention_calculator.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/store_shrink_task_ranker.py" --help
python3 "$SKILL_DIR/scripts/promo_lift_analyzer.py" --help
python3 "$SKILL_DIR/scripts/otif_detention_calculator.py" --help
```

## Step 4 — Write-Back Governance (`Auto-Guardian`) & Conversational Scheduling (`schedule_task`)

- **Read-Only & Local Draft Actions:** Connector reads via `remote_cli mcp`, file inspection via `view_file`, `pyrepl` scoring, interactive Canvas (`emit_a2ui`), and saving local deliverables via `write_to_file` run without mutating external systems.
- **Agent Gateway (`Auto-Guardian`) & Explicit User Confirmation:** External write-backs executed via authorized connectors are protected by Agent Gateway (`Auto-Guardian`) and require explicit user confirmation prior to execution:
  - Posting perpetual inventory shrink write-offs impacting store COGS via SAP Retail MCP
  - Issuing supplier OTIF chargeback or detention debit memos via ERP AP MCP
- **Code-Enforced Python Guardrails (`scripts/*.py`):**
  - Mandatory exclusion of unpolled POS stores (pos_poll_status == MISSING) before shrink/write-off attribution
  - Baseline-adjusted promo net margin ROI guard preventing margin-destructive promotions from passing on gross unit lift
  - Strict contractual OTIF window and dock-wait grace-minute detention math
- **Conversational Scheduling (`schedule_task`):** Only when the user asks to automate recurring monitoring, invoke `schedule_task(title="Daily Store Shrink & Zero-Scan Watch", cron_expression="30 6 * * *", time_zone="UTC", instruction="Run the morning store shrink and zero-scan phantom inventory sweep via scripts/store_shrink_task_ranker.py and produce prioritized cycle-count lists per store manager.")`.
