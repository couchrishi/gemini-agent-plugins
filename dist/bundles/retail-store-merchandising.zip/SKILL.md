---
name: retail-store-merchandising
description: "Ranks store shrink loss and phantom inventory (zero-scan anomalies) while skipping unpolled POS stores, attributes promotional unit/margin lift net of cannibalization and basket halo, and audits supplier OTIF scorecards, chargebacks, and carrier detention. Use when routing or executing Retail & CPG Store Ops + Merchandising workflows (store-ops-shrink-copilot, merchandising-assortment-planner, supplier-otif-chargeback-auditor). Don't use for unrelated domains outside retail-store-merchandising or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# Retail & CPG Store Ops + Merchandising (Department Bundle)

Ranks store shrink loss and phantom inventory (zero-scan anomalies) while skipping unpolled POS stores, attributes promotional unit/margin lift net of cannibalization and basket halo, and audits supplier OTIF scorecards, chargebacks, and carrier detention.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `store-ops-shrink-copilot` | [store-ops-shrink-copilot.md](references/workflows/store-ops-shrink-copilot.md) | [store_shrink_task_ranker.py](scripts/store_shrink_task_ranker.py) | Ranks store physical shrink loss $, detects zero-scan phantom inventory cleanly, and prioritizes store floor cycle counts. |
| `merchandising-assortment-planner` | [merchandising-assortment-planner.md](references/workflows/merchandising-assortment-planner.md) | [promo_lift_analyzer.py](scripts/promo_lift_analyzer.py) | Normalizes baseline vs promo durations, deducts sibling cannibalization, adds basket halo, and computes net promo margin ROI. |
| `supplier-otif-chargeback-auditor` | [supplier-otif-chargeback-auditor.md](references/workflows/supplier-otif-chargeback-auditor.md) | [otif_detention_calculator.py](scripts/otif_detention_calculator.py) | Scores PO On-Time and In-Full compliance, honors weather/buyer exclusions, and computes vendor chargebacks vs detention fees. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `retail_pos_wms_and_erp` | bigquery_sql_api, sap_odata_api | Google Sheets, Google Docs, Google Drive (Read Store Shrink Cycle-Count Sheets (`UNFORMATTED_VALUE`), Promo Recap Decks/Sheets, and DC Receiving Logs in Retail Ops Drives.) | .json, .csv |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [finance-materiality-baseline.md](references/baselines/finance-materiality-baseline.md)
- [itsm-sla-severity-baseline.md](references/baselines/itsm-sla-severity-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Inspect outputs and optionally visualize metrics with `emit_a2ui` or automate via `schedule_task`.

Using persistent `pyrepl`:

```python
import json
from scripts.store_shrink_task_ranker import analyze
with open('references/config.json') as f:
    cfg = json.load(f)
# Pass loaded Mode A/B/C records in RAM without flooding context tokens
```

Using CLI fallback (`python3`):

```bash
python3 scripts/store_shrink_task_ranker.py --help
python3 scripts/promo_lift_analyzer.py --help
python3 scripts/otif_detention_calculator.py --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [chain-denominator-seams.md](references/traps/chain-denominator-seams.md)
- [bigquery-sap-erp-traps.md](references/traps/bigquery-sap-erp-traps.md)
- [sharepoint-onedrive-kql-traps.md](references/traps/sharepoint-onedrive-kql-traps.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `bigquery_query_pos_inventory`, `sap_read_po_receipts`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `sheets_draft_store_task_list`, `docs_create_vendor_scorecard`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `erp_post_inventory_writeoff` (scope: `explicit_per_call`) — Posting perpetual inventory write-offs alters financial COGS and requires Store/Inventory Controller approval.
  - `ap_issue_vendor_chargeback_debit` (scope: `explicit_per_call`) — Issuing vendor OTIF debit memos requires Merchandising & Vendor Ops HITL sign-off.
