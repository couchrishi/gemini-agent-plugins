---
name: sdlc-modernization-sre
description: "Reverse-engineers legacy codebases into PRD traceability matrices, computes exact SLO error-budget burn and TTD/TTM/TTR postmortem timelines, and gates PR diffs for secrets, removed authz checks, and unsafe DB migrations. Use when routing or executing SDLC Modernization, Security PR & SRE Ops workflows (legacy-code-to-prd, sre-incident-postmortem, security-pr-readiness-gate). Don't use for unrelated domains outside sdlc-modernization-sre or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# SDLC Modernization, Security PR & SRE Ops (Department Bundle)

Reverse-engineers legacy codebases into PRD traceability matrices, computes exact SLO error-budget burn and TTD/TTM/TTR postmortem timelines, and gates PR diffs for secrets, removed authz checks, and unsafe DB migrations.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `legacy-code-to-prd` | [legacy-code-to-prd.md](references/workflows/legacy-code-to-prd.md) | [spec_traceability_matrix.py](scripts/spec_traceability_matrix.py) | Parses legacy code inventories for entrypoints, DB read/write couplings, complexity hotspots, and requirement-to-test traceability coverage. |
| `sre-incident-postmortem` | [sre-incident-postmortem.md](references/workflows/sre-incident-postmortem.md) | [slo_timeline_calculator.py](scripts/slo_timeline_calculator.py) | Computes error-budget burn rates, TTD/TTM/TTR intervals, availability impact, and postmortem action-item SLA compliance. |
| `security-pr-readiness-gate` | [security-pr-readiness-gate.md](references/workflows/security-pr-readiness-gate.md) | [diff_risk_inspector.py](scripts/diff_risk_inspector.py) | Scans unified PR diffs and dependency manifests for hardcoded secrets, removed authz checks, unsafe migrations, and breaking API changes. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `source_code_and_pr_diffs` | github_rest_api, gitlab_api | Google Drive, Google Docs, Google Sheets (Read exported Architecture Inventory Sheets, Postmortem Docs, and Diff Attachments in Engineering Shared Drives.) | .json, .diff, .csv, .md, .txt |
| `monitoring_and_incident_timeline` | cloud_logging_api, jira_api | Google Docs, Google Sheets (Locate Incident Postmortem Docs and Action Tracker Sheets in SRE Shared Drives.) | .json, .csv, .md |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [itsm-sla-severity-baseline.md](references/baselines/itsm-sla-severity-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Inspect outputs and optionally visualize metrics with `emit_a2ui` or automate via `schedule_task`.

Using persistent `pyrepl`:

```python
import json
from scripts.spec_traceability_matrix import analyze
with open('references/config.json') as f:
    cfg = json.load(f)
# Pass loaded Mode A/B/C records in RAM without flooding context tokens
```

Using CLI fallback (`python3`):

```bash
python3 scripts/spec_traceability_matrix.py --help
python3 scripts/slo_timeline_calculator.py --help
python3 scripts/diff_risk_inspector.py --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [servicenow-jira-itsm-traps.md](references/traps/servicenow-jira-itsm-traps.md)
- [untrusted-content-and-pii.md](references/traps/untrusted-content-and-pii.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `github_read_pr_diff`, `gitlab_read_mr_diff`, `cloud_logging_query`, `jira_jql_search`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `docs_create_postmortem_draft`, `docs_create_prd_draft`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `github_merge_or_approve_pr` (scope: `explicit_per_call`) — Merging PRs or submitting code approvals requires explicit engineer confirmation.
  - `jira_bulk_create_remediation_tickets` (scope: `task_sticky`) — Creating postmortem remediation tickets in Jira requires owner approval.
  - `database_apply_migration` (scope: `explicit_per_call`) — Applying schema migrations in production or staging requires explicit DBA/SRE approval.
