---
name: sdlc-modernization-sre
description: "Reverse-engineers legacy codebases into PRD traceability matrices, computes exact SLO error-budget burn and TTD/TTM/TTR postmortem timelines, and gates PR diffs for secrets, removed authz checks, and unsafe DB migrations. Use when routing or executing SDLC Modernization, Security PR & SRE Ops workflows (legacy-code-to-prd, sre-incident-postmortem, security-pr-readiness-gate). Don't use for unrelated domains outside sdlc-modernization-sre or automated external mutations without explicit user confirmation."
created_by: gemini-agent-plugins
---

# SDLC Modernization, Security PR & SRE Ops (Department Bundle)

Reverse-engineers legacy codebases into PRD traceability matrices, computes exact SLO error-budget burn and TTD/TTM/TTR postmortem timelines, and gates PR diffs for secrets, removed authz checks, and unsafe DB migrations.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `legacy-code-to-prd` | `references/workflows/legacy-code-to-prd.md` | `scripts/spec_traceability_matrix.py` | Parses legacy code inventories for entrypoints, DB read/write couplings, complexity hotspots, and requirement-to-test traceability coverage. |
| `sre-incident-postmortem` | `references/workflows/sre-incident-postmortem.md` | `scripts/slo_timeline_calculator.py` | Computes error-budget burn rates, TTD/TTM/TTR intervals, availability impact, and postmortem action-item SLA compliance. |
| `security-pr-readiness-gate` | `references/workflows/security-pr-readiness-gate.md` | `scripts/diff_risk_inspector.py` | Scans unified PR diffs and dependency manifests for hardcoded secrets, removed authz checks, unsafe migrations, and breaking API changes. |

## Step 1 — Fetch Data via Live `/work` Connectors or Attached Files

Probe enabled Gemini Enterprise connectors first before falling back to user-attached exports:

- **Built-in Managed 1P Connectors:** `GitHub`, `Jira`, `Confluence`, `BigQuery`, `Google Drive`, `Google Docs`, `Google Sheets`, `Slack`.
- **Connector Tool Discovery:** Query enabled 1P/MCP servers via `remote_cli mcp <connector> list-tools` before calling Python engines.
- **Fetch Guidance:** Pull PR diffs, CI test manifests, incident timeline logs, and Jira postmortem action queues from GitHub, Jira, Confluence, and BigQuery via remote_cli mcp before running Python traceability, SLO interval, and diff-risk checks.
- **Connected Docs & Attached File Fallback:** Fetch Google Docs (`includeTabsContent=true`), Google Sheets (`UNFORMATTED_VALUE`), Shared Drives (`supportsAllDrives=true`), and SharePoint/OneDrive workbooks (`@odata.nextLink`), or read chat-attached `.xlsx`, `.docx`, `.csv`, `.tsv`, `.json`, and `.jsonl` snapshots via `view_file` and `scripts/enterprise_io.py`.

## Step 2 — Inspect & Shape Custom Customer Fields in `pyrepl`

Customer exports and live connector responses often use custom tab names or column headers. Check the matching workflow guide from the Workflow Router Matrix above for canonical keys and inspect the real source shape in `pyrepl` before computing:

- **Inspect Real Headers & Shape:** Read attached files via `scripts/enterprise_io.py` (`read_xlsx_workbook`, `read_docx`, `read_csv_tsv`, `read_json_or_jsonl`) or inspect connector JSON keys directly in `pyrepl` so you see actual tab names, headers, and sample rows first.
- **Normalize in Python (`payload`):** Shape messy customer headers or nested JSON objects in 5-10 lines of Python into a canonical `payload` dict and call `analyze(payload, config=cfg_path)` (pass file paths directly when headers already match canonical names). Call `ask_question` only when two source columns remain genuinely ambiguous.

## Step 3 — Run Deterministic Python Engine in `pyrepl` (or CLI)

1. Read `references/config.json` using `view_file` and check `org_configured`.
2. When `org_configured` is `false`, apply the bundled starter rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`
3. Resolve `SKILL_DIR` dynamically under `/workspace/skills/` so both `pyrepl` and shell CLI invocations work regardless of install root, and enforce every bundled baseline (`references/baselines/itsm-sla-severity-baseline.md`) and trap sheet (`references/traps/absent-is-not-zero.md`, `references/traps/servicenow-jira-itsm-traps.md`, `references/traps/untrusted-content-and-pii.md`).

Bundled baseline rubrics:
- `references/baselines/itsm-sla-severity-baseline.md`

Bundled API and analytical trap guides:
- `references/traps/absent-is-not-zero.md`
- `references/traps/servicenow-jira-itsm-traps.md`
- `references/traps/untrusted-content-and-pii.md`

Using persistent `pyrepl`:

```python
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/sdlc-modernization-sre"),
            Path("skills/user-skills/sdlc-modernization-sre"),
            Path("skills/legacy-code-to-prd"),
            Path("skills/user-skills/legacy-code-to-prd"),
            Path("."),
        )
        if (p / "scripts/spec_traceability_matrix.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/spec_traceability_matrix.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.enterprise_io import read_xlsx_workbook, read_docx, read_csv_tsv, read_json_or_jsonl
from scripts.spec_traceability_matrix import analyze, render_markdown

cfg_path = SKILL_DIR / "references" / "config.json"

# If headers differ from canonical names, inspect in Python first and normalize:
# wb = read_xlsx_workbook(Path("customer_export.xlsx"))
# print({tab: (list(rows[0].keys()) if rows else []) for tab, rows in wb.items()})
# payload = { ...shape customer columns into canonical keys... }
payload = source_path_or_dict
result = analyze(payload, config=cfg_path)
print(render_markdown(result))
```

CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/sdlc-modernization-sre skills/user-skills/sdlc-modernization-sre skills/*; do
  [ -f "$d/scripts/spec_traceability_matrix.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/spec_traceability_matrix.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/slo_timeline_calculator.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/diff_risk_inspector.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/spec_traceability_matrix.py" --help
python3 "$SKILL_DIR/scripts/slo_timeline_calculator.py" --help
python3 "$SKILL_DIR/scripts/diff_risk_inspector.py" --help
```

## Step 4 — Write-Back Governance (`Auto-Guardian`) & Conversational Scheduling (`schedule_task`)

- **Read-Only & Local Draft Actions:** Connector reads via `remote_cli mcp`, file inspection via `view_file`, `pyrepl` scoring, interactive Canvas (`emit_a2ui`), and saving local deliverables via `write_to_file` run without mutating external systems.
- **Agent Gateway (`Auto-Guardian`) & Explicit User Confirmation:** External write-backs executed via authorized connectors are protected by Agent Gateway (`Auto-Guardian`) and require explicit user confirmation prior to execution:
  - Submitting GitHub PR reviews, merge approvals, or protected-branch status updates
  - Bulk-creating or updating Jira postmortem remediation tickets and owners
  - Executing or scheduling database DDL/schema migrations flagged as blocking
- **Code-Enforced Python Guardrails (`scripts/*.py`):**
  - Hardcoded secret, removed auth decorator, and unsafe/blocking DDL migration merge blocker
  - Outage interval union-merge deduplication preventing overlapping windows from overstating TTR/SLO burn
  - Strict legacy requirement-to-test traceability matrix coverage check
- **Conversational Scheduling (`schedule_task`):** Only when the user asks to automate recurring monitoring, invoke `schedule_task(title="Weekly SRE SLO & Postmortem Review", cron_expression="0 9 * * 1", time_zone="UTC", instruction="Run the weekly SRE reliability and postmortem action-item SLA audit via scripts/slo_timeline_calculator.py. Compute 30-day error-budget consumption across P1/P2 incidents, report TTD/TTM/TTR trends, and flag overdue postmortem corrective actions without mutating Jira issues autonomously.")`.
