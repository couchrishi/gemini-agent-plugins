---
name: fsi-credit-kyc-claims
description: "Calculates commercial borrower DSCR, net leverage, and interest coverage under multi-shock stress scenarios, resolves multi-hop UBO beneficial ownership with AML velocity/structuring checks, and evaluates insurance claims deterministically. Use when routing or executing Financial Services Credit, KYB/AML & Claims Underwriting workflows (commercial-credit-memo-analyst, kyc-aml-screening-dossier, insurance-claims-triage-pack). Don't use for unrelated domains outside fsi-credit-kyc-claims or automated external mutations without explicit user confirmation."
created_by: gemini-agent-plugins
---

# Financial Services Credit, KYB/AML & Claims Underwriting (Department Bundle)

Calculates commercial borrower DSCR, net leverage, and interest coverage under multi-shock stress scenarios, resolves multi-hop UBO beneficial ownership with AML velocity/structuring checks, and evaluates insurance claims deterministically.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `commercial-credit-memo-analyst` | `references/workflows/commercial-credit-memo-analyst.md` | `scripts/credit_covenant_stress.py` | Calculates DSCR, Net Leverage, Interest Coverage, and Current Ratio across Base, -10%/-20% revenue, and +200bps rate shocks. |
| `kyc-aml-screening-dossier` | `references/workflows/kyc-aml-screening-dossier.md` | `scripts/ubo_velocity_screener.py` | Traverses multi-hop holding DAGs to compute cumulative UBO ownership %, enforces 10% EDD drop, and detects velocity/structuring spikes. |
| `insurance-claims-triage-pack` | `references/workflows/insurance-claims-triage-pack.md` | `scripts/coverage_limit_evaluator.py` | Validates policy effective periods and peril exclusions, computes deductible/coinsurance/sublimit payouts, and flags >$100k reserves. |

## Step 1 — Fetch Data via Live `/work` Connectors or Attached Files

Probe enabled Gemini Enterprise connectors first before falling back to user-attached exports:

- **Built-in Managed 1P Connectors:** `BigQuery`, `Snowflake`, `Google Drive`, `Google Docs`, `Google Sheets`, `Gmail`.
- **Optional Customer BYO-MCP Servers:** `KYB / Sanctions Screening & Core Banking / Claims Clearinghouse MCP server` (discover exposed tools via `remote_cli mcp <connector> list-tools`).
- **Fetch Guidance:** Retrieve borrower financials, corporate ownership graphs, wire ledger transactions, and policy claim schedules from BigQuery, Snowflake, or customer KYB/Claims MCP servers via remote_cli mcp before Python graph and covenant checks.
- **Connected Docs & Attached File Fallback:** Fetch Google Docs (`includeTabsContent=true`), Google Sheets (`UNFORMATTED_VALUE`), Shared Drives (`supportsAllDrives=true`), and SharePoint/OneDrive workbooks (`@odata.nextLink`), or read chat-attached `.xlsx`, `.docx`, `.csv`, `.tsv`, `.json`, and `.jsonl` snapshots via `view_file` and `scripts/enterprise_io.py`.

## Step 2 — Inspect & Shape Custom Customer Fields in `pyrepl`

Customer exports and live connector responses often use custom tab names or column headers. Check the matching workflow guide from the Workflow Router Matrix above for canonical keys and inspect the real source shape in `pyrepl` before computing:

- **Inspect Real Headers & Shape:** Read attached files via `scripts/enterprise_io.py` (`read_xlsx_workbook`, `read_docx`, `read_csv_tsv`, `read_json_or_jsonl`) or inspect connector JSON keys directly in `pyrepl` so you see actual tab names, headers, and sample rows first.
- **Normalize in Python (`payload`):** Shape messy customer headers or nested JSON objects in 5-10 lines of Python into a canonical `payload` dict and call `analyze(payload, config=cfg_path)` (pass file paths directly when headers already match canonical names). Call `ask_question` only when two source columns remain genuinely ambiguous.

## Step 3 — Run Deterministic Python Engine in `pyrepl` (or CLI)

1. Read `references/config.json` using `view_file` and check `org_configured`.
2. When `org_configured` is `false`, apply the bundled starter rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`
3. Resolve `SKILL_DIR` dynamically under `/workspace/skills/` so both `pyrepl` and shell CLI invocations work regardless of install root, and enforce every bundled baseline (`references/baselines/fsi-credit-kyc-baseline.md`) and trap sheet (`references/traps/absent-is-not-zero.md`, `references/traps/chain-denominator-seams.md`, `references/traps/bigquery-sap-erp-traps.md`, `references/traps/untrusted-content-and-pii.md`).

Bundled baseline rubrics:
- `references/baselines/fsi-credit-kyc-baseline.md`

Bundled API and analytical trap guides:
- `references/traps/absent-is-not-zero.md`
- `references/traps/chain-denominator-seams.md`
- `references/traps/bigquery-sap-erp-traps.md`
- `references/traps/untrusted-content-and-pii.md`

Using persistent `pyrepl`:

```python
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/fsi-credit-kyc-claims"),
            Path("skills/user-skills/fsi-credit-kyc-claims"),
            Path("skills/commercial-credit-memo-analyst"),
            Path("skills/user-skills/commercial-credit-memo-analyst"),
            Path("."),
        )
        if (p / "scripts/credit_covenant_stress.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/credit_covenant_stress.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.enterprise_io import read_xlsx_workbook, read_docx, read_csv_tsv, read_json_or_jsonl
from scripts.credit_covenant_stress import analyze, render_markdown

cfg_path = SKILL_DIR / "references" / "config.json"

# If headers differ from canonical names, inspect in Python first and normalize:
# wb = read_xlsx_workbook(Path("customer_export.xlsx"))
# print({tab: (list(rows[0].keys()) if rows else []) for tab, rows in wb.items()})
# payload = { ...shape customer columns into canonical keys... }
payload = source_path_or_dict
result = analyze(payload, config=cfg_path)
print(render_markdown(result))
```

CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/fsi-credit-kyc-claims skills/user-skills/fsi-credit-kyc-claims skills/*; do
  [ -f "$d/scripts/credit_covenant_stress.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/credit_covenant_stress.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/ubo_velocity_screener.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/coverage_limit_evaluator.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/credit_covenant_stress.py" --help
python3 "$SKILL_DIR/scripts/ubo_velocity_screener.py" --help
python3 "$SKILL_DIR/scripts/coverage_limit_evaluator.py" --help
```

## Step 4 — Write-Back Governance (`Auto-Guardian`) & Conversational Scheduling (`schedule_task`)

- **Read-Only & Local Draft Actions:** Connector reads via `remote_cli mcp`, file inspection via `view_file`, `pyrepl` scoring, interactive Canvas (`emit_a2ui`), and saving local deliverables via `write_to_file` run without mutating external systems.
- **Agent Gateway (`Auto-Guardian`) & Explicit User Confirmation:** External write-backs executed via authorized connectors are protected by Agent Gateway (`Auto-Guardian`) and require explicit user confirmation prior to execution:
  - Submitting commercial credit underwriting decisions or covenant waivers in core banking/LOS MCP
  - Filing regulatory SAR/STR narratives or freezing customer banking accounts via AML MCP
  - Authorizing claim settlement reserve releases or disbursement payouts via Claims MCP
- **Code-Enforced Python Guardrails (`scripts/*.py`):**
  - Transitive ownership graph multiplication catching sub-threshold pass-through structures (>=10% EDD / >=25% UBO)
  - Sub-$10k structuring velocity burst detection and hard base/stress DSCR & leverage covenant breaches
  - Per-occurrence deductible, coverage sublimit, and policy exclusion net indemnity math
- **Conversational Scheduling (`schedule_task`):** Only when the user asks to automate recurring monitoring, invoke `schedule_task(title="Daily KYB Velocity & Structuring Watch", cron_expression="0 5 * * *", time_zone="UTC", instruction="Run the daily AML transaction velocity and structuring sweep via scripts/ubo_velocity_screener.py across active corporate banking accounts and flag EDD alerts for MLRO review.")`.
