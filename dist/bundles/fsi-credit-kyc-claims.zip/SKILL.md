---
name: fsi-credit-kyc-claims
description: "Calculates commercial borrower DSCR, net leverage, and interest coverage under multi-shock stress scenarios, resolves multi-hop UBO beneficial ownership with AML velocity/structuring checks, and evaluates insurance claims deterministically. Use when routing or executing Financial Services Credit, KYB/AML & Claims Underwriting workflows (commercial-credit-memo-analyst, kyc-aml-screening-dossier, insurance-claims-triage-pack). Don't use for unrelated domains outside fsi-credit-kyc-claims or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# Financial Services Credit, KYB/AML & Claims Underwriting (Department Bundle)

Calculates commercial borrower DSCR, net leverage, and interest coverage under multi-shock stress scenarios, resolves multi-hop UBO beneficial ownership with AML velocity/structuring checks, and evaluates insurance claims deterministically.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `commercial-credit-memo-analyst` | [commercial-credit-memo-analyst.md](references/workflows/commercial-credit-memo-analyst.md) | [credit_covenant_stress.py](scripts/credit_covenant_stress.py) | Calculates DSCR, Net Leverage, Interest Coverage, and Current Ratio across Base, -10%/-20% revenue, and +200bps rate shocks. |
| `kyc-aml-screening-dossier` | [kyc-aml-screening-dossier.md](references/workflows/kyc-aml-screening-dossier.md) | [ubo_velocity_screener.py](scripts/ubo_velocity_screener.py) | Traverses multi-hop holding DAGs to compute cumulative UBO ownership %, enforces 10% EDD drop, and detects velocity/structuring spikes. |
| `insurance-claims-triage-pack` | [insurance-claims-triage-pack.md](references/workflows/insurance-claims-triage-pack.md) | [coverage_limit_evaluator.py](scripts/coverage_limit_evaluator.py) | Validates policy effective periods and peril exclusions, computes deductible/coinsurance/sublimit payouts, and flags >$100k reserves. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `core_banking_and_kyb_feeds` | bigquery_sql_api, fin_kyc_registry_api | Google Sheets, Google Docs, Google Drive (Read Credit Spreadsheets (UNFORMATTED_VALUE), Corporate Ownership Docs, and Claims Adjuster Sheets in FSI Shared Drives.) | .json, .csv |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [fsi-credit-kyc-baseline.md](references/baselines/fsi-credit-kyc-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Because runtime shells start in `/workspace` while bundles and individual skills unpack under `skills/<slug>/` or `skills/user-skills/<slug>/`, always resolve `SKILL_DIR` dynamically before importing scripts or reading references.

- **Zero-dependency enterprise ingestion:** Every engine uses [enterprise_io.py](scripts/enterprise_io.py) to parse multi-tab `.xlsx`/`.xlsm` workbooks (1900/1904 dates, inline/shared strings, formula cached values), `.docx` documents (sections, headings, embedded tables, footnotes/comments), UTF-8 BOM `.csv`/`.tsv`, `.json`, and `.jsonl` directly from `--input` without needing `openpyxl` or `python-docx`. Pass `--sheet <TabName>` (or `sheet='...'` in `analyze()`) to analyze a specific worksheet.

Using persistent `pyrepl`:

```python
import json
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/fsi-credit-kyc-claims"),
            Path("skills/user-skills/fsi-credit-kyc-claims"),
            Path("skills/commercial-credit-memo-analyst"),
            Path("skills/user-skills/commercial-credit-memo-analyst"),
            Path("."),
        )
        if (p / "scripts/credit_covenant_stress.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/credit_covenant_stress.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.credit_covenant_stress import analyze, render_markdown

cfg = json.loads((SKILL_DIR / "references" / "config.json").read_text(encoding="utf-8"))
# Pass loaded Mode A/B/C payload in RAM without flooding prompt tokens:
# result = analyze(payload, config=SKILL_DIR / "references" / "config.json")
# print(render_markdown(result))
```

Using CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/fsi-credit-kyc-claims skills/user-skills/fsi-credit-kyc-claims skills/*; do
  [ -f "$d/scripts/credit_covenant_stress.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/credit_covenant_stress.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/ubo_velocity_screener.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/coverage_limit_evaluator.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
# Or pass .xlsx / .docx / .csv directly (optional --sheet "TabName"):
# python3 "$SKILL_DIR/scripts/credit_covenant_stress.py" --input workbook.xlsx --config "$SKILL_DIR/references/config.json" --format markdown
# Inspect CLI flags directly:
python3 "$SKILL_DIR/scripts/credit_covenant_stress.py" --help
python3 "$SKILL_DIR/scripts/ubo_velocity_screener.py" --help
python3 "$SKILL_DIR/scripts/coverage_limit_evaluator.py" --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [chain-denominator-seams.md](references/traps/chain-denominator-seams.md)
- [bigquery-sap-erp-traps.md](references/traps/bigquery-sap-erp-traps.md)
- [untrusted-content-and-pii.md](references/traps/untrusted-content-and-pii.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `bigquery_query_credit_spread`, `kyb_read_corporate_tree`, `claims_read_policy_terms`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `docs_create_credit_memo`, `docs_draft_sar_narrative`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `credit_commit_loan_decision` (scope: `explicit_per_call`) — Credit underwriting decisions and covenant waivers require Credit Committee approval.
  - `aml_file_sar_or_block_account` (scope: `explicit_per_call`) — Filing SARs or freezing customer accounts requires MLRO Compliance Officer sign-off.
  - `claims_issue_settlement_payout` (scope: `explicit_per_call`) — Disbursing claim settlements requires Senior Claims Adjuster approval.
