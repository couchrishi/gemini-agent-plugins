---
name: fsi-credit-kyc-claims
description: "Calculates commercial borrower DSCR, net leverage, and interest coverage under multi-shock stress scenarios, resolves multi-hop UBO beneficial ownership with AML velocity/structuring checks, and evaluates insurance claims deterministically. Use when routing or executing Financial Services Credit, KYB/AML & Claims Underwriting workflows (commercial-credit-memo-analyst, kyc-aml-screening-dossier, insurance-claims-triage-pack). Don't use for unrelated domains outside fsi-credit-kyc-claims or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# Financial Services Credit, KYB/AML & Claims Underwriting (Department Bundle)

Calculates commercial borrower DSCR, net leverage, and interest coverage under multi-shock stress scenarios, resolves multi-hop UBO beneficial ownership with AML velocity/structuring checks, and evaluates insurance claims deterministically.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `commercial-credit-memo-analyst` | [commercial-credit-memo-analyst.md](references/workflows/commercial-credit-memo-analyst.md) | [credit_covenant_stress.py](scripts/credit_covenant_stress.py) | Calculates DSCR, Net Leverage, Interest Coverage, and Current Ratio across Base, -10%/-20% revenue, and +200bps rate shocks. |
| `kyc-aml-screening-dossier` | [kyc-aml-screening-dossier.md](references/workflows/kyc-aml-screening-dossier.md) | [ubo_velocity_screener.py](scripts/ubo_velocity_screener.py) | Traverses multi-hop holding DAGs to compute cumulative UBO ownership %, enforces 10% EDD drop, and detects velocity/structuring spikes. |
| `insurance-claims-triage-pack` | [insurance-claims-triage-pack.md](references/workflows/insurance-claims-triage-pack.md) | [coverage_limit_evaluator.py](scripts/coverage_limit_evaluator.py) | Validates policy effective periods and peril exclusions, computes deductible/coinsurance/sublimit payouts, and flags >$100k reserves. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `core_banking_and_kyb_feeds` | bigquery_sql_api, fin_kyc_registry_api | Google Sheets, Google Docs, Google Drive (Read Credit Spreadsheets (UNFORMATTED_VALUE), Corporate Ownership Docs, and Claims Adjuster Sheets in FSI Shared Drives.) | .json, .csv |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [fsi-credit-kyc-baseline.md](references/baselines/fsi-credit-kyc-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Inspect outputs and optionally visualize metrics with `emit_a2ui` or automate via `schedule_task`.

Using persistent `pyrepl`:

```python
import json
from scripts.credit_covenant_stress import analyze
with open('references/config.json') as f:
    cfg = json.load(f)
# Pass loaded Mode A/B/C records in RAM without flooding context tokens
```

Using CLI fallback (`python3`):

```bash
python3 scripts/credit_covenant_stress.py --help
python3 scripts/ubo_velocity_screener.py --help
python3 scripts/coverage_limit_evaluator.py --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [chain-denominator-seams.md](references/traps/chain-denominator-seams.md)
- [bigquery-sap-erp-traps.md](references/traps/bigquery-sap-erp-traps.md)
- [untrusted-content-and-pii.md](references/traps/untrusted-content-and-pii.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `bigquery_query_credit_spread`, `kyb_read_corporate_tree`, `claims_read_policy_terms`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `docs_create_credit_memo`, `docs_draft_sar_narrative`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `credit_commit_loan_decision` (scope: `explicit_per_call`) — Credit underwriting decisions and covenant waivers require Credit Committee approval.
  - `aml_file_sar_or_block_account` (scope: `explicit_per_call`) — Filing SARs or freezing customer accounts requires MLRO Compliance Officer sign-off.
  - `claims_issue_settlement_payout` (scope: `explicit_per_call`) — Disbursing claim settlements requires Senior Claims Adjuster approval.
