---
name: people-ops-talent-hub
description: "Calibrates structured interview scorecards for score dispersion and bias signals, orchestrates 30/60/90 onboarding plans with mandatory Day-1 gate checks, and audits effective-dated Workday compensation bands with FTE/CWK separation and small-cell privacy redaction. Use when routing or executing People Ops, Talent Calibration & Workforce Analytics workflows (structured-hiring-rubric, employee-onboarding-navigator, workforce-attrition-comp-audit). Don't use for unrelated domains outside people-ops-talent-hub or automated external mutations without explicit user confirmation."
created_by: gemini-agent-plugins
---

# People Ops, Talent Calibration & Workforce Analytics (Department Bundle)

Calibrates structured interview scorecards for score dispersion and bias signals, orchestrates 30/60/90 onboarding plans with mandatory Day-1 gate checks, and audits effective-dated Workday compensation bands with FTE/CWK separation and small-cell privacy redaction.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `structured-hiring-rubric` | `references/workflows/structured-hiring-rubric.md` | `scripts/rubric_calibration_checker.py` | Audits 1-4 interview scorecards for >=2.0 dispersion, thin behavioral evidence (<40 chars), and protected-class bias signals. |
| `employee-onboarding-navigator` | `references/workflows/employee-onboarding-navigator.md` | `scripts/onboarding_plan_builder.py` | Tracks 30/60/90 onboarding milestones, enforces mandatory Day-1 IT/security gates, and detects blocked upstream dependencies. |
| `workforce-attrition-comp-audit` | `references/workflows/workforce-attrition-comp-audit.md` | `scripts/comp_band_analyzer.py` | Deduplicates effective-dated HRIS rows, isolates CWKs from FTEs, normalizes hourly/monthly/FX pay, and suppresses <5 privacy cells. |

## Step 1 — Fetch Data via Live `/work` Connectors or Attached Files

Probe enabled Gemini Enterprise connectors first before falling back to user-attached exports:

- **Built-in Managed 1P Connectors:** `Google Drive`, `Google Docs`, `Google Sheets`, `Gmail`, `ServiceNow`, `Microsoft 365 (SharePoint, OneDrive, Outlook, Teams)`.
- **Optional Customer BYO-MCP Servers:** `Workday HRIS & ATS Scorecard MCP server` (discover exposed tools via `remote_cli mcp <connector> list-tools`).
- **Fetch Guidance:** Retrieve effective-dated employee compensation rosters, contingent-worker flags, interview scorecards, and onboarding task gates from Google Sheets/ServiceNow or customer Workday/ATS MCP servers via remote_cli mcp before Python HR analytics.
- **Connected Docs & Attached File Fallback:** Fetch Google Docs (`includeTabsContent=true`), Google Sheets (`UNFORMATTED_VALUE`), Shared Drives (`supportsAllDrives=true`), and SharePoint/OneDrive workbooks (`@odata.nextLink`), or read chat-attached `.xlsx`, `.docx`, `.csv`, `.tsv`, `.json`, and `.jsonl` snapshots via `view_file` and `scripts/enterprise_io.py`.

## Step 2 — Inspect & Shape Custom Customer Fields in `pyrepl`

Customer exports and live connector responses often use custom tab names or column headers. Check the matching workflow guide from the Workflow Router Matrix above for canonical keys and inspect the real source shape in `pyrepl` before computing:

- **Inspect Real Headers & Shape:** Read attached files via `scripts/enterprise_io.py` (`read_xlsx_workbook`, `read_docx`, `read_csv_tsv`, `read_json_or_jsonl`) or inspect connector JSON keys directly in `pyrepl` so you see actual tab names, headers, and sample rows first.
- **Normalize in Python (`payload`):** Shape messy customer headers or nested JSON objects in 5-10 lines of Python into a canonical `payload` dict and call `analyze(payload, config=cfg_path)` (pass file paths directly when headers already match canonical names). Call `ask_question` only when two source columns remain genuinely ambiguous.

## Step 3 — Run Deterministic Python Engine in `pyrepl` (or CLI)

1. Read `references/config.json` using `view_file` and check `org_configured`.
2. When `org_configured` is `false`, apply the bundled starter rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`
3. Resolve `SKILL_DIR` dynamically under `/workspace/skills/` so both `pyrepl` and shell CLI invocations work regardless of install root, and enforce every bundled baseline (`references/baselines/hr-hiring-comp-baseline.md`) and trap sheet (`references/traps/workday-hris-traps.md`, `references/traps/absent-is-not-zero.md`, `references/traps/chain-denominator-seams.md`, `references/traps/google-workspace-traps.md`, `references/traps/untrusted-content-and-pii.md`).

Bundled baseline rubrics:
- `references/baselines/hr-hiring-comp-baseline.md`

Bundled API and analytical trap guides:
- `references/traps/workday-hris-traps.md`
- `references/traps/absent-is-not-zero.md`
- `references/traps/chain-denominator-seams.md`
- `references/traps/google-workspace-traps.md`
- `references/traps/untrusted-content-and-pii.md`

Using persistent `pyrepl`:

```python
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/people-ops-talent-hub"),
            Path("skills/user-skills/people-ops-talent-hub"),
            Path("skills/structured-hiring-rubric"),
            Path("skills/user-skills/structured-hiring-rubric"),
            Path("."),
        )
        if (p / "scripts/rubric_calibration_checker.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/rubric_calibration_checker.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.enterprise_io import read_xlsx_workbook, read_docx, read_csv_tsv, read_json_or_jsonl
from scripts.rubric_calibration_checker import analyze, render_markdown

cfg_path = SKILL_DIR / "references" / "config.json"

# If headers differ from canonical names, inspect in Python first and normalize:
# wb = read_xlsx_workbook(Path("customer_export.xlsx"))
# print({tab: (list(rows[0].keys()) if rows else []) for tab, rows in wb.items()})
# payload = { ...shape customer columns into canonical keys... }
payload = source_path_or_dict
result = analyze(payload, config=cfg_path)
print(render_markdown(result))
```

CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/people-ops-talent-hub skills/user-skills/people-ops-talent-hub skills/*; do
  [ -f "$d/scripts/rubric_calibration_checker.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/rubric_calibration_checker.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/onboarding_plan_builder.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/comp_band_analyzer.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/rubric_calibration_checker.py" --help
python3 "$SKILL_DIR/scripts/onboarding_plan_builder.py" --help
python3 "$SKILL_DIR/scripts/comp_band_analyzer.py" --help
```

## Step 4 — Write-Back Governance (`Auto-Guardian`) & Conversational Scheduling (`schedule_task`)

- **Read-Only & Local Draft Actions:** Connector reads via `remote_cli mcp`, file inspection via `view_file`, `pyrepl` scoring, interactive Canvas (`emit_a2ui`), and saving local deliverables via `write_to_file` run without mutating external systems.
- **Agent Gateway (`Auto-Guardian`) & Explicit User Confirmation:** External write-backs executed via authorized connectors are protected by Agent Gateway (`Auto-Guardian`) and require explicit user confirmation prior to execution:
  - Proposing or committing compensation adjustments in customer Workday HRIS MCP
  - Advancing candidate offer stages or dispatching hiring letters via customer ATS MCP / Gmail
- **Code-Enforced Python Guardrails (`scripts/*.py`):**
  - Strict small-cohort n < min_privacy_group_size (n < 5) k-anonymity salary & attrition redaction
  - Effective-date deduplication, Contingent Worker (CWK) isolation from FTE totals, and EUR/GBP monthly FX normalization
  - Scorecard bias/halo variance alert preventing autonomous hiring recommendations
- **Conversational Scheduling (`schedule_task`):** Only when the user asks to automate recurring monitoring, invoke `schedule_task(title="Weekly Onboarding Stall Watch", cron_expression="0 8 * * 1", time_zone="UTC", instruction="Run the weekly onboarding gate check via scripts/onboarding_plan_builder.py to detect missing Day-1 IT/security gates and stalled 30/60/90 milestones.")`.
