---
name: people-ops-talent-hub
description: "Calibrates structured interview scorecards for score dispersion and bias signals, orchestrates 30/60/90 onboarding plans with mandatory Day-1 gate checks, and audits effective-dated Workday compensation bands with FTE/CWK separation and small-cell privacy redaction. Use when routing or executing People Ops, Talent Calibration & Workforce Analytics workflows (structured-hiring-rubric, employee-onboarding-navigator, workforce-attrition-comp-audit). Don't use for unrelated domains outside people-ops-talent-hub or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# People Ops, Talent Calibration & Workforce Analytics (Department Bundle)

Calibrates structured interview scorecards for score dispersion and bias signals, orchestrates 30/60/90 onboarding plans with mandatory Day-1 gate checks, and audits effective-dated Workday compensation bands with FTE/CWK separation and small-cell privacy redaction.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `structured-hiring-rubric` | [structured-hiring-rubric.md](references/workflows/structured-hiring-rubric.md) | [rubric_calibration_checker.py](scripts/rubric_calibration_checker.py) | Audits 1-4 interview scorecards for >=2.0 dispersion, thin behavioral evidence (<40 chars), and protected-class bias signals. |
| `employee-onboarding-navigator` | [employee-onboarding-navigator.md](references/workflows/employee-onboarding-navigator.md) | [onboarding_plan_builder.py](scripts/onboarding_plan_builder.py) | Tracks 30/60/90 onboarding milestones, enforces mandatory Day-1 IT/security gates, and detects blocked upstream dependencies. |
| `workforce-attrition-comp-audit` | [workforce-attrition-comp-audit.md](references/workflows/workforce-attrition-comp-audit.md) | [comp_band_analyzer.py](scripts/comp_band_analyzer.py) | Deduplicates effective-dated HRIS rows, isolates CWKs from FTEs, normalizes hourly/monthly/FX pay, and suppresses <5 privacy cells. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `hris_and_ats_records` | workday_raas_api, greenhouse_harvest_api | Google Sheets, Google Docs, Google Drive (Read Workforce Roster Sheets (UNFORMATTED_VALUE) and Interview Debrief Docs in People Ops Shared Drives.) | .json, .csv |
| `onboarding_it_provisioning` | servicenow_hrsd_api | Google Sheets, Gmail, Google Drive (Inspect Onboarding Tracker Sheets and IT ticket updates in People Ops Drives.) | .json, .csv |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [hr-hiring-comp-baseline.md](references/baselines/hr-hiring-comp-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Because runtime shells start in `/workspace` while bundles and individual skills unpack under `skills/<slug>/` or `skills/user-skills/<slug>/`, always resolve `SKILL_DIR` dynamically before importing scripts or reading references.

- **Zero-dependency enterprise ingestion:** Every engine uses [enterprise_io.py](scripts/enterprise_io.py) to parse multi-tab `.xlsx`/`.xlsm` workbooks (1900/1904 dates, inline/shared strings, formula cached values), `.docx` documents (sections, headings, embedded tables, footnotes/comments), UTF-8 BOM `.csv`/`.tsv`, `.json`, and `.jsonl` directly from `--input` without needing `openpyxl` or `python-docx`. Pass `--sheet <TabName>` (or `sheet='...'` in `analyze()`) to analyze a specific worksheet.

Using persistent `pyrepl`:

```python
import json
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/people-ops-talent-hub"),
            Path("skills/user-skills/people-ops-talent-hub"),
            Path("skills/structured-hiring-rubric"),
            Path("skills/user-skills/structured-hiring-rubric"),
            Path("."),
        )
        if (p / "scripts/rubric_calibration_checker.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/rubric_calibration_checker.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.rubric_calibration_checker import analyze, render_markdown

cfg = json.loads((SKILL_DIR / "references" / "config.json").read_text(encoding="utf-8"))
# Pass loaded Mode A/B/C payload in RAM without flooding prompt tokens:
# result = analyze(payload, config=SKILL_DIR / "references" / "config.json")
# print(render_markdown(result))
```

Using CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/people-ops-talent-hub skills/user-skills/people-ops-talent-hub skills/*; do
  [ -f "$d/scripts/rubric_calibration_checker.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/rubric_calibration_checker.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/onboarding_plan_builder.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/comp_band_analyzer.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
# Or pass .xlsx / .docx / .csv directly (optional --sheet "TabName"):
# python3 "$SKILL_DIR/scripts/rubric_calibration_checker.py" --input workbook.xlsx --config "$SKILL_DIR/references/config.json" --format markdown
# Inspect CLI flags directly:
python3 "$SKILL_DIR/scripts/rubric_calibration_checker.py" --help
python3 "$SKILL_DIR/scripts/onboarding_plan_builder.py" --help
python3 "$SKILL_DIR/scripts/comp_band_analyzer.py" --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [workday-hris-traps.md](references/traps/workday-hris-traps.md)
- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [chain-denominator-seams.md](references/traps/chain-denominator-seams.md)
- [google-workspace-traps.md](references/traps/google-workspace-traps.md)
- [untrusted-content-and-pii.md](references/traps/untrusted-content-and-pii.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `workday_read_effective_roster`, `greenhouse_read_scorecards`, `sheets_read_unformatted`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `docs_create_debrief_pack`, `docs_create_onboarding_checklist`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `workday_propose_comp_change` (scope: `explicit_per_call`) — Compensation adjustments require Compensation Lead and HRBP approval.
  - `greenhouse_advance_offer_stage` (scope: `explicit_per_call`) — Hiring decisions and offer approvals must remain strictly human-owned.
