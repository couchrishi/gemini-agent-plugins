---
name: brand-campaign-studio
description: "Lints marketing copy against brand voice rules, prohibited claims, and channel limits, validates audience-by-channel multimodal campaign matrices, and audits global localization packs against do-not-translate glossaries. Use when routing or executing Brand Governance, Campaign Matrix & Localization Studio workflows (brand-voice-compliance-gate, multimodal-campaign-brief, market-localization-adapter). Don't use for unrelated domains outside brand-campaign-studio or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# Brand Governance, Campaign Matrix & Localization Studio (Department Bundle)

Lints marketing copy against brand voice rules, prohibited claims, and channel limits, validates audience-by-channel multimodal campaign matrices, and audits global localization packs against do-not-translate glossaries.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `brand-voice-compliance-gate` | [brand-voice-compliance-gate.md](references/workflows/brand-voice-compliance-gate.md) | [copy_compliance_linter.py](scripts/copy_compliance_linter.py) | Lints marketing copy for banned guarantees, missing substantiation disclaimers, readability density, and channel char caps. |
| `multimodal-campaign-brief` | [multimodal-campaign-brief.md](references/workflows/multimodal-campaign-brief.md) | [campaign_asset_matrix.py](scripts/campaign_asset_matrix.py) | Audits audience-by-channel and funnel coverage matrices, planned spend vs budget, and critical-path launch buffers. |
| `market-localization-adapter` | [market-localization-adapter.md](references/workflows/market-localization-adapter.md) | [locale_glossary_checker.py](scripts/locale_glossary_checker.py) | Verifies target locale translations for missing markets, untranslated leaks, DNT term preservation, and regional glossary fidelity. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `marketing_asset_repository` | google_drive_api, microsoft_graph_sharepoint | Google Docs, Google Sheets, Google Slides, Google Drive (Read Brand Playbook Docs, Campaign Matrix Sheets, and Launch Decks in Marketing Shared Drives.) | .json, .csv, .md |
| `localization_cms` | smartling_tms_api | Google Sheets, Google Docs (Inspect Regional Copy & Glossary Tabs in Marketing Launch Sheets.) | .json, .csv |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [commercial-contract-baseline.md](references/baselines/commercial-contract-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Because runtime shells start in `/workspace` while bundles and individual skills unpack under `skills/<slug>/` or `skills/user-skills/<slug>/`, always resolve `SKILL_DIR` dynamically before importing scripts or reading references.

- **Zero-dependency enterprise ingestion:** Every engine uses [enterprise_io.py](scripts/enterprise_io.py) to parse multi-tab `.xlsx`/`.xlsm` workbooks (1900/1904 dates, inline/shared strings, formula cached values), `.docx` documents (sections, headings, embedded tables, footnotes/comments), UTF-8 BOM `.csv`/`.tsv`, `.json`, and `.jsonl` directly from `--input` without needing `openpyxl` or `python-docx`. Pass `--sheet <TabName>` (or `sheet='...'` in `analyze()`) to analyze a specific worksheet.

Using persistent `pyrepl`:

```python
import json
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/brand-campaign-studio"),
            Path("skills/user-skills/brand-campaign-studio"),
            Path("skills/brand-voice-compliance-gate"),
            Path("skills/user-skills/brand-voice-compliance-gate"),
            Path("."),
        )
        if (p / "scripts/copy_compliance_linter.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/copy_compliance_linter.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.copy_compliance_linter import analyze, render_markdown

cfg = json.loads((SKILL_DIR / "references" / "config.json").read_text(encoding="utf-8"))
# Pass loaded Mode A/B/C payload in RAM without flooding prompt tokens:
# result = analyze(payload, config=SKILL_DIR / "references" / "config.json")
# print(render_markdown(result))
```

Using CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/brand-campaign-studio skills/user-skills/brand-campaign-studio skills/*; do
  [ -f "$d/scripts/copy_compliance_linter.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/copy_compliance_linter.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/campaign_asset_matrix.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/locale_glossary_checker.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
# Or pass .xlsx / .docx / .csv directly (optional --sheet "TabName"):
# python3 "$SKILL_DIR/scripts/copy_compliance_linter.py" --input workbook.xlsx --config "$SKILL_DIR/references/config.json" --format markdown
# Inspect CLI flags directly:
python3 "$SKILL_DIR/scripts/copy_compliance_linter.py" --help
python3 "$SKILL_DIR/scripts/campaign_asset_matrix.py" --help
python3 "$SKILL_DIR/scripts/locale_glossary_checker.py" --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [google-workspace-traps.md](references/traps/google-workspace-traps.md)
- [sharepoint-onedrive-kql-traps.md](references/traps/sharepoint-onedrive-kql-traps.md)
- [untrusted-content-and-pii.md](references/traps/untrusted-content-and-pii.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `drive_read_brand_kit`, `smartling_read_translations`, `docs_read_tabs`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `docs_create_campaign_brief`, `slides_draft_creative_deck`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `cms_publish_campaign_asset` (scope: `explicit_per_call`) — Publishing public marketing copy or paid ads requires Brand & Legal approval.
