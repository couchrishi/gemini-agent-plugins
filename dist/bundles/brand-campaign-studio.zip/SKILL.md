---
name: brand-campaign-studio
description: "Lints marketing copy against brand voice rules, prohibited claims, and channel limits, validates audience-by-channel multimodal campaign matrices, and audits global localization packs against do-not-translate glossaries. Use when routing or executing Brand Governance, Campaign Matrix & Localization Studio workflows (brand-voice-compliance-gate, multimodal-campaign-brief, market-localization-adapter). Don't use for unrelated domains outside brand-campaign-studio or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# Brand Governance, Campaign Matrix & Localization Studio (Department Bundle)

Lints marketing copy against brand voice rules, prohibited claims, and channel limits, validates audience-by-channel multimodal campaign matrices, and audits global localization packs against do-not-translate glossaries.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `brand-voice-compliance-gate` | [brand-voice-compliance-gate.md](references/workflows/brand-voice-compliance-gate.md) | [copy_compliance_linter.py](scripts/copy_compliance_linter.py) | Lints marketing copy for banned guarantees, missing substantiation disclaimers, readability density, and channel char caps. |
| `multimodal-campaign-brief` | [multimodal-campaign-brief.md](references/workflows/multimodal-campaign-brief.md) | [campaign_asset_matrix.py](scripts/campaign_asset_matrix.py) | Audits audience-by-channel and funnel coverage matrices, planned spend vs budget, and critical-path launch buffers. |
| `market-localization-adapter` | [market-localization-adapter.md](references/workflows/market-localization-adapter.md) | [locale_glossary_checker.py](scripts/locale_glossary_checker.py) | Verifies target locale translations for missing markets, untranslated leaks, DNT term preservation, and regional glossary fidelity. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `marketing_asset_repository` | google_drive_api, microsoft_graph_sharepoint | Google Docs, Google Sheets, Google Slides, Google Drive (Read Brand Playbook Docs, Campaign Matrix Sheets, and Launch Decks in Marketing Shared Drives.) | .json, .csv, .md |
| `localization_cms` | smartling_tms_api | Google Sheets, Google Docs (Inspect Regional Copy & Glossary Tabs in Marketing Launch Sheets.) | .json, .csv |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [commercial-contract-baseline.md](references/baselines/commercial-contract-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Inspect outputs and optionally visualize metrics with `emit_a2ui` or automate via `schedule_task`.

Using persistent `pyrepl`:

```python
import json
from scripts.copy_compliance_linter import analyze
with open('references/config.json') as f:
    cfg = json.load(f)
# Pass loaded Mode A/B/C records in RAM without flooding context tokens
```

Using CLI fallback (`python3`):

```bash
python3 scripts/copy_compliance_linter.py --help
python3 scripts/campaign_asset_matrix.py --help
python3 scripts/locale_glossary_checker.py --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [google-workspace-traps.md](references/traps/google-workspace-traps.md)
- [sharepoint-onedrive-kql-traps.md](references/traps/sharepoint-onedrive-kql-traps.md)
- [untrusted-content-and-pii.md](references/traps/untrusted-content-and-pii.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `drive_read_brand_kit`, `smartling_read_translations`, `docs_read_tabs`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `docs_create_campaign_brief`, `slides_draft_creative_deck`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `cms_publish_campaign_asset` (scope: `explicit_per_call`) — Publishing public marketing copy or paid ads requires Brand & Legal approval.
