---
name: brand-campaign-studio
description: "Lints marketing copy against brand voice rules, prohibited claims, and channel limits, validates audience-by-channel multimodal campaign matrices, and audits global localization packs against do-not-translate glossaries. Use when routing or executing Brand Governance, Campaign Matrix & Localization Studio workflows (brand-voice-compliance-gate, multimodal-campaign-brief, market-localization-adapter). Don't use for unrelated domains outside brand-campaign-studio or automated external mutations without explicit user confirmation."
created_by: gemini-agent-plugins
---

# Brand Governance, Campaign Matrix & Localization Studio (Department Bundle)

Lints marketing copy against brand voice rules, prohibited claims, and channel limits, validates audience-by-channel multimodal campaign matrices, and audits global localization packs against do-not-translate glossaries.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `brand-voice-compliance-gate` | `references/workflows/brand-voice-compliance-gate.md` | `scripts/copy_compliance_linter.py` | Lints marketing copy for banned guarantees, missing substantiation disclaimers, readability density, and channel char caps. |
| `multimodal-campaign-brief` | `references/workflows/multimodal-campaign-brief.md` | `scripts/campaign_asset_matrix.py` | Audits audience-by-channel and funnel coverage matrices, planned spend vs budget, and critical-path launch buffers. |
| `market-localization-adapter` | `references/workflows/market-localization-adapter.md` | `scripts/locale_glossary_checker.py` | Verifies target locale translations for missing markets, untranslated leaks, DNT term preservation, and regional glossary fidelity. |

## Step 1 — Fetch Data via Live `/work` Connectors or Attached Files

Probe enabled Gemini Enterprise connectors first before falling back to user-attached exports:

- **Built-in Managed 1P Connectors:** `Google Drive`, `Google Docs`, `Google Sheets`, `Google Slides`, `Microsoft 365 (SharePoint, OneDrive, Outlook, Teams)`, `Slack`.
- **Optional Customer BYO-MCP Servers:** `Localization TMS & Brand CMS MCP server` (discover exposed tools via `remote_cli mcp <connector> list-tools`).
- **Fetch Guidance:** Query Google Drive, SharePoint, and Docs via remote_cli mcp or Workspace tools to pull brand guidelines, campaign copy decks, and locale translation sheets before running copy and glossary lint checks in Python.
- **Connected Docs & Attached File Fallback:** Fetch Google Docs (`includeTabsContent=true`), Google Sheets (`UNFORMATTED_VALUE`), Shared Drives (`supportsAllDrives=true`), and SharePoint/OneDrive workbooks (`@odata.nextLink`), or read chat-attached `.xlsx`, `.docx`, `.csv`, `.tsv`, `.json`, and `.jsonl` snapshots via `view_file` and `scripts/enterprise_io.py`.

## Step 2 — Inspect & Shape Custom Customer Fields in `pyrepl`

Customer exports and live connector responses often use custom tab names or column headers. Check the matching workflow guide from the Workflow Router Matrix above for canonical keys and inspect the real source shape in `pyrepl` before computing:

- **Inspect Real Headers & Shape:** Read attached files via `scripts/enterprise_io.py` (`read_xlsx_workbook`, `read_docx`, `read_csv_tsv`, `read_json_or_jsonl`) or inspect connector JSON keys directly in `pyrepl` so you see actual tab names, headers, and sample rows first.
- **Normalize in Python (`payload`):** Shape messy customer headers or nested JSON objects in 5-10 lines of Python into a canonical `payload` dict and call `analyze(payload, config=cfg_path)` (pass file paths directly when headers already match canonical names). Call `ask_question` only when two source columns remain genuinely ambiguous.

## Step 3 — Run Deterministic Python Engine in `pyrepl` (or CLI)

1. Read `references/config.json` using `view_file` and check `org_configured`.
2. When `org_configured` is `false`, apply the bundled starter rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`
3. Resolve `SKILL_DIR` dynamically under `/workspace/skills/` so both `pyrepl` and shell CLI invocations work regardless of install root, and enforce every bundled baseline (`references/baselines/commercial-contract-baseline.md`) and trap sheet (`references/traps/absent-is-not-zero.md`, `references/traps/google-workspace-traps.md`, `references/traps/sharepoint-onedrive-kql-traps.md`, `references/traps/untrusted-content-and-pii.md`).

Bundled baseline rubrics:
- `references/baselines/commercial-contract-baseline.md`

Bundled API and analytical trap guides:
- `references/traps/absent-is-not-zero.md`
- `references/traps/google-workspace-traps.md`
- `references/traps/sharepoint-onedrive-kql-traps.md`
- `references/traps/untrusted-content-and-pii.md`

Using persistent `pyrepl`:

```python
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/brand-campaign-studio"),
            Path("skills/user-skills/brand-campaign-studio"),
            Path("skills/brand-voice-compliance-gate"),
            Path("skills/user-skills/brand-voice-compliance-gate"),
            Path("."),
        )
        if (p / "scripts/copy_compliance_linter.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/copy_compliance_linter.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.enterprise_io import read_xlsx_workbook, read_docx, read_csv_tsv, read_json_or_jsonl
from scripts.copy_compliance_linter import analyze, render_markdown

cfg_path = SKILL_DIR / "references" / "config.json"

# If headers differ from canonical names, inspect in Python first and normalize:
# wb = read_xlsx_workbook(Path("customer_export.xlsx"))
# print({tab: (list(rows[0].keys()) if rows else []) for tab, rows in wb.items()})
# payload = { ...shape customer columns into canonical keys... }
payload = source_path_or_dict
result = analyze(payload, config=cfg_path)
print(render_markdown(result))
```

CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/brand-campaign-studio skills/user-skills/brand-campaign-studio skills/*; do
  [ -f "$d/scripts/copy_compliance_linter.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/copy_compliance_linter.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/campaign_asset_matrix.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/locale_glossary_checker.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/copy_compliance_linter.py" --help
python3 "$SKILL_DIR/scripts/campaign_asset_matrix.py" --help
python3 "$SKILL_DIR/scripts/locale_glossary_checker.py" --help
```

## Step 4 — Write-Back Governance (`Auto-Guardian`) & Conversational Scheduling (`schedule_task`)

- **Read-Only & Local Draft Actions:** Connector reads via `remote_cli mcp`, file inspection via `view_file`, `pyrepl` scoring, interactive Canvas (`emit_a2ui`), and saving local deliverables via `write_to_file` run without mutating external systems.
- **Agent Gateway (`Auto-Guardian`) & Explicit User Confirmation:** External write-backs executed via authorized connectors are protected by Agent Gateway (`Auto-Guardian`) and require explicit user confirmation prior to execution:
  - Publishing public campaign copy or paid ad assets via CMS MCP or shared workspace channels
  - Sending external agency creative briefs or translation sign-offs over email or Slack
- **Code-Enforced Python Guardrails (`scripts/*.py`):**
  - Unverified superlative, ROI, and missing mandatory claim disclaimer blocker
  - Strict Do-Not-Translate (DNT) brand glossary and channel character-limit enforcement
  - Brand color/tone deviation and critical-path campaign dependency cycle checks
- **Conversational Scheduling (`schedule_task`):** Only when the user asks to automate recurring monitoring, invoke `schedule_task(title="Weekly Campaign Compliance Sweep", cron_expression="0 10 * * 2", time_zone="UTC", instruction="Run the weekly marketing compliance sweep via scripts/copy_compliance_linter.py across upcoming campaign drafts and flag missing disclaimers or prohibited claims.")`.
