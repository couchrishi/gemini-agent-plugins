---
name: healthcare-clinical-regulatory
description: "Validates clinical Schedule of Assessments schedules vs endpoints and enrollment capacity, checks E2B ICSR 4 minimum criteria and 7/15-day statutory clocks with PHI redaction alerts, and audits prior authorization packets against payer criteria. Use when routing or executing Healthcare Clinical Trial, Pharmacovigilance & Prior Auth workflows (clinical-protocol-feasibility, pharmacovigilance-safety-intake, prior-auth-medical-necessity). Don't use for unrelated domains outside healthcare-clinical-regulatory or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# Healthcare Clinical Trial, Pharmacovigilance & Prior Auth (Department Bundle)

Validates clinical Schedule of Assessments schedules vs endpoints and enrollment capacity, checks E2B ICSR 4 minimum criteria and 7/15-day statutory clocks with PHI redaction alerts, and audits prior authorization packets against payer criteria.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `clinical-protocol-feasibility` | [clinical-protocol-feasibility.md](references/workflows/clinical-protocol-feasibility.md) | [soa_endpoint_validator.py](scripts/soa_endpoint_validator.py) | Detects missing endpoint procedures in trial Schedules of Assessments and projects net IRB-approved screen-adjusted enrollment. |
| `pharmacovigilance-safety-intake` | [pharmacovigilance-safety-intake.md](references/workflows/pharmacovigilance-safety-intake.md) | [icsr_completeness_checker.py](scripts/icsr_completeness_checker.py) | Validates 4 ICH minimum ICSR criteria, calculates 7-day/15-day/90-day statutory clocks from awareness_date, and traps raw PHI leaks. |
| `prior-auth-medical-necessity` | [prior-auth-medical-necessity.md](references/workflows/prior-auth-medical-necessity.md) | [medical_criteria_matcher.py](scripts/medical_criteria_matcher.py) | Matches CPT prior-auth packets against covered ICD-10 prefixes, step-therapy trial durations, and required diagnostic labs. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `clinical_ctms_and_safety_db` | ctms_fhir_api, bigquery_sql_api | Google Sheets, Google Docs, Google Drive (Read De-Identified SoA Feasibility Sheets, PV Intake Logs, and Medical Policy Playbooks in Clinical Ops Drives.) | .json, .csv |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [commercial-contract-baseline.md](references/baselines/commercial-contract-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Inspect outputs and optionally visualize metrics with `emit_a2ui` or automate via `schedule_task`.

Using persistent `pyrepl`:

```python
import json
from scripts.soa_endpoint_validator import analyze
with open('references/config.json') as f:
    cfg = json.load(f)
# Pass loaded Mode A/B/C records in RAM without flooding context tokens
```

Using CLI fallback (`python3`):

```bash
python3 scripts/soa_endpoint_validator.py --help
python3 scripts/icsr_completeness_checker.py --help
python3 scripts/medical_criteria_matcher.py --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [chain-denominator-seams.md](references/traps/chain-denominator-seams.md)
- [untrusted-content-and-pii.md](references/traps/untrusted-content-and-pii.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `ctms_read_soa_protocol`, `safety_read_deidentified_icsr`, `payer_read_clinical_policy`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `docs_create_feasibility_brief`, `docs_draft_prior_auth_summary`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `pv_submit_e2b_regulatory_report` (scope: `explicit_per_call`) — Submitting E2B safety reports to FDA/EMA/PMDA requires Pharmacovigilance QPPV medical sign-off.
  - `payer_finalize_auth_determination` (scope: `explicit_per_call`) — Final clinical approvals or medical necessity denials always require Medical Director / Clinician confirmation.
