---
name: healthcare-clinical-regulatory
description: "Validates clinical Schedule of Assessments schedules vs endpoints and enrollment capacity, checks E2B ICSR 4 minimum criteria and 7/15-day statutory clocks with PHI redaction alerts, and audits prior authorization packets against payer criteria. Use when routing or executing Healthcare Clinical Trial, Pharmacovigilance & Prior Auth workflows (clinical-protocol-feasibility, pharmacovigilance-safety-intake, prior-auth-medical-necessity). Don't use for unrelated domains outside healthcare-clinical-regulatory or automated external mutations without explicit user confirmation."
created_by: gemini-agent-plugins
---

# Healthcare Clinical Trial, Pharmacovigilance & Prior Auth (Department Bundle)

Validates clinical Schedule of Assessments schedules vs endpoints and enrollment capacity, checks E2B ICSR 4 minimum criteria and 7/15-day statutory clocks with PHI redaction alerts, and audits prior authorization packets against payer criteria.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `clinical-protocol-feasibility` | `references/workflows/clinical-protocol-feasibility.md` | `scripts/soa_endpoint_validator.py` | Detects missing endpoint procedures in trial Schedules of Assessments and projects net IRB-approved screen-adjusted enrollment. |
| `pharmacovigilance-safety-intake` | `references/workflows/pharmacovigilance-safety-intake.md` | `scripts/icsr_completeness_checker.py` | Validates 4 ICH minimum ICSR criteria, calculates 7-day/15-day/90-day statutory clocks from awareness_date, and traps raw PHI leaks. |
| `prior-auth-medical-necessity` | `references/workflows/prior-auth-medical-necessity.md` | `scripts/medical_criteria_matcher.py` | Matches CPT prior-auth packets against covered ICD-10 prefixes, step-therapy trial durations, and required diagnostic labs. |

## Step 1 — Fetch Data via Live `/work` Connectors or Attached Files

Probe enabled Gemini Enterprise connectors first before falling back to user-attached exports:

- **Built-in Managed 1P Connectors:** `BigQuery`, `Google Drive`, `Google Docs`, `Google Sheets`.
- **Optional Customer BYO-MCP Servers:** `Claims / EHR Clearinghouse & CTMS Safety Gateway MCP server` (discover exposed tools via `remote_cli mcp <connector> list-tools`).
- **Fetch Guidance:** Fetch de-identified clinical protocol Schedules of Assessments, ICSR adverse-event safety intakes, and prior-auth medical policy criteria from BigQuery or customer CTMS/Clearinghouse MCP servers via remote_cli mcp before Python validation.
- **Connected Docs & Attached File Fallback:** Fetch Google Docs (`includeTabsContent=true`), Google Sheets (`UNFORMATTED_VALUE`), Shared Drives (`supportsAllDrives=true`), and SharePoint/OneDrive workbooks (`@odata.nextLink`), or read chat-attached `.xlsx`, `.docx`, `.csv`, `.tsv`, `.json`, and `.jsonl` snapshots via `view_file` and `scripts/enterprise_io.py`.

## Step 2 — Inspect & Shape Custom Customer Fields in `pyrepl`

Customer exports and live connector responses often use custom tab names or column headers. Check the matching workflow guide from the Workflow Router Matrix above for canonical keys and inspect the real source shape in `pyrepl` before computing:

- **Inspect Real Headers & Shape:** Read attached files via `scripts/enterprise_io.py` (`read_xlsx_workbook`, `read_docx`, `read_csv_tsv`, `read_json_or_jsonl`) or inspect connector JSON keys directly in `pyrepl` so you see actual tab names, headers, and sample rows first.
- **Normalize in Python (`payload`):** Shape messy customer headers or nested JSON objects in 5-10 lines of Python into a canonical `payload` dict and call `analyze(payload, config=cfg_path)` (pass file paths directly when headers already match canonical names). Call `ask_question` only when two source columns remain genuinely ambiguous.

## Step 3 — Run Deterministic Python Engine in `pyrepl` (or CLI)

1. Read `references/config.json` using `view_file` and check `org_configured`.
2. When `org_configured` is `false`, apply the bundled starter rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`
3. Resolve `SKILL_DIR` dynamically under `/workspace/skills/` so both `pyrepl` and shell CLI invocations work regardless of install root, and enforce every bundled baseline (`references/baselines/commercial-contract-baseline.md`) and trap sheet (`references/traps/absent-is-not-zero.md`, `references/traps/chain-denominator-seams.md`, `references/traps/untrusted-content-and-pii.md`).

Bundled baseline rubrics:
- `references/baselines/commercial-contract-baseline.md`

Bundled API and analytical trap guides:
- `references/traps/absent-is-not-zero.md`
- `references/traps/chain-denominator-seams.md`
- `references/traps/untrusted-content-and-pii.md`

Using persistent `pyrepl`:

```python
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/healthcare-clinical-regulatory"),
            Path("skills/user-skills/healthcare-clinical-regulatory"),
            Path("skills/clinical-protocol-feasibility"),
            Path("skills/user-skills/clinical-protocol-feasibility"),
            Path("."),
        )
        if (p / "scripts/soa_endpoint_validator.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/soa_endpoint_validator.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.enterprise_io import read_xlsx_workbook, read_docx, read_csv_tsv, read_json_or_jsonl
from scripts.soa_endpoint_validator import analyze, render_markdown

cfg_path = SKILL_DIR / "references" / "config.json"

# If headers differ from canonical names, inspect in Python first and normalize:
# wb = read_xlsx_workbook(Path("customer_export.xlsx"))
# print({tab: (list(rows[0].keys()) if rows else []) for tab, rows in wb.items()})
# payload = { ...shape customer columns into canonical keys... }
payload = source_path_or_dict
result = analyze(payload, config=cfg_path)
print(render_markdown(result))
```

CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/healthcare-clinical-regulatory skills/user-skills/healthcare-clinical-regulatory skills/*; do
  [ -f "$d/scripts/soa_endpoint_validator.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/soa_endpoint_validator.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/icsr_completeness_checker.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/medical_criteria_matcher.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/soa_endpoint_validator.py" --help
python3 "$SKILL_DIR/scripts/icsr_completeness_checker.py" --help
python3 "$SKILL_DIR/scripts/medical_criteria_matcher.py" --help
```

## Step 4 — Write-Back Governance (`Auto-Guardian`) & Conversational Scheduling (`schedule_task`)

- **Read-Only & Local Draft Actions:** Connector reads via `remote_cli mcp`, file inspection via `view_file`, `pyrepl` scoring, interactive Canvas (`emit_a2ui`), and saving local deliverables via `write_to_file` run without mutating external systems.
- **Agent Gateway (`Auto-Guardian`) & Explicit User Confirmation:** External write-backs executed via authorized connectors are protected by Agent Gateway (`Auto-Guardian`) and require explicit user confirmation prior to execution:
  - Submitting E2B regulatory safety reports to FDA/EMA/PMDA via customer Safety MCP
  - Finalizing clinical prior-authorization medical necessity approvals or denials via Clearinghouse MCP
- **Code-Enforced Python Guardrails (`scripts/*.py`):**
  - Unredacted SSN, email, or phone PHI detection and masking inside narrative outputs
  - Fatal/life-threatening 7-day SUSAR vs 15-day statutory reporting deadline and 4-criteria check
  - Step-therapy completion verification (never conflating active ongoing therapy with completed prerequisites)
- **Conversational Scheduling (`schedule_task`):** Only when the user asks to automate recurring monitoring, invoke `schedule_task(title="Daily Pharmacovigilance ICSR SLA Watch", cron_expression="0 7 * * *", time_zone="UTC", instruction="Run the daily pharmacovigilance intake check via scripts/icsr_completeness_checker.py to watch 7-day fatal SUSAR clocks, incomplete 4-criteria cases, and raw PHI alerts.")`.
