---
name: executive-briefing-ops
description: "Prepares daily executive briefings with calendar conflict and commitment tracking, extracts structured action/decision packs from meeting transcripts, and synthesizes multi-signal stakeholder account dossiers. Use when routing or executing Executive Briefing & Chief of Staff Ops workflows (daily-executive-briefing, meeting-to-execution-pack, stakeholder-account-prep). Don't use for unrelated domains outside executive-briefing-ops or automated external mutations without explicit user confirmation."
created_by: gemini-agent-plugins
---

# Executive Briefing & Chief of Staff Ops (Department Bundle)

Prepares daily executive briefings with calendar conflict and commitment tracking, extracts structured action/decision packs from meeting transcripts, and synthesizes multi-signal stakeholder account dossiers.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `daily-executive-briefing` | `references/workflows/daily-executive-briefing.md` | `scripts/agenda_commitment_tracker.py` | Reconciles calendar events, priority threads, and open action items into time-boxed prep blocks with conflict and overdue alerts. |
| `meeting-to-execution-pack` | `references/workflows/meeting-to-execution-pack.md` | `scripts/transcript_action_extractor.py` | Extracts owner-assigned commitments, decision logs, unresolved blockers, and repeat carryovers from meeting transcripts. |
| `stakeholder-account-prep` | `references/workflows/stakeholder-account-prep.md` | `scripts/dossier_synthesizer.py` | Aggregates account ARR milestones, open escalations, executive touchpoints, and renewal countdowns into scored stakeholder dossiers. |

## Step 1 — Fetch Data via Live `/work` Connectors or Attached Files

Probe enabled Gemini Enterprise connectors first before falling back to user-attached exports:

- **Built-in Managed 1P Connectors:** `Google Calendar`, `Gmail`, `Google Drive`, `Google Docs`, `Google Sheets`, `Microsoft 365 (SharePoint, OneDrive, Outlook, Teams)`, `Salesforce`, `Slack`.
- **Connector Tool Discovery:** Query enabled 1P/MCP servers via `remote_cli mcp <connector> list-tools` before calling Python engines.
- **Fetch Guidance:** Collect day calendar events, Gmail/Outlook threads, Meet transcripts, and Salesforce account snapshots via remote_cli mcp before building overlap checks, action tables, and stakeholder briefs in Python.
- **Connected Docs & Attached File Fallback:** Fetch Google Docs (`includeTabsContent=true`), Google Sheets (`UNFORMATTED_VALUE`), Shared Drives (`supportsAllDrives=true`), and SharePoint/OneDrive workbooks (`@odata.nextLink`), or read chat-attached `.xlsx`, `.docx`, `.csv`, `.tsv`, `.json`, and `.jsonl` snapshots via `view_file` and `scripts/enterprise_io.py`.

## Step 2 — Inspect & Shape Custom Customer Fields in `pyrepl`

Customer exports and live connector responses often use custom tab names or column headers. Check the matching workflow guide from the Workflow Router Matrix above for canonical keys and inspect the real source shape in `pyrepl` before computing:

- **Inspect Real Headers & Shape:** Read attached files via `scripts/enterprise_io.py` (`read_xlsx_workbook`, `read_docx`, `read_csv_tsv`, `read_json_or_jsonl`) or inspect connector JSON keys directly in `pyrepl` so you see actual tab names, headers, and sample rows first.
- **Normalize in Python (`payload`):** Shape messy customer headers or nested JSON objects in 5-10 lines of Python into a canonical `payload` dict and call `analyze(payload, config=cfg_path)` (pass file paths directly when headers already match canonical names). Call `ask_question` only when two source columns remain genuinely ambiguous.

## Step 3 — Run Deterministic Python Engine in `pyrepl` (or CLI)

1. Read `references/config.json` using `view_file` and check `org_configured`.
2. When `org_configured` is `false`, apply the bundled starter rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`
3. Resolve `SKILL_DIR` dynamically under `/workspace/skills/` so both `pyrepl` and shell CLI invocations work regardless of install root, and enforce every bundled baseline (`references/baselines/deal-desk-approval-baseline.md`, `references/baselines/itsm-sla-severity-baseline.md`) and trap sheet (`references/traps/absent-is-not-zero.md`, `references/traps/google-workspace-traps.md`, `references/traps/salesforce-crm-soql-traps.md`, `references/traps/untrusted-content-and-pii.md`).

Bundled baseline rubrics:
- `references/baselines/deal-desk-approval-baseline.md`
- `references/baselines/itsm-sla-severity-baseline.md`

Bundled API and analytical trap guides:
- `references/traps/absent-is-not-zero.md`
- `references/traps/google-workspace-traps.md`
- `references/traps/salesforce-crm-soql-traps.md`
- `references/traps/untrusted-content-and-pii.md`

Using persistent `pyrepl`:

```python
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/executive-briefing-ops"),
            Path("skills/user-skills/executive-briefing-ops"),
            Path("skills/daily-executive-briefing"),
            Path("skills/user-skills/daily-executive-briefing"),
            Path("."),
        )
        if (p / "scripts/agenda_commitment_tracker.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/agenda_commitment_tracker.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.enterprise_io import read_xlsx_workbook, read_docx, read_csv_tsv, read_json_or_jsonl
from scripts.agenda_commitment_tracker import analyze, render_markdown

cfg_path = SKILL_DIR / "references" / "config.json"

# If headers differ from canonical names, inspect in Python first and normalize:
# wb = read_xlsx_workbook(Path("customer_export.xlsx"))
# print({tab: (list(rows[0].keys()) if rows else []) for tab, rows in wb.items()})
# payload = { ...shape customer columns into canonical keys... }
payload = source_path_or_dict
result = analyze(payload, config=cfg_path)
print(render_markdown(result))
```

CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/executive-briefing-ops skills/user-skills/executive-briefing-ops skills/*; do
  [ -f "$d/scripts/agenda_commitment_tracker.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/agenda_commitment_tracker.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/transcript_action_extractor.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/dossier_synthesizer.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/agenda_commitment_tracker.py" --help
python3 "$SKILL_DIR/scripts/transcript_action_extractor.py" --help
python3 "$SKILL_DIR/scripts/dossier_synthesizer.py" --help
```

## Step 4 — Write-Back Governance (`Auto-Guardian`) & Conversational Scheduling (`schedule_task`)

- **Read-Only & Local Draft Actions:** Connector reads via `remote_cli mcp`, file inspection via `view_file`, `pyrepl` scoring, interactive Canvas (`emit_a2ui`), and saving local deliverables via `write_to_file` run without mutating external systems.
- **Agent Gateway (`Auto-Guardian`) & Explicit User Confirmation:** External write-backs executed via authorized connectors are protected by Agent Gateway (`Auto-Guardian`) and require explicit user confirmation prior to execution:
  - Sending executive follow-up emails or stakeholder outreach via Gmail or Outlook
  - Modifying, rescheduling, or declining multi-attendee Calendar events
  - Posting meeting action summaries to shared Slack or Microsoft Teams channels
- **Code-Enforced Python Guardrails (`scripts/*.py`):**
  - Untrusted external email/transcript instruction quarantine before action extraction
  - Strict pagination/truncation propagation preventing silent omission of afternoon events
  - Time-zone normalization and double-booked conflict interval overlap math
- **Conversational Scheduling (`schedule_task`):** Only when the user asks to automate recurring monitoring, invoke `schedule_task(title="Weekday Executive Morning Briefing", cron_expression="30 6 * * 1-5", time_zone="UTC", instruction="Build the weekday morning executive briefing using scripts/agenda_commitment_tracker.py. Detect overlapping meetings, missing pre-read documents, back-to-back fatigue stretches, and overdue action commitments, and save a private Google Doc brief without sending any external emails.")`.
