---
name: executive-briefing-ops
description: "Prepares daily executive briefings with calendar conflict and commitment tracking, extracts structured action/decision packs from meeting transcripts, and synthesizes multi-signal stakeholder account dossiers. Use when routing or executing Executive Briefing & Chief of Staff Ops workflows (daily-executive-briefing, meeting-to-execution-pack, stakeholder-account-prep). Don't use for unrelated domains outside executive-briefing-ops or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# Executive Briefing & Chief of Staff Ops (Department Bundle)

Prepares daily executive briefings with calendar conflict and commitment tracking, extracts structured action/decision packs from meeting transcripts, and synthesizes multi-signal stakeholder account dossiers.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `daily-executive-briefing` | [daily-executive-briefing.md](references/workflows/daily-executive-briefing.md) | [agenda_commitment_tracker.py](scripts/agenda_commitment_tracker.py) | Reconciles calendar events, priority threads, and open action items into time-boxed prep blocks with conflict and overdue alerts. |
| `meeting-to-execution-pack` | [meeting-to-execution-pack.md](references/workflows/meeting-to-execution-pack.md) | [transcript_action_extractor.py](scripts/transcript_action_extractor.py) | Extracts owner-assigned commitments, decision logs, unresolved blockers, and repeat carryovers from meeting transcripts. |
| `stakeholder-account-prep` | [stakeholder-account-prep.md](references/workflows/stakeholder-account-prep.md) | [dossier_synthesizer.py](scripts/dossier_synthesizer.py) | Aggregates account ARR milestones, open escalations, executive touchpoints, and renewal countdowns into scored stakeholder dossiers. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `calendar_and_mail_context` | google_calendar_api, gmail_api, microsoft_graph_calendar_mail | Google Calendar, Gmail, Google Meet, Google Docs (Inspect Calendar event descriptions and Google Meet transcript Docs in the Executive Prep folder.) | .json, .csv, .md, .txt |
| `account_and_escalation_context` | salesforce_soql_api | Google Sheets, Google Drive (Locate Account Health Tracker Sheet in Executive Shared Drive.) | .json, .csv |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [deal-desk-approval-baseline.md](references/baselines/deal-desk-approval-baseline.md)
- [itsm-sla-severity-baseline.md](references/baselines/itsm-sla-severity-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Because runtime shells start in `/workspace` while bundles and individual skills unpack under `skills/<slug>/` or `skills/user-skills/<slug>/`, always resolve `SKILL_DIR` dynamically before importing scripts or reading references.

- **Zero-dependency enterprise ingestion:** Every engine uses [enterprise_io.py](scripts/enterprise_io.py) to parse multi-tab `.xlsx`/`.xlsm` workbooks (1900/1904 dates, inline/shared strings, formula cached values), `.docx` documents (sections, headings, embedded tables, footnotes/comments), UTF-8 BOM `.csv`/`.tsv`, `.json`, and `.jsonl` directly from `--input` without needing `openpyxl` or `python-docx`. Pass `--sheet <TabName>` (or `sheet='...'` in `analyze()`) to analyze a specific worksheet.

Using persistent `pyrepl`:

```python
import json
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/executive-briefing-ops"),
            Path("skills/user-skills/executive-briefing-ops"),
            Path("skills/daily-executive-briefing"),
            Path("skills/user-skills/daily-executive-briefing"),
            Path("."),
        )
        if (p / "scripts/agenda_commitment_tracker.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/agenda_commitment_tracker.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.agenda_commitment_tracker import analyze, render_markdown

cfg = json.loads((SKILL_DIR / "references" / "config.json").read_text(encoding="utf-8"))
# Pass loaded Mode A/B/C payload in RAM without flooding prompt tokens:
# result = analyze(payload, config=SKILL_DIR / "references" / "config.json")
# print(render_markdown(result))
```

Using CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/executive-briefing-ops skills/user-skills/executive-briefing-ops skills/*; do
  [ -f "$d/scripts/agenda_commitment_tracker.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/agenda_commitment_tracker.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/transcript_action_extractor.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/dossier_synthesizer.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
# Or pass .xlsx / .docx / .csv directly (optional --sheet "TabName"):
# python3 "$SKILL_DIR/scripts/agenda_commitment_tracker.py" --input workbook.xlsx --config "$SKILL_DIR/references/config.json" --format markdown
# Inspect CLI flags directly:
python3 "$SKILL_DIR/scripts/agenda_commitment_tracker.py" --help
python3 "$SKILL_DIR/scripts/transcript_action_extractor.py" --help
python3 "$SKILL_DIR/scripts/dossier_synthesizer.py" --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [google-workspace-traps.md](references/traps/google-workspace-traps.md)
- [salesforce-crm-soql-traps.md](references/traps/salesforce-crm-soql-traps.md)
- [untrusted-content-and-pii.md](references/traps/untrusted-content-and-pii.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `calendar_list_events`, `gmail_list_messages`, `meet_read_transcript`, `salesforce_query_account`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `gmail_create_draft`, `docs_create_private_brief`, `calendar_propose_hold_draft`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `gmail_send_message` (scope: `explicit_per_call`) — Sending executive follow-ups or stakeholder emails requires explicit user confirmation.
  - `calendar_update_event` (scope: `explicit_per_call`) — Modifying or declining multi-attendee meetings requires explicit HITL approval.
  - `slack_post_action_summary` (scope: `task_sticky`) — Posting meeting action items into shared channels requires user confirmation.
