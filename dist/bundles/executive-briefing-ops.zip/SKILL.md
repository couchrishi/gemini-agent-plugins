---
name: executive-briefing-ops
description: "Prepares daily executive briefings with calendar conflict and commitment tracking, extracts structured action/decision packs from meeting transcripts, and synthesizes multi-signal stakeholder account dossiers. Use when routing or executing Executive Briefing & Chief of Staff Ops workflows (daily-executive-briefing, meeting-to-execution-pack, stakeholder-account-prep). Don't use for unrelated domains outside executive-briefing-ops or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# Executive Briefing & Chief of Staff Ops (Department Bundle)

Prepares daily executive briefings with calendar conflict and commitment tracking, extracts structured action/decision packs from meeting transcripts, and synthesizes multi-signal stakeholder account dossiers.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `daily-executive-briefing` | [daily-executive-briefing.md](references/workflows/daily-executive-briefing.md) | [agenda_commitment_tracker.py](scripts/agenda_commitment_tracker.py) | Reconciles calendar events, priority threads, and open action items into time-boxed prep blocks with conflict and overdue alerts. |
| `meeting-to-execution-pack` | [meeting-to-execution-pack.md](references/workflows/meeting-to-execution-pack.md) | [transcript_action_extractor.py](scripts/transcript_action_extractor.py) | Extracts owner-assigned commitments, decision logs, unresolved blockers, and repeat carryovers from meeting transcripts. |
| `stakeholder-account-prep` | [stakeholder-account-prep.md](references/workflows/stakeholder-account-prep.md) | [dossier_synthesizer.py](scripts/dossier_synthesizer.py) | Aggregates account ARR milestones, open escalations, executive touchpoints, and renewal countdowns into scored stakeholder dossiers. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `calendar_and_mail_context` | google_calendar_api, gmail_api, microsoft_graph_calendar_mail | Google Calendar, Gmail, Google Meet, Google Docs (Inspect Calendar event descriptions and Google Meet transcript Docs in the Executive Prep folder.) | .json, .csv, .md, .txt |
| `account_and_escalation_context` | salesforce_soql_api | Google Sheets, Google Drive (Locate Account Health Tracker Sheet in Executive Shared Drive.) | .json, .csv |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [deal-desk-approval-baseline.md](references/baselines/deal-desk-approval-baseline.md)
- [itsm-sla-severity-baseline.md](references/baselines/itsm-sla-severity-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Inspect outputs and optionally visualize metrics with `emit_a2ui` or automate via `schedule_task`.

Using persistent `pyrepl`:

```python
import json
from scripts.agenda_commitment_tracker import analyze
with open('references/config.json') as f:
    cfg = json.load(f)
# Pass loaded Mode A/B/C records in RAM without flooding context tokens
```

Using CLI fallback (`python3`):

```bash
python3 scripts/agenda_commitment_tracker.py --help
python3 scripts/transcript_action_extractor.py --help
python3 scripts/dossier_synthesizer.py --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [google-workspace-traps.md](references/traps/google-workspace-traps.md)
- [salesforce-crm-soql-traps.md](references/traps/salesforce-crm-soql-traps.md)
- [untrusted-content-and-pii.md](references/traps/untrusted-content-and-pii.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `calendar_list_events`, `gmail_list_messages`, `meet_read_transcript`, `salesforce_query_account`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `gmail_create_draft`, `docs_create_private_brief`, `calendar_propose_hold_draft`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `gmail_send_message` (scope: `explicit_per_call`) — Sending executive follow-ups or stakeholder emails requires explicit user confirmation.
  - `calendar_update_event` (scope: `explicit_per_call`) — Modifying or declining multi-attendee meetings requires explicit HITL approval.
  - `slack_post_action_summary` (scope: `task_sticky`) — Posting meeting action items into shared channels requires user confirmation.
