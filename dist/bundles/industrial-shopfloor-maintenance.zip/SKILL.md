---
name: industrial-shopfloor-maintenance
description: "Optimizes critical spare-part safety stocks and reorder points via censored MTBF reliability modeling, builds 80/20 scrap defect Paretos with CapEx payback evaluation, and enforces strict EHS Permit-to-Work LOTO and gas-test safety gates. Use when routing or executing Industrial Shopfloor Reliability, Quality & EHS Safety workflows (asset-reliability-spares-planner, quality-capex-rca-copilot, ehs-safety-permit-auditor). Don't use for unrelated domains outside industrial-shopfloor-maintenance or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# Industrial Shopfloor Reliability, Quality & EHS Safety (Department Bundle)

Optimizes critical spare-part safety stocks and reorder points via censored MTBF reliability modeling, builds 80/20 scrap defect Paretos with CapEx payback evaluation, and enforces strict EHS Permit-to-Work LOTO and gas-test safety gates.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `asset-reliability-spares-planner` | [asset-reliability-spares-planner.md](references/workflows/asset-reliability-spares-planner.md) | [mtbf_spares_optimizer.py](scripts/mtbf_spares_optimizer.py) | Calculates right-censored MTBF, lead-time demand, safety stock, Reorder Point (ROP), and critical stockout expedite POs. |
| `quality-capex-rca-copilot` | [quality-capex-rca-copilot.md](references/workflows/quality-capex-rca-copilot.md) | [defect_pareto_correlator.py](scripts/defect_pareto_correlator.py) | Builds 80/20 manufacturing scrap cost Paretos, isolates >=2x anomalous supplier lots, and computes CapEx payback hurdles. |
| `ehs-safety-permit-auditor` | [ehs-safety-permit-auditor.md](references/workflows/ehs-safety-permit-auditor.md) | [hse_permit_checker.py](scripts/hse_permit_checker.py) | Enforces zero-compromise LOTO isolation, confined-space O2 (19.5-23.5%), 0% LEL gas freshness, fire watch, and worker certification checks. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `cmms_qms_ehs_systems` | sap_odata_api, bigquery_sql_api | Google Sheets, Google Docs, Google Drive (Read Critical Spares Inventory Sheets, QMS Scrap Logs, and Daily PTW Safety Logs in Plant Ops Shared Drives.) | .json, .csv |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [finance-materiality-baseline.md](references/baselines/finance-materiality-baseline.md)
- [itsm-sla-severity-baseline.md](references/baselines/itsm-sla-severity-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Inspect outputs and optionally visualize metrics with `emit_a2ui` or automate via `schedule_task`.

Using persistent `pyrepl`:

```python
import json
from scripts.mtbf_spares_optimizer import analyze
with open('references/config.json') as f:
    cfg = json.load(f)
# Pass loaded Mode A/B/C records in RAM without flooding context tokens
```

Using CLI fallback (`python3`):

```bash
python3 scripts/mtbf_spares_optimizer.py --help
python3 scripts/defect_pareto_correlator.py --help
python3 scripts/hse_permit_checker.py --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [bigquery-sap-erp-traps.md](references/traps/bigquery-sap-erp-traps.md)
- [chain-denominator-seams.md](references/traps/chain-denominator-seams.md)
- [servicenow-jira-itsm-traps.md](references/traps/servicenow-jira-itsm-traps.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `sap_read_maintenance_history`, `bigquery_query_qms_scrap`, `ehs_read_ptw_forms`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `docs_create_capex_request`, `sheets_draft_reorder_requisition`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `sap_create_spares_pr` (scope: `explicit_per_call`) — Releasing spare parts purchase requisitions requires Plant Maintenance Manager approval.
  - `ehs_authorize_permit_to_work` (scope: `explicit_per_call`) — Signing live Permit-to-Work authorizations always requires a certified EHS Area Authority on-site.
