---
name: industrial-shopfloor-maintenance
description: "Optimizes critical spare-part safety stocks and reorder points via censored MTBF reliability modeling, builds 80/20 scrap defect Paretos with CapEx payback evaluation, and enforces strict EHS Permit-to-Work LOTO and gas-test safety gates. Use when routing or executing Industrial Shopfloor Reliability, Quality & EHS Safety workflows (asset-reliability-spares-planner, quality-capex-rca-copilot, ehs-safety-permit-auditor). Don't use for unrelated domains outside industrial-shopfloor-maintenance or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# Industrial Shopfloor Reliability, Quality & EHS Safety (Department Bundle)

Optimizes critical spare-part safety stocks and reorder points via censored MTBF reliability modeling, builds 80/20 scrap defect Paretos with CapEx payback evaluation, and enforces strict EHS Permit-to-Work LOTO and gas-test safety gates.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `asset-reliability-spares-planner` | [asset-reliability-spares-planner.md](references/workflows/asset-reliability-spares-planner.md) | [mtbf_spares_optimizer.py](scripts/mtbf_spares_optimizer.py) | Calculates right-censored MTBF, lead-time demand, safety stock, Reorder Point (ROP), and critical stockout expedite POs. |
| `quality-capex-rca-copilot` | [quality-capex-rca-copilot.md](references/workflows/quality-capex-rca-copilot.md) | [defect_pareto_correlator.py](scripts/defect_pareto_correlator.py) | Builds 80/20 manufacturing scrap cost Paretos, isolates >=2x anomalous supplier lots, and computes CapEx payback hurdles. |
| `ehs-safety-permit-auditor` | [ehs-safety-permit-auditor.md](references/workflows/ehs-safety-permit-auditor.md) | [hse_permit_checker.py](scripts/hse_permit_checker.py) | Enforces zero-compromise LOTO isolation, confined-space O2 (19.5-23.5%), 0% LEL gas freshness, fire watch, and worker certification checks. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `cmms_qms_ehs_systems` | sap_odata_api, bigquery_sql_api | Google Sheets, Google Docs, Google Drive (Read Critical Spares Inventory Sheets, QMS Scrap Logs, and Daily PTW Safety Logs in Plant Ops Shared Drives.) | .json, .csv |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [finance-materiality-baseline.md](references/baselines/finance-materiality-baseline.md)
- [itsm-sla-severity-baseline.md](references/baselines/itsm-sla-severity-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Because runtime shells start in `/workspace` while bundles and individual skills unpack under `skills/<slug>/` or `skills/user-skills/<slug>/`, always resolve `SKILL_DIR` dynamically before importing scripts or reading references.

- **Zero-dependency enterprise ingestion:** Every engine uses [enterprise_io.py](scripts/enterprise_io.py) to parse multi-tab `.xlsx`/`.xlsm` workbooks (1900/1904 dates, inline/shared strings, formula cached values), `.docx` documents (sections, headings, embedded tables, footnotes/comments), UTF-8 BOM `.csv`/`.tsv`, `.json`, and `.jsonl` directly from `--input` without needing `openpyxl` or `python-docx`. Pass `--sheet <TabName>` (or `sheet='...'` in `analyze()`) to analyze a specific worksheet.

Using persistent `pyrepl`:

```python
import json
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/industrial-shopfloor-maintenance"),
            Path("skills/user-skills/industrial-shopfloor-maintenance"),
            Path("skills/asset-reliability-spares-planner"),
            Path("skills/user-skills/asset-reliability-spares-planner"),
            Path("."),
        )
        if (p / "scripts/mtbf_spares_optimizer.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/mtbf_spares_optimizer.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.mtbf_spares_optimizer import analyze, render_markdown

cfg = json.loads((SKILL_DIR / "references" / "config.json").read_text(encoding="utf-8"))
# Pass loaded Mode A/B/C payload in RAM without flooding prompt tokens:
# result = analyze(payload, config=SKILL_DIR / "references" / "config.json")
# print(render_markdown(result))
```

Using CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/industrial-shopfloor-maintenance skills/user-skills/industrial-shopfloor-maintenance skills/*; do
  [ -f "$d/scripts/mtbf_spares_optimizer.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/mtbf_spares_optimizer.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/defect_pareto_correlator.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/hse_permit_checker.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
# Or pass .xlsx / .docx / .csv directly (optional --sheet "TabName"):
# python3 "$SKILL_DIR/scripts/mtbf_spares_optimizer.py" --input workbook.xlsx --config "$SKILL_DIR/references/config.json" --format markdown
# Inspect CLI flags directly:
python3 "$SKILL_DIR/scripts/mtbf_spares_optimizer.py" --help
python3 "$SKILL_DIR/scripts/defect_pareto_correlator.py" --help
python3 "$SKILL_DIR/scripts/hse_permit_checker.py" --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [bigquery-sap-erp-traps.md](references/traps/bigquery-sap-erp-traps.md)
- [chain-denominator-seams.md](references/traps/chain-denominator-seams.md)
- [servicenow-jira-itsm-traps.md](references/traps/servicenow-jira-itsm-traps.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `sap_read_maintenance_history`, `bigquery_query_qms_scrap`, `ehs_read_ptw_forms`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `docs_create_capex_request`, `sheets_draft_reorder_requisition`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `sap_create_spares_pr` (scope: `explicit_per_call`) — Releasing spare parts purchase requisitions requires Plant Maintenance Manager approval.
  - `ehs_authorize_permit_to_work` (scope: `explicit_per_call`) — Signing live Permit-to-Work authorizations always requires a certified EHS Area Authority on-site.
