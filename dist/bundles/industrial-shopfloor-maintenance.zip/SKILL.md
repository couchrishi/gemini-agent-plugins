---
name: industrial-shopfloor-maintenance
description: "Optimizes critical spare-part safety stocks and reorder points via censored MTBF reliability modeling, builds 80/20 scrap defect Paretos with CapEx payback evaluation, and enforces strict EHS Permit-to-Work LOTO and gas-test safety gates. Use when routing or executing Industrial Shopfloor Reliability, Quality & EHS Safety workflows (asset-reliability-spares-planner, quality-capex-rca-copilot, ehs-safety-permit-auditor). Don't use for unrelated domains outside industrial-shopfloor-maintenance or automated external mutations without explicit user confirmation."
created_by: gemini-agent-plugins
---

# Industrial Shopfloor Reliability, Quality & EHS Safety (Department Bundle)

Optimizes critical spare-part safety stocks and reorder points via censored MTBF reliability modeling, builds 80/20 scrap defect Paretos with CapEx payback evaluation, and enforces strict EHS Permit-to-Work LOTO and gas-test safety gates.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `asset-reliability-spares-planner` | `references/workflows/asset-reliability-spares-planner.md` | `scripts/mtbf_spares_optimizer.py` | Calculates right-censored MTBF, lead-time demand, safety stock, Reorder Point (ROP), and critical stockout expedite POs. |
| `quality-capex-rca-copilot` | `references/workflows/quality-capex-rca-copilot.md` | `scripts/defect_pareto_correlator.py` | Builds 80/20 manufacturing scrap cost Paretos, isolates >=2x anomalous supplier lots, and computes CapEx payback hurdles. |
| `ehs-safety-permit-auditor` | `references/workflows/ehs-safety-permit-auditor.md` | `scripts/hse_permit_checker.py` | Enforces zero-compromise LOTO isolation, confined-space O2 (19.5-23.5%), 0% LEL gas freshness, fire watch, and worker certification checks. |

## Step 1 — Fetch Data via Live `/work` Connectors or Attached Files

Probe enabled Gemini Enterprise connectors first before falling back to user-attached exports:

- **Built-in Managed 1P Connectors:** `BigQuery`, `Google Drive`, `Google Sheets`, `Google Docs`.
- **Optional Customer BYO-MCP Servers:** `SAP PM / Shopfloor Historian & EHS Permit MCP server` (discover exposed tools via `remote_cli mcp <connector> list-tools`).
- **Fetch Guidance:** Extract equipment work-order MTBF logs, spares inventory balances, QMS scrap batches, and EHS confined-space permit readings from BigQuery or customer SAP PM / Historian MCP servers via remote_cli mcp before Python safety and optimization runs.
- **Connected Docs & Attached File Fallback:** Fetch Google Docs (`includeTabsContent=true`), Google Sheets (`UNFORMATTED_VALUE`), Shared Drives (`supportsAllDrives=true`), and SharePoint/OneDrive workbooks (`@odata.nextLink`), or read chat-attached `.xlsx`, `.docx`, `.csv`, `.tsv`, `.json`, and `.jsonl` snapshots via `view_file` and `scripts/enterprise_io.py`.

## Step 2 — Inspect & Shape Custom Customer Fields in `pyrepl`

Customer exports and live connector responses often use custom tab names or column headers. Check the matching workflow guide from the Workflow Router Matrix above for canonical keys and inspect the real source shape in `pyrepl` before computing:

- **Inspect Real Headers & Shape:** Read attached files via `scripts/enterprise_io.py` (`read_xlsx_workbook`, `read_docx`, `read_csv_tsv`, `read_json_or_jsonl`) or inspect connector JSON keys directly in `pyrepl` so you see actual tab names, headers, and sample rows first.
- **Normalize in Python (`payload`):** Shape messy customer headers or nested JSON objects in 5-10 lines of Python into a canonical `payload` dict and call `analyze(payload, config=cfg_path)` (pass file paths directly when headers already match canonical names). Call `ask_question` only when two source columns remain genuinely ambiguous.

## Step 3 — Run Deterministic Python Engine in `pyrepl` (or CLI)

1. Read `references/config.json` using `view_file` and check `org_configured`.
2. When `org_configured` is `false`, apply the bundled starter rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`
3. Resolve `SKILL_DIR` dynamically under `/workspace/skills/` so both `pyrepl` and shell CLI invocations work regardless of install root, and enforce every bundled baseline (`references/baselines/finance-materiality-baseline.md`, `references/baselines/itsm-sla-severity-baseline.md`) and trap sheet (`references/traps/absent-is-not-zero.md`, `references/traps/bigquery-sap-erp-traps.md`, `references/traps/chain-denominator-seams.md`, `references/traps/servicenow-jira-itsm-traps.md`).

Bundled baseline rubrics:
- `references/baselines/finance-materiality-baseline.md`
- `references/baselines/itsm-sla-severity-baseline.md`

Bundled API and analytical trap guides:
- `references/traps/absent-is-not-zero.md`
- `references/traps/bigquery-sap-erp-traps.md`
- `references/traps/chain-denominator-seams.md`
- `references/traps/servicenow-jira-itsm-traps.md`

Using persistent `pyrepl`:

```python
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/industrial-shopfloor-maintenance"),
            Path("skills/user-skills/industrial-shopfloor-maintenance"),
            Path("skills/asset-reliability-spares-planner"),
            Path("skills/user-skills/asset-reliability-spares-planner"),
            Path("."),
        )
        if (p / "scripts/mtbf_spares_optimizer.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/mtbf_spares_optimizer.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.enterprise_io import read_xlsx_workbook, read_docx, read_csv_tsv, read_json_or_jsonl
from scripts.mtbf_spares_optimizer import analyze, render_markdown

cfg_path = SKILL_DIR / "references" / "config.json"

# If headers differ from canonical names, inspect in Python first and normalize:
# wb = read_xlsx_workbook(Path("customer_export.xlsx"))
# print({tab: (list(rows[0].keys()) if rows else []) for tab, rows in wb.items()})
# payload = { ...shape customer columns into canonical keys... }
payload = source_path_or_dict
result = analyze(payload, config=cfg_path)
print(render_markdown(result))
```

CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/industrial-shopfloor-maintenance skills/user-skills/industrial-shopfloor-maintenance skills/*; do
  [ -f "$d/scripts/mtbf_spares_optimizer.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/mtbf_spares_optimizer.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/defect_pareto_correlator.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/hse_permit_checker.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/mtbf_spares_optimizer.py" --help
python3 "$SKILL_DIR/scripts/defect_pareto_correlator.py" --help
python3 "$SKILL_DIR/scripts/hse_permit_checker.py" --help
```

## Step 4 — Write-Back Governance (`Auto-Guardian`) & Conversational Scheduling (`schedule_task`)

- **Read-Only & Local Draft Actions:** Connector reads via `remote_cli mcp`, file inspection via `view_file`, `pyrepl` scoring, interactive Canvas (`emit_a2ui`), and saving local deliverables via `write_to_file` run without mutating external systems.
- **Agent Gateway (`Auto-Guardian`) & Explicit User Confirmation:** External write-backs executed via authorized connectors are protected by Agent Gateway (`Auto-Guardian`) and require explicit user confirmation prior to execution:
  - Creating spare-parts purchase requisitions in customer SAP PM / ERP MCP
  - Signing or authorizing live Permit-to-Work (LOTO / confined space) clearances in EHS MCP
- **Code-Enforced Python Guardrails (`scripts/*.py`):**
  - Hard STOP_WORK_BLOCKED interlock whenever O2 < 19.5%/> 23.5%, LEL >= 10%, H2S/CO threshold breach, or missing LOTO verification
  - Zero-stock critical asset safety-stock floor and MTBF reorder-point calculation
  - Pareto 80/20 scrap concentration correlation and discounted CapEx payback bounds
- **Conversational Scheduling (`schedule_task`):** Only when the user asks to automate recurring monitoring, invoke `schedule_task(title="Daily Critical Spares ROP Watch", cron_expression="0 6 * * 1-5", time_zone="UTC", instruction="Run the daily critical spare parts ROP check via scripts/mtbf_spares_optimizer.py across plant rotating equipment and flag zero-stock critical assets.")`.
