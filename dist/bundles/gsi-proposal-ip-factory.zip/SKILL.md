---
name: gsi-proposal-ip-factory
description: "Models consulting delivery staffing pyramids and onshore/offshore margin leverage, audits SOW drafts for scope creep phrasing and margin breaches, and matches open project roles to bench consultants. Use when routing or executing GSI Proposal Architecture, SOW Margin & Bench Factory workflows (winning-proposal-architect, sow-scope-margin-auditor, bench-skill-demand-matcher). Don't use for unrelated domains outside gsi-proposal-ip-factory or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# GSI Proposal Architecture, SOW Margin & Bench Factory (Department Bundle)

Models consulting delivery staffing pyramids and onshore/offshore margin leverage, audits SOW drafts for scope creep phrasing and margin breaches, and matches open project roles to bench consultants.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `winning-proposal-architect` | [winning-proposal-architect.md](references/workflows/winning-proposal-architect.md) | [staffing_pyramid_calculator.py](scripts/staffing_pyramid_calculator.py) | Calculates multi-phase effort hours, onshore/offshore leverage ratio, blended bill rate, and gross margin vs SOW floor. |
| `sow-scope-margin-auditor` | [sow-scope-margin-auditor.md](references/workflows/sow-scope-margin-auditor.md) | [sow_margin_linter.py](scripts/sow_margin_linter.py) | Lints SOW drafts for unbounded 'all work required' obligations, missing acceptance criteria, >10d deemed acceptance, and margin floors. |
| `bench-skill-demand-matcher` | [bench-skill-demand-matcher.md](references/workflows/bench-skill-demand-matcher.md) | [talent_bench_matcher.py](scripts/talent_bench_matcher.py) | Matches open project seats against bench skills, roll-off dates, location overlap, and target role margin. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `psa_and_proposal_assets` | google_drive_api, microsoft_graph_sharepoint | Google Sheets, Google Docs, Google Slides, Google Drive (Read Pricing Pyramid Sheets (UNFORMATTED_VALUE), Draft SOW Docs, and Bench Roster Sheets in Delivery Shared Drives.) | .json, .csv |
| `bench_talent_roster` | workday_raas_api | Google Sheets, Google Drive (Read Weekly Bench & Roll-off Tracker Sheets in Resource Management Drives.) | .json, .csv |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [commercial-contract-baseline.md](references/baselines/commercial-contract-baseline.md)
- [deal-desk-approval-baseline.md](references/baselines/deal-desk-approval-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Because runtime shells start in `/workspace` while bundles and individual skills unpack under `skills/<slug>/` or `skills/user-skills/<slug>/`, always resolve `SKILL_DIR` dynamically before importing scripts or reading references.

- **Zero-dependency enterprise ingestion:** Every engine uses [enterprise_io.py](scripts/enterprise_io.py) to parse multi-tab `.xlsx`/`.xlsm` workbooks (1900/1904 dates, inline/shared strings, formula cached values), `.docx` documents (sections, headings, embedded tables, footnotes/comments), UTF-8 BOM `.csv`/`.tsv`, `.json`, and `.jsonl` directly from `--input` without needing `openpyxl` or `python-docx`. Pass `--sheet <TabName>` (or `sheet='...'` in `analyze()`) to analyze a specific worksheet.

Using persistent `pyrepl`:

```python
import json
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/gsi-proposal-ip-factory"),
            Path("skills/user-skills/gsi-proposal-ip-factory"),
            Path("skills/winning-proposal-architect"),
            Path("skills/user-skills/winning-proposal-architect"),
            Path("."),
        )
        if (p / "scripts/staffing_pyramid_calculator.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/staffing_pyramid_calculator.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.staffing_pyramid_calculator import analyze, render_markdown

cfg = json.loads((SKILL_DIR / "references" / "config.json").read_text(encoding="utf-8"))
# Pass loaded Mode A/B/C payload in RAM without flooding prompt tokens:
# result = analyze(payload, config=SKILL_DIR / "references" / "config.json")
# print(render_markdown(result))
```

Using CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/gsi-proposal-ip-factory skills/user-skills/gsi-proposal-ip-factory skills/*; do
  [ -f "$d/scripts/staffing_pyramid_calculator.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/staffing_pyramid_calculator.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/sow_margin_linter.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/talent_bench_matcher.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
# Or pass .xlsx / .docx / .csv directly (optional --sheet "TabName"):
# python3 "$SKILL_DIR/scripts/staffing_pyramid_calculator.py" --input workbook.xlsx --config "$SKILL_DIR/references/config.json" --format markdown
# Inspect CLI flags directly:
python3 "$SKILL_DIR/scripts/staffing_pyramid_calculator.py" --help
python3 "$SKILL_DIR/scripts/sow_margin_linter.py" --help
python3 "$SKILL_DIR/scripts/talent_bench_matcher.py" --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [chain-denominator-seams.md](references/traps/chain-denominator-seams.md)
- [google-workspace-traps.md](references/traps/google-workspace-traps.md)
- [sharepoint-onedrive-kql-traps.md](references/traps/sharepoint-onedrive-kql-traps.md)
- [workday-hris-traps.md](references/traps/workday-hris-traps.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `drive_read_sow_draft`, `workday_read_bench_roster`, `sheets_read_unformatted`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `docs_create_proposal_draft`, `slides_draft_solution_deck`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `psa_submit_sow_for_bid_review` (scope: `explicit_per_call`) — Submitting below-margin or scope-risk SOWs requires Practice VP and Finance approval.
  - `psa_assign_bench_resource` (scope: `task_sticky`) — Allocating consultants to client projects requires Resource Manager confirmation.
