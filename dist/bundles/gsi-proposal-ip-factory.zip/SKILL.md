---
name: gsi-proposal-ip-factory
description: "Models consulting delivery staffing pyramids and onshore/offshore margin leverage, audits SOW drafts for scope creep phrasing and margin breaches, and matches open project roles to bench consultants. Use when routing or executing GSI Proposal Architecture, SOW Margin & Bench Factory workflows (winning-proposal-architect, sow-scope-margin-auditor, bench-skill-demand-matcher). Don't use for unrelated domains outside gsi-proposal-ip-factory or automated external mutations without explicit user confirmation."
created_by: gemini-agent-plugins
---

# GSI Proposal Architecture, SOW Margin & Bench Factory (Department Bundle)

Models consulting delivery staffing pyramids and onshore/offshore margin leverage, audits SOW drafts for scope creep phrasing and margin breaches, and matches open project roles to bench consultants.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `winning-proposal-architect` | `references/workflows/winning-proposal-architect.md` | `scripts/staffing_pyramid_calculator.py` | Calculates multi-phase effort hours, onshore/offshore leverage ratio, blended bill rate, and gross margin vs SOW floor. |
| `sow-scope-margin-auditor` | `references/workflows/sow-scope-margin-auditor.md` | `scripts/sow_margin_linter.py` | Lints SOW drafts for unbounded 'all work required' obligations, missing acceptance criteria, >10d deemed acceptance, and margin floors. |
| `bench-skill-demand-matcher` | `references/workflows/bench-skill-demand-matcher.md` | `scripts/talent_bench_matcher.py` | Matches open project seats against bench skills, roll-off dates, location overlap, and target role margin. |

## Step 1 — Fetch Data via Live `/work` Connectors or Attached Files

Probe enabled Gemini Enterprise connectors first before falling back to user-attached exports:

- **Built-in Managed 1P Connectors:** `Google Drive`, `Google Docs`, `Google Sheets`, `Google Slides`, `Microsoft 365 (SharePoint, OneDrive, Outlook, Teams)`.
- **Optional Customer BYO-MCP Servers:** `Workday HRIS & PSA Staffing MCP server` (discover exposed tools via `remote_cli mcp <connector> list-tools`).
- **Fetch Guidance:** Pull rate cards, SOW milestone drafts, and RFP requirements from Google Drive/SharePoint plus consultant skill inventories and clearance eligibility from Workday/PSA MCP servers via remote_cli mcp before Python staffing and margin checks.
- **Connected Docs & Attached File Fallback:** Fetch Google Docs (`includeTabsContent=true`), Google Sheets (`UNFORMATTED_VALUE`), Shared Drives (`supportsAllDrives=true`), and SharePoint/OneDrive workbooks (`@odata.nextLink`), or read chat-attached `.xlsx`, `.docx`, `.csv`, `.tsv`, `.json`, and `.jsonl` snapshots via `view_file` and `scripts/enterprise_io.py`.

## Step 2 — Inspect & Shape Custom Customer Fields in `pyrepl`

Customer exports and live connector responses often use custom tab names or column headers. Check the matching workflow guide from the Workflow Router Matrix above for canonical keys and inspect the real source shape in `pyrepl` before computing:

- **Inspect Real Headers & Shape:** Read attached files via `scripts/enterprise_io.py` (`read_xlsx_workbook`, `read_docx`, `read_csv_tsv`, `read_json_or_jsonl`) or inspect connector JSON keys directly in `pyrepl` so you see actual tab names, headers, and sample rows first.
- **Normalize in Python (`payload`):** Shape messy customer headers or nested JSON objects in 5-10 lines of Python into a canonical `payload` dict and call `analyze(payload, config=cfg_path)` (pass file paths directly when headers already match canonical names). Call `ask_question` only when two source columns remain genuinely ambiguous.

## Step 3 — Run Deterministic Python Engine in `pyrepl` (or CLI)

1. Read `references/config.json` using `view_file` and check `org_configured`.
2. When `org_configured` is `false`, apply the bundled starter rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`
3. Resolve `SKILL_DIR` dynamically under `/workspace/skills/` so both `pyrepl` and shell CLI invocations work regardless of install root, and enforce every bundled baseline (`references/baselines/commercial-contract-baseline.md`, `references/baselines/deal-desk-approval-baseline.md`) and trap sheet (`references/traps/absent-is-not-zero.md`, `references/traps/chain-denominator-seams.md`, `references/traps/google-workspace-traps.md`, `references/traps/sharepoint-onedrive-kql-traps.md`, `references/traps/workday-hris-traps.md`).

Bundled baseline rubrics:
- `references/baselines/commercial-contract-baseline.md`
- `references/baselines/deal-desk-approval-baseline.md`

Bundled API and analytical trap guides:
- `references/traps/absent-is-not-zero.md`
- `references/traps/chain-denominator-seams.md`
- `references/traps/google-workspace-traps.md`
- `references/traps/sharepoint-onedrive-kql-traps.md`
- `references/traps/workday-hris-traps.md`

Using persistent `pyrepl`:

```python
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/gsi-proposal-ip-factory"),
            Path("skills/user-skills/gsi-proposal-ip-factory"),
            Path("skills/winning-proposal-architect"),
            Path("skills/user-skills/winning-proposal-architect"),
            Path("."),
        )
        if (p / "scripts/staffing_pyramid_calculator.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/staffing_pyramid_calculator.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.enterprise_io import read_xlsx_workbook, read_docx, read_csv_tsv, read_json_or_jsonl
from scripts.staffing_pyramid_calculator import analyze, render_markdown

cfg_path = SKILL_DIR / "references" / "config.json"

# If headers differ from canonical names, inspect in Python first and normalize:
# wb = read_xlsx_workbook(Path("customer_export.xlsx"))
# print({tab: (list(rows[0].keys()) if rows else []) for tab, rows in wb.items()})
# payload = { ...shape customer columns into canonical keys... }
payload = source_path_or_dict
result = analyze(payload, config=cfg_path)
print(render_markdown(result))
```

CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/gsi-proposal-ip-factory skills/user-skills/gsi-proposal-ip-factory skills/*; do
  [ -f "$d/scripts/staffing_pyramid_calculator.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/staffing_pyramid_calculator.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/sow_margin_linter.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/talent_bench_matcher.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/staffing_pyramid_calculator.py" --help
python3 "$SKILL_DIR/scripts/sow_margin_linter.py" --help
python3 "$SKILL_DIR/scripts/talent_bench_matcher.py" --help
```

## Step 4 — Write-Back Governance (`Auto-Guardian`) & Conversational Scheduling (`schedule_task`)

- **Read-Only & Local Draft Actions:** Connector reads via `remote_cli mcp`, file inspection via `view_file`, `pyrepl` scoring, interactive Canvas (`emit_a2ui`), and saving local deliverables via `write_to_file` run without mutating external systems.
- **Agent Gateway (`Auto-Guardian`) & Explicit User Confirmation:** External write-backs executed via authorized connectors are protected by Agent Gateway (`Auto-Guardian`) and require explicit user confirmation prior to execution:
  - Submitting below-margin or high-risk SOW bids for Practice VP / Finance sign-off in PSA MCP
  - Assigning bench consultants or initiating subcontractor requisitions in Workday/PSA MCP
  - Sending client proposal decks or redlined SOWs externally via Gmail or Outlook
- **Code-Enforced Python Guardrails (`scripts/*.py`):**
  - Onshore/offshore leverage ratio, blended cost/bill rate, and hard minimum gross-margin floor guard
  - Mandatory security-clearance and availability window matching before bench allocation
  - Unlimited-revisions and deemed-acceptance SOW legal/margin risk clause flagging
- **Conversational Scheduling (`schedule_task`):** Only when the user asks to automate recurring monitoring, invoke `schedule_task(title="Weekly Bench Utilization Digest", cron_expression="0 8 * * 1", time_zone="UTC", instruction="Run the weekly bench-to-demand skill matching check via scripts/talent_bench_matcher.py and surface unfilled roles needing subcontractor sourcing.")`.
