---
name: erp-procure-to-pay
description: "Reconciles SAP GR/IR clearing imbalances across goods receipts and invoice postings with TCURX scaling, simulates multi-supplier RFx total landed cost under tariff shocks, and rolls up multi-level BOM purchase price variances with cycle detection. Use when routing or executing ERP Procure-to-Pay, GR/IR Clearing & Tariff Cost Engine workflows (gr-ir-clearing-orchestrator, supplier-rfx-tariff-modeler, bom-cost-rollup-variance). Don't use for unrelated domains outside erp-procure-to-pay or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# ERP Procure-to-Pay, GR/IR Clearing & Tariff Cost Engine (Department Bundle)

Reconciles SAP GR/IR clearing imbalances across goods receipts and invoice postings with TCURX scaling, simulates multi-supplier RFx total landed cost under tariff shocks, and rolls up multi-level BOM purchase price variances with cycle detection.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `gr-ir-clearing-orchestrator` | [gr-ir-clearing-orchestrator.md](references/workflows/gr-ir-clearing-orchestrator.md) | [gr_ir_reconciler.py](scripts/gr_ir_reconciler.py) | Reconciles SAP WE goods receipts and RE invoice postings with TCURX currency scaling, SHKZG sign flips, and >60d aging classification. |
| `supplier-rfx-tariff-modeler` | [supplier-rfx-tariff-modeler.md](references/workflows/supplier-rfx-tariff-modeler.md) | [landed_cost_simulator.py](scripts/landed_cost_simulator.py) | Simulates multi-supplier RFx bids across FOB, freight, tariffs, shock scenarios, payment financing, and quality defect penalties. |
| `bom-cost-rollup-variance` | [bom-cost-rollup-variance.md](references/workflows/bom-cost-rollup-variance.md) | [bom_ppv_rollup.py](scripts/bom_ppv_rollup.py) | Explodes multi-level BOMs with scrap factors, guards against circular BOM graphs, and rolls up leaf PPV drivers. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `erp_p2p_and_bom_data` | sap_odata_api, bigquery_sql_api | Google Sheets, Google Drive (Read Procurement GR/IR Aging Sheets, RFx Bid Matrix Sheets, and BOM Cost Rollup tabs in Supply Chain Shared Drives.) | .json, .csv |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [finance-materiality-baseline.md](references/baselines/finance-materiality-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Inspect outputs and optionally visualize metrics with `emit_a2ui` or automate via `schedule_task`.

Using persistent `pyrepl`:

```python
import json
from scripts.gr_ir_reconciler import analyze
with open('references/config.json') as f:
    cfg = json.load(f)
# Pass loaded Mode A/B/C records in RAM without flooding context tokens
```

Using CLI fallback (`python3`):

```bash
python3 scripts/gr_ir_reconciler.py --help
python3 scripts/landed_cost_simulator.py --help
python3 scripts/bom_ppv_rollup.py --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [bigquery-sap-erp-traps.md](references/traps/bigquery-sap-erp-traps.md)
- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [chain-denominator-seams.md](references/traps/chain-denominator-seams.md)
- [untrusted-content-and-pii.md](references/traps/untrusted-content-and-pii.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `sap_read_ekbe_grir`, `sap_read_bom_hierarchy`, `bigquery_query_ppv`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `sheets_write_clearing_proposal`, `docs_create_sourcing_memo`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `sap_execute_mr11_clearing` (scope: `explicit_per_call`) — Executing SAP MR11/F.13 GR/IR clearing postings impacts GL accruals and requires Controller approval.
  - `sap_award_purchase_order` (scope: `explicit_per_call`) — Awarding supplier RFx contracts or modifying standard BOM costs requires Procurement VP sign-off.
