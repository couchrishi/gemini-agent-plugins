---
name: erp-procure-to-pay
description: "Reconciles SAP GR/IR clearing imbalances across goods receipts and invoice postings with TCURX scaling, simulates multi-supplier RFx total landed cost under tariff shocks, and rolls up multi-level BOM purchase price variances with cycle detection. Use when routing or executing ERP Procure-to-Pay, GR/IR Clearing & Tariff Cost Engine workflows (gr-ir-clearing-orchestrator, supplier-rfx-tariff-modeler, bom-cost-rollup-variance). Don't use for unrelated domains outside erp-procure-to-pay or automated external mutations without explicit user confirmation."
created_by: gemini-agent-plugins
---

# ERP Procure-to-Pay, GR/IR Clearing & Tariff Cost Engine (Department Bundle)

Reconciles SAP GR/IR clearing imbalances across goods receipts and invoice postings with TCURX scaling, simulates multi-supplier RFx total landed cost under tariff shocks, and rolls up multi-level BOM purchase price variances with cycle detection.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `gr-ir-clearing-orchestrator` | `references/workflows/gr-ir-clearing-orchestrator.md` | `scripts/gr_ir_reconciler.py` | Reconciles SAP WE goods receipts and RE invoice postings with TCURX currency scaling, SHKZG sign flips, and >60d aging classification. |
| `supplier-rfx-tariff-modeler` | `references/workflows/supplier-rfx-tariff-modeler.md` | `scripts/landed_cost_simulator.py` | Simulates multi-supplier RFx bids across FOB, freight, tariffs, shock scenarios, payment financing, and quality defect penalties. |
| `bom-cost-rollup-variance` | `references/workflows/bom-cost-rollup-variance.md` | `scripts/bom_ppv_rollup.py` | Explodes multi-level BOMs with scrap factors, guards against circular BOM graphs, and rolls up leaf PPV drivers. |

## Step 1 — Fetch Data via Live `/work` Connectors or Attached Files

Probe enabled Gemini Enterprise connectors first before falling back to user-attached exports:

- **Built-in Managed 1P Connectors:** `BigQuery`, `Google Drive`, `Google Sheets`, `Gmail`, `Microsoft 365 (SharePoint, OneDrive, Outlook, Teams)`.
- **Optional Customer BYO-MCP Servers:** `SAP S/4HANA / Oracle ERP & PLM BOM MCP server` (discover exposed tools via `remote_cli mcp <connector> list-tools`).
- **Fetch Guidance:** Extract EKBE PO/GR/IR history tables, multi-level BOM explosions, and supplier RFx bids from BigQuery or customer SAP/Oracle ERP MCP servers (or Drive/SharePoint exports) via remote_cli mcp before running Python cost and clearing engines.
- **Connected Docs & Attached File Fallback:** Fetch Google Docs (`includeTabsContent=true`), Google Sheets (`UNFORMATTED_VALUE`), Shared Drives (`supportsAllDrives=true`), and SharePoint/OneDrive workbooks (`@odata.nextLink`), or read chat-attached `.xlsx`, `.docx`, `.csv`, `.tsv`, `.json`, and `.jsonl` snapshots via `view_file` and `scripts/enterprise_io.py`.

## Step 2 — Inspect & Shape Custom Customer Fields in `pyrepl`

Customer exports and live connector responses often use custom tab names or column headers. Check the matching workflow guide from the Workflow Router Matrix above for canonical keys and inspect the real source shape in `pyrepl` before computing:

- **Inspect Real Headers & Shape:** Read attached files via `scripts/enterprise_io.py` (`read_xlsx_workbook`, `read_docx`, `read_csv_tsv`, `read_json_or_jsonl`) or inspect connector JSON keys directly in `pyrepl` so you see actual tab names, headers, and sample rows first.
- **Normalize in Python (`payload`):** Shape messy customer headers or nested JSON objects in 5-10 lines of Python into a canonical `payload` dict and call `analyze(payload, config=cfg_path)` (pass file paths directly when headers already match canonical names). Call `ask_question` only when two source columns remain genuinely ambiguous.

## Step 3 — Run Deterministic Python Engine in `pyrepl` (or CLI)

1. Read `references/config.json` using `view_file` and check `org_configured`.
2. When `org_configured` is `false`, apply the bundled starter rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`
3. Resolve `SKILL_DIR` dynamically under `/workspace/skills/` so both `pyrepl` and shell CLI invocations work regardless of install root, and enforce every bundled baseline (`references/baselines/finance-materiality-baseline.md`) and trap sheet (`references/traps/bigquery-sap-erp-traps.md`, `references/traps/absent-is-not-zero.md`, `references/traps/chain-denominator-seams.md`, `references/traps/untrusted-content-and-pii.md`).

Bundled baseline rubrics:
- `references/baselines/finance-materiality-baseline.md`

Bundled API and analytical trap guides:
- `references/traps/bigquery-sap-erp-traps.md`
- `references/traps/absent-is-not-zero.md`
- `references/traps/chain-denominator-seams.md`
- `references/traps/untrusted-content-and-pii.md`

Using persistent `pyrepl`:

```python
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/erp-procure-to-pay"),
            Path("skills/user-skills/erp-procure-to-pay"),
            Path("skills/gr-ir-clearing-orchestrator"),
            Path("skills/user-skills/gr-ir-clearing-orchestrator"),
            Path("."),
        )
        if (p / "scripts/gr_ir_reconciler.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/gr_ir_reconciler.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.enterprise_io import read_xlsx_workbook, read_docx, read_csv_tsv, read_json_or_jsonl
from scripts.gr_ir_reconciler import analyze, render_markdown

cfg_path = SKILL_DIR / "references" / "config.json"

# If headers differ from canonical names, inspect in Python first and normalize:
# wb = read_xlsx_workbook(Path("customer_export.xlsx"))
# print({tab: (list(rows[0].keys()) if rows else []) for tab, rows in wb.items()})
# payload = { ...shape customer columns into canonical keys... }
payload = source_path_or_dict
result = analyze(payload, config=cfg_path)
print(render_markdown(result))
```

CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/erp-procure-to-pay skills/user-skills/erp-procure-to-pay skills/*; do
  [ -f "$d/scripts/gr_ir_reconciler.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/gr_ir_reconciler.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/landed_cost_simulator.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/bom_ppv_rollup.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/gr_ir_reconciler.py" --help
python3 "$SKILL_DIR/scripts/landed_cost_simulator.py" --help
python3 "$SKILL_DIR/scripts/bom_ppv_rollup.py" --help
```

## Step 4 — Write-Back Governance (`Auto-Guardian`) & Conversational Scheduling (`schedule_task`)

- **Read-Only & Local Draft Actions:** Connector reads via `remote_cli mcp`, file inspection via `view_file`, `pyrepl` scoring, interactive Canvas (`emit_a2ui`), and saving local deliverables via `write_to_file` run without mutating external systems.
- **Agent Gateway (`Auto-Guardian`) & Explicit User Confirmation:** External write-backs executed via authorized connectors are protected by Agent Gateway (`Auto-Guardian`) and require explicit user confirmation prior to execution:
  - Posting SAP MR11/F.13 GR/IR clearing entries impacting GL accruals via customer ERP MCP
  - Awarding supplier RFx purchase orders or updating standard BOM costs in ERP/PLM
- **Code-Enforced Python Guardrails (`scripts/*.py`):**
  - Prohibition on clearing IR_WITHOUT_GR lines lacking verified physical goods receipt
  - BOM cycle detection blocking circular assembly graphs from cost rollups and compound 1/(1-scrap) yield math
  - TCURX decimal scaling, SHKZG credit reversal handling, and single-source vendor concentration alerts
- **Conversational Scheduling (`schedule_task`):** Only when the user asks to automate recurring monitoring, invoke `schedule_task(title="Daily GR/IR Aging Watch", cron_expression="0 7 * * 1-5", time_zone="UTC", instruction="Execute weekday SAP GR/IR clearing aging check via scripts/gr_ir_reconciler.py to isolate IR_WITHOUT_GR blocks and >60 day accruals.")`.
