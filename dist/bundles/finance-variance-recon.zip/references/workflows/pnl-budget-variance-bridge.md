# Workflow: pnl-budget-variance-bridge

# P&L Budget Variance Bridge

Calculate exact constant-currency vs FX P&L variance bridges across hierarchical GL accounts without summary-row double-counting.

## Three-Mode Connector Degradation

| Mode | Source Path | Execution Guidance |
| :--- | :--- | :--- |
| **Mode A — Live Enterprise Connectors** | `bigquery_sql_api`, `sap_odata_api` | Query GL actuals, budget versions, and period-end exchange rates from BigQuery/ERP marts. |
| **Mode B — Google Workspace Fallback** | `Google Sheets`, `Google Docs`, `Google Drive` | Extract close workbooks via Sheets `UNFORMATTED_VALUE` and commentary Docs in Finance Shared Drives. |
| **Mode C — Direct File Upload** | `.json`, `.csv` | Read uploaded GL trial-balance extracts directly into Python RAM using `view_file`. |

## Org Configuration & Starter Baseline Rule

1. Inspect [config.json](../config.json) with `view_file`.
2. Whenever `org_configured` is `false`, apply [finance-materiality-baseline.md](../baselines/finance-materiality-baseline.md) and stamp the deliverable header verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

## In-Memory Python Execution (`pyrepl` & CLI)

Execute [pnl_variance_engine.py](../../scripts/pnl_variance_engine.py) inside persistent `pyrepl` and optionally visualize bridges with `emit_a2ui`:

```python
from scripts.pnl_variance_engine import analyze, render_markdown

res = analyze("gl_variance.json", config="references/config.json")
print(render_markdown(res))
```

CLI fallback:

```bash
python3 scripts/pnl_variance_engine.py --input gl_variance.json --config references/config.json --format markdown
```

## Enterprise Traps & HITL Confirmation Gate

- Follow [bigquery-sap-erp-traps.md](../traps/bigquery-sap-erp-traps.md), [chain-denominator-seams.md](../traps/chain-denominator-seams.md), [absent-is-not-zero.md](../traps/absent-is-not-zero.md), [google-workspace-traps.md](../traps/google-workspace-traps.md), and [untrusted-content-and-pii.md](../traps/untrusted-content-and-pii.md).
- Always separate `row_type == "summary"` parent rows from leaf rows before summing EBITDA so totals are never doubled.
- Publishing executive close memos or adjusting ERP forecast/journal entries requires explicit user confirmation (HITL).
