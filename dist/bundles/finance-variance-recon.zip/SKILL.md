---
name: finance-variance-recon
description: "Reconciles AP 3-way PO/GR/Invoice matches with SAP TCURX/SHKZG guards and duplicate/bank-change fraud holds, builds constant-currency P&L variance bridges without summary double-counting, and audits AR aging buckets with strict credit-memo isolation. Use when routing or executing Finance Variance, 3-Way Match & AR Reconciliation workflows (ap-three-way-match, pnl-budget-variance-bridge, ar-aging-collections-audit). Don't use for unrelated domains outside finance-variance-recon or automated external mutations without explicit user confirmation."
created_by: gemini-agent-plugins
---

# Finance Variance, 3-Way Match & AR Reconciliation (Department Bundle)

Reconciles AP 3-way PO/GR/Invoice matches with SAP TCURX/SHKZG guards and duplicate/bank-change fraud holds, builds constant-currency P&L variance bridges without summary double-counting, and audits AR aging buckets with strict credit-memo isolation.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `ap-three-way-match` | `references/workflows/ap-three-way-match.md` | `scripts/reconcile_3way.py` | Performs deterministic PO/GR/Invoice 3-way matching with SAP TCURX decimal normalization, SHKZG sign handling, duplicate invoice detection, and bank-change fraud holds. |
| `pnl-budget-variance-bridge` | `references/workflows/pnl-budget-variance-bridge.md` | `scripts/pnl_variance_engine.py` | Computes P&L Actual vs Budget/Forecast variance bridges split by constant-FX vs currency impact while enforcing leaf-vs-summary hierarchy tie-outs. |
| `ar-aging-collections-audit` | `references/workflows/ar-aging-collections-audit.md` | `scripts/aging_bucket_auditor.py` | Buckets open accounts receivable across Current to 90+ days while isolating unapplied credit memos so negative rows never mask delinquent balances. |

## Step 1 — Fetch Data via Live `/work` Connectors or Attached Files

Probe enabled Gemini Enterprise connectors first before falling back to user-attached exports:

- **Built-in Managed 1P Connectors:** `BigQuery`, `Google Drive`, `Google Sheets`, `Google Docs`, `Gmail`, `Microsoft 365 (SharePoint, OneDrive, Outlook, Teams)`.
- **Optional Customer BYO-MCP Servers:** `SAP S/4HANA / Oracle ERP MCP server` (discover exposed tools via `remote_cli mcp <connector> list-tools`).
- **Fetch Guidance:** Pull PO, Goods Receipt, Invoice, GL actual/budget hierarchy, and AR open-item ledgers from BigQuery, Google Sheets, SharePoint, or customer SAP/Oracle ERP MCP servers via remote_cli mcp before running Python reconciliation engines.
- **Connected Docs & Attached File Fallback:** Fetch Google Docs (`includeTabsContent=true`), Google Sheets (`UNFORMATTED_VALUE`), Shared Drives (`supportsAllDrives=true`), and SharePoint/OneDrive workbooks (`@odata.nextLink`), or read chat-attached `.xlsx`, `.docx`, `.csv`, `.tsv`, `.json`, and `.jsonl` snapshots via `view_file` and `scripts/enterprise_io.py`.

## Step 2 — Inspect & Shape Custom Customer Fields in `pyrepl`

Customer exports and live connector responses often use custom tab names or column headers. Check the matching workflow guide from the Workflow Router Matrix above for canonical keys and inspect the real source shape in `pyrepl` before computing:

- **Inspect Real Headers & Shape:** Read attached files via `scripts/enterprise_io.py` (`read_xlsx_workbook`, `read_docx`, `read_csv_tsv`, `read_json_or_jsonl`) or inspect connector JSON keys directly in `pyrepl` so you see actual tab names, headers, and sample rows first.
- **Normalize in Python (`payload`):** Shape messy customer headers or nested JSON objects in 5-10 lines of Python into a canonical `payload` dict and call `analyze(payload, config=cfg_path)` (pass file paths directly when headers already match canonical names). Call `ask_question` only when two source columns remain genuinely ambiguous.

## Step 3 — Run Deterministic Python Engine in `pyrepl` (or CLI)

1. Read `references/config.json` using `view_file` and check `org_configured`.
2. When `org_configured` is `false`, apply the bundled starter rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`
3. Resolve `SKILL_DIR` dynamically under `/workspace/skills/` so both `pyrepl` and shell CLI invocations work regardless of install root, and enforce every bundled baseline (`references/baselines/finance-materiality-baseline.md`) and trap sheet (`references/traps/bigquery-sap-erp-traps.md`, `references/traps/absent-is-not-zero.md`, `references/traps/chain-denominator-seams.md`, `references/traps/google-workspace-traps.md`, `references/traps/untrusted-content-and-pii.md`).

Bundled baseline rubrics:
- `references/baselines/finance-materiality-baseline.md`

Bundled API and analytical trap guides:
- `references/traps/bigquery-sap-erp-traps.md`
- `references/traps/absent-is-not-zero.md`
- `references/traps/chain-denominator-seams.md`
- `references/traps/google-workspace-traps.md`
- `references/traps/untrusted-content-and-pii.md`

Using persistent `pyrepl`:

```python
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/finance-variance-recon"),
            Path("skills/user-skills/finance-variance-recon"),
            Path("skills/ap-three-way-match"),
            Path("skills/user-skills/ap-three-way-match"),
            Path("."),
        )
        if (p / "scripts/reconcile_3way.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/reconcile_3way.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.enterprise_io import read_xlsx_workbook, read_docx, read_csv_tsv, read_json_or_jsonl
from scripts.reconcile_3way import analyze, render_markdown

cfg_path = SKILL_DIR / "references" / "config.json"

# If headers differ from canonical names, inspect in Python first and normalize:
# wb = read_xlsx_workbook(Path("customer_export.xlsx"))
# print({tab: (list(rows[0].keys()) if rows else []) for tab, rows in wb.items()})
# payload = { ...shape customer columns into canonical keys... }
payload = source_path_or_dict
result = analyze(payload, config=cfg_path)
print(render_markdown(result))
```

CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/finance-variance-recon skills/user-skills/finance-variance-recon skills/*; do
  [ -f "$d/scripts/reconcile_3way.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/reconcile_3way.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/pnl_variance_engine.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/aging_bucket_auditor.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/reconcile_3way.py" --help
python3 "$SKILL_DIR/scripts/pnl_variance_engine.py" --help
python3 "$SKILL_DIR/scripts/aging_bucket_auditor.py" --help
```

## Step 4 — Write-Back Governance (`Auto-Guardian`) & Conversational Scheduling (`schedule_task`)

- **Read-Only & Local Draft Actions:** Connector reads via `remote_cli mcp`, file inspection via `view_file`, `pyrepl` scoring, interactive Canvas (`emit_a2ui`), and saving local deliverables via `write_to_file` run without mutating external systems.
- **Agent Gateway (`Auto-Guardian`) & Explicit User Confirmation:** External write-backs executed via authorized connectors are protected by Agent Gateway (`Auto-Guardian`) and require explicit user confirmation prior to execution:
  - Releasing AP invoice payment batches or posting GL/AP entries via customer ERP MCP
  - Updating vendor remittance or bank master records in ERP (never auto-executed from email)
  - Sending external customer AR collections or dunning emails via Gmail or Outlook
- **Code-Enforced Python Guardrails (`scripts/*.py`):**
  - TCURX zero/3-decimal scaling (JPY/KRW x100, KWD/BHD x0.1), SHKZG='H' sign inversion, and BEC bank-change FRAUD_HOLD
  - GL summary-vs-leaf exclusion preventing parent rollup double-counting beyond hierarchy_tolerance_amount
  - AR credit-memo isolation so negative credits never mask 90+ days past-due delinquency
- **Conversational Scheduling (`schedule_task`):** Only when the user asks to automate recurring monitoring, invoke `schedule_task(title="Daily AP & GR/IR Exception Watch", cron_expression="0 6 * * 1-5", time_zone="UTC", instruction="Run the weekday morning AP 3-way match sweep using scripts/reconcile_3way.py across open vendor invoices, purchase orders, and goods receipts. Surface duplicate invoice suspects, bank-change holds, TCURX decimal mismatches, and price/quantity exceptions for AP Controller review without releasing payments.")`.
