---
name: marketplace-superapp-ops
description: "Screens merchant catalog listings for prohibited terms, prompt-injection payloads, and price outliers, attributes on-demand delivery SLA breaches across merchant prep vs courier transit with force-majeure waivers, and reconciles merchant GMV, commission fees, FX, and PSP settlements. Use when routing or executing Marketplace, Ride-Hailing & SuperApp Ops workflows (merchant-catalog-trust-gate, logistics-sla-dispute-resolver, commission-payout-reconciler). Don't use for unrelated domains outside marketplace-superapp-ops or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# Marketplace, Ride-Hailing & SuperApp Ops (Department Bundle)

Screens merchant catalog listings for prohibited terms, prompt-injection payloads, and price outliers, attributes on-demand delivery SLA breaches across merchant prep vs courier transit with force-majeure waivers, and reconciles merchant GMV, commission fees, FX, and PSP settlements.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `merchant-catalog-trust-gate` | [merchant-catalog-trust-gate.md](references/workflows/merchant-catalog-trust-gate.md) | [catalog_quality_scorer.py](scripts/catalog_quality_scorer.py) | Detects indirect prompt injection in merchant copy, screens counterfeit/prohibited goods, flags price outliers, and checks attributes. |
| `logistics-sla-dispute-resolver` | [logistics-sla-dispute-resolver.md](references/workflows/logistics-sla-dispute-resolver.md) | [zone_sla_dispute_analyzer.py](scripts/zone_sla_dispute_analyzer.py) | Splits order delays into merchant prep vs courier transit faults, waives verified weather delays, and assigns refund liability. |
| `commission-payout-reconciler` | [commission-payout-reconciler.md](references/workflows/commission-payout-reconciler.md) | [payout_ledger_reconciler.py](scripts/payout_ledger_reconciler.py) | Reconciles gross GMV, commission take-rates, promo splits, FX conversions, and PSP wires while flagging negative clawbacks. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `marketplace_catalog_dispatch_psp` | bigquery_sql_api, rest_webhook_api | Google Sheets, Google Docs, Google Drive (Read Merchant Listing Queues, Zone Delivery SLA Logs, and Weekly PSP Payout Sheets in SuperApp Ops Drives.) | .json, .csv |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [itsm-sla-severity-baseline.md](references/baselines/itsm-sla-severity-baseline.md)
- [finance-materiality-baseline.md](references/baselines/finance-materiality-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Inspect outputs and optionally visualize metrics with `emit_a2ui` or automate via `schedule_task`.

Using persistent `pyrepl`:

```python
import json
from scripts.catalog_quality_scorer import analyze
with open('references/config.json') as f:
    cfg = json.load(f)
# Pass loaded Mode A/B/C records in RAM without flooding context tokens
```

Using CLI fallback (`python3`):

```bash
python3 scripts/catalog_quality_scorer.py --help
python3 scripts/zone_sla_dispute_analyzer.py --help
python3 scripts/payout_ledger_reconciler.py --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [untrusted-content-and-pii.md](references/traps/untrusted-content-and-pii.md)
- [chain-denominator-seams.md](references/traps/chain-denominator-seams.md)
- [bigquery-sap-erp-traps.md](references/traps/bigquery-sap-erp-traps.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `bigquery_query_marketplace_orders`, `catalog_read_pending_skus`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `docs_draft_trust_hold_notice`, `sheets_draft_settlement_recon`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `catalog_suspend_merchant_sku` (scope: `explicit_per_call`) — Suspending merchants or publishing rejected SKUs requires Trust & Safety moderator sign-off.
  - `psp_release_merchant_payout_batch` (scope: `explicit_per_call`) — Releasing merchant bank payout batches or SLA refunds requires Marketplace Finance Ops approval.
