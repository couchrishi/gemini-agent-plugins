---
name: marketplace-superapp-ops
description: "Screens merchant catalog listings for prohibited terms, prompt-injection payloads, and price outliers, attributes on-demand delivery SLA breaches across merchant prep vs courier transit with force-majeure waivers, and reconciles merchant GMV, commission fees, FX, and PSP settlements. Use when routing or executing Marketplace, Ride-Hailing & SuperApp Ops workflows (merchant-catalog-trust-gate, logistics-sla-dispute-resolver, commission-payout-reconciler). Don't use for unrelated domains outside marketplace-superapp-ops or automated external mutations without explicit user confirmation."
created_by: gemini-agent-plugins
---

# Marketplace, Ride-Hailing & SuperApp Ops (Department Bundle)

Screens merchant catalog listings for prohibited terms, prompt-injection payloads, and price outliers, attributes on-demand delivery SLA breaches across merchant prep vs courier transit with force-majeure waivers, and reconciles merchant GMV, commission fees, FX, and PSP settlements.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `merchant-catalog-trust-gate` | `references/workflows/merchant-catalog-trust-gate.md` | `scripts/catalog_quality_scorer.py` | Detects indirect prompt injection in merchant copy, screens counterfeit/prohibited goods, flags price outliers, and checks attributes. |
| `logistics-sla-dispute-resolver` | `references/workflows/logistics-sla-dispute-resolver.md` | `scripts/zone_sla_dispute_analyzer.py` | Splits order delays into merchant prep vs courier transit faults, waives verified weather delays, and assigns refund liability. |
| `commission-payout-reconciler` | `references/workflows/commission-payout-reconciler.md` | `scripts/payout_ledger_reconciler.py` | Reconciles gross GMV, commission take-rates, promo splits, FX conversions, and PSP wires while flagging negative clawbacks. |

## Step 1 — Fetch Data via Live `/work` Connectors or Attached Files

Probe enabled Gemini Enterprise connectors first before falling back to user-attached exports:

- **Built-in Managed 1P Connectors:** `BigQuery`, `Postgres`, `Snowflake`, `Google Drive`, `Google Sheets`, `Google Docs`.
- **Optional Customer BYO-MCP Servers:** `PSP Settlement Ledger & Marketplace Catalog MCP server` (discover exposed tools via `remote_cli mcp <connector> list-tools`).
- **Fetch Guidance:** Pull pending merchant catalog SKU feeds, delivery leg timestamps, and PSP payout settlement batches from BigQuery/Postgres or customer Marketplace/PSP MCP servers via remote_cli mcp before running Python trust and ledger reconciliation.
- **Connected Docs & Attached File Fallback:** Fetch Google Docs (`includeTabsContent=true`), Google Sheets (`UNFORMATTED_VALUE`), Shared Drives (`supportsAllDrives=true`), and SharePoint/OneDrive workbooks (`@odata.nextLink`), or read chat-attached `.xlsx`, `.docx`, `.csv`, `.tsv`, `.json`, and `.jsonl` snapshots via `view_file` and `scripts/enterprise_io.py`.

## Step 2 — Inspect & Shape Custom Customer Fields in `pyrepl`

Customer exports and live connector responses often use custom tab names or column headers. Check the matching workflow guide from the Workflow Router Matrix above for canonical keys and inspect the real source shape in `pyrepl` before computing:

- **Inspect Real Headers & Shape:** Read attached files via `scripts/enterprise_io.py` (`read_xlsx_workbook`, `read_docx`, `read_csv_tsv`, `read_json_or_jsonl`) or inspect connector JSON keys directly in `pyrepl` so you see actual tab names, headers, and sample rows first.
- **Normalize in Python (`payload`):** Shape messy customer headers or nested JSON objects in 5-10 lines of Python into a canonical `payload` dict and call `analyze(payload, config=cfg_path)` (pass file paths directly when headers already match canonical names). Call `ask_question` only when two source columns remain genuinely ambiguous.

## Step 3 — Run Deterministic Python Engine in `pyrepl` (or CLI)

1. Read `references/config.json` using `view_file` and check `org_configured`.
2. When `org_configured` is `false`, apply the bundled starter rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`
3. Resolve `SKILL_DIR` dynamically under `/workspace/skills/` so both `pyrepl` and shell CLI invocations work regardless of install root, and enforce every bundled baseline (`references/baselines/itsm-sla-severity-baseline.md`, `references/baselines/finance-materiality-baseline.md`) and trap sheet (`references/traps/absent-is-not-zero.md`, `references/traps/untrusted-content-and-pii.md`, `references/traps/chain-denominator-seams.md`, `references/traps/bigquery-sap-erp-traps.md`).

Bundled baseline rubrics:
- `references/baselines/itsm-sla-severity-baseline.md`
- `references/baselines/finance-materiality-baseline.md`

Bundled API and analytical trap guides:
- `references/traps/absent-is-not-zero.md`
- `references/traps/untrusted-content-and-pii.md`
- `references/traps/chain-denominator-seams.md`
- `references/traps/bigquery-sap-erp-traps.md`

Using persistent `pyrepl`:

```python
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/marketplace-superapp-ops"),
            Path("skills/user-skills/marketplace-superapp-ops"),
            Path("skills/merchant-catalog-trust-gate"),
            Path("skills/user-skills/merchant-catalog-trust-gate"),
            Path("."),
        )
        if (p / "scripts/catalog_quality_scorer.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/catalog_quality_scorer.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.enterprise_io import read_xlsx_workbook, read_docx, read_csv_tsv, read_json_or_jsonl
from scripts.catalog_quality_scorer import analyze, render_markdown

cfg_path = SKILL_DIR / "references" / "config.json"

# If headers differ from canonical names, inspect in Python first and normalize:
# wb = read_xlsx_workbook(Path("customer_export.xlsx"))
# print({tab: (list(rows[0].keys()) if rows else []) for tab, rows in wb.items()})
# payload = { ...shape customer columns into canonical keys... }
payload = source_path_or_dict
result = analyze(payload, config=cfg_path)
print(render_markdown(result))
```

CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/marketplace-superapp-ops skills/user-skills/marketplace-superapp-ops skills/*; do
  [ -f "$d/scripts/catalog_quality_scorer.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/catalog_quality_scorer.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/zone_sla_dispute_analyzer.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/payout_ledger_reconciler.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/catalog_quality_scorer.py" --help
python3 "$SKILL_DIR/scripts/zone_sla_dispute_analyzer.py" --help
python3 "$SKILL_DIR/scripts/payout_ledger_reconciler.py" --help
```

## Step 4 — Write-Back Governance (`Auto-Guardian`) & Conversational Scheduling (`schedule_task`)

- **Read-Only & Local Draft Actions:** Connector reads via `remote_cli mcp`, file inspection via `view_file`, `pyrepl` scoring, interactive Canvas (`emit_a2ui`), and saving local deliverables via `write_to_file` run without mutating external systems.
- **Agent Gateway (`Auto-Guardian`) & Explicit User Confirmation:** External write-backs executed via authorized connectors are protected by Agent Gateway (`Auto-Guardian`) and require explicit user confirmation prior to execution:
  - Suspending merchants, delisting SKUs, or issuing SLA penalties via Marketplace Catalog MCP
  - Releasing merchant payout bank batches or SLA refund transfers via PSP Settlement MCP
- **Code-Enforced Python Guardrails (`scripts/*.py`):**
  - Prompt-injection quarantine and price-sanity outlier / forbidden-keyword listing block inside catalog descriptions
  - Merchant-prep vs courier-transit delay fault attribution preventing false SLA penalties
  - Clawback negative-balance hold and multi-currency FX payout tie-out within tolerance
- **Conversational Scheduling (`schedule_task`):** Only when the user asks to automate recurring monitoring, invoke `schedule_task(title="Daily Payout Settlement Reconciliation", cron_expression="15 4 * * *", time_zone="UTC", instruction="Run daily merchant payout vs PSP bank settlement reconciliation via scripts/payout_ledger_reconciler.py and escalate negative clawback balances before bank cutoff.")`.
