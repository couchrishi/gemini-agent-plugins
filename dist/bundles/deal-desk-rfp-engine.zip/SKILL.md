---
name: deal-desk-rfp-engine
description: "Accelerates RFP security/compliance questionnaires with TF-IDF answer matching, validates multi-year SaaS quote discounts and gross margins against Deal Desk approval tiers, and audits CRM pipeline for slippage and multi-currency traps. Use when routing or executing Deal Desk, RFP & Pipeline Hygiene Engine workflows (rfp-questionnaire-responder, deal-desk-quote-guard, pipeline-hygiene-slippage). Don't use for unrelated domains outside deal-desk-rfp-engine or automated external mutations without explicit user confirmation."
created_by: gemini-agent-plugins
---

# Deal Desk, RFP & Pipeline Hygiene Engine (Department Bundle)

Accelerates RFP security/compliance questionnaires with TF-IDF answer matching, validates multi-year SaaS quote discounts and gross margins against Deal Desk approval tiers, and audits CRM pipeline for slippage and multi-currency traps.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `rfp-questionnaire-responder` | `references/workflows/rfp-questionnaire-responder.md` | `scripts/rfp_matrix_builder.py` | Matches RFP requirement rows against verified answer libraries using TF-IDF cosine similarity and flags mandatory compliance gaps. |
| `deal-desk-quote-guard` | `references/workflows/deal-desk-quote-guard.md` | `scripts/deal_margin_validator.py` | Computes net effective discount, multi-year ramp ACV/TCV, gross margin floor compliance, non-standard terms, and required Deal Desk tier. |
| `pipeline-hygiene-slippage` | `references/workflows/pipeline-hygiene-slippage.md` | `scripts/pipeline_slippage_auditor.py` | Audits CRM opportunities for stage staleness, push counts, missing MEDDPICC commit gates, single-threading, and multi-currency FX alignment. |

## Step 1 — Fetch Data via Live `/work` Connectors or Attached Files

Probe enabled Gemini Enterprise connectors first before falling back to user-attached exports:

- **Built-in Managed 1P Connectors:** `Salesforce`, `Google Drive`, `Google Docs`, `Google Sheets`, `Microsoft 365 (SharePoint, OneDrive, Outlook, Teams)`, `Gmail`.
- **Connector Tool Discovery:** Query enabled 1P/MCP servers via `remote_cli mcp <connector> list-tools` before calling Python engines.
- **Fetch Guidance:** Query Salesforce opportunities, DatedConversionRate FX tables, and quote line items via remote_cli mcp salesforce, plus RFP questionnaires and Deal Desk approvals from Google Drive or SharePoint before Python validation.
- **Connected Docs & Attached File Fallback:** Fetch Google Docs (`includeTabsContent=true`), Google Sheets (`UNFORMATTED_VALUE`), Shared Drives (`supportsAllDrives=true`), and SharePoint/OneDrive workbooks (`@odata.nextLink`), or read chat-attached `.xlsx`, `.docx`, `.csv`, `.tsv`, `.json`, and `.jsonl` snapshots via `view_file` and `scripts/enterprise_io.py`.

## Step 2 — Inspect & Shape Custom Customer Fields in `pyrepl`

Customer exports and live connector responses often use custom tab names or column headers. Check the matching workflow guide from the Workflow Router Matrix above for canonical keys and inspect the real source shape in `pyrepl` before computing:

- **Inspect Real Headers & Shape:** Read attached files via `scripts/enterprise_io.py` (`read_xlsx_workbook`, `read_docx`, `read_csv_tsv`, `read_json_or_jsonl`) or inspect connector JSON keys directly in `pyrepl` so you see actual tab names, headers, and sample rows first.
- **Normalize in Python (`payload`):** Shape messy customer headers or nested JSON objects in 5-10 lines of Python into a canonical `payload` dict and call `analyze(payload, config=cfg_path)` (pass file paths directly when headers already match canonical names). Call `ask_question` only when two source columns remain genuinely ambiguous.

## Step 3 — Run Deterministic Python Engine in `pyrepl` (or CLI)

1. Read `references/config.json` using `view_file` and check `org_configured`.
2. When `org_configured` is `false`, apply the bundled starter rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`
3. Resolve `SKILL_DIR` dynamically under `/workspace/skills/` so both `pyrepl` and shell CLI invocations work regardless of install root, and enforce every bundled baseline (`references/baselines/deal-desk-approval-baseline.md`, `references/baselines/commercial-contract-baseline.md`) and trap sheet (`references/traps/absent-is-not-zero.md`, `references/traps/salesforce-crm-soql-traps.md`, `references/traps/chain-denominator-seams.md`, `references/traps/untrusted-content-and-pii.md`).

Bundled baseline rubrics:
- `references/baselines/deal-desk-approval-baseline.md`
- `references/baselines/commercial-contract-baseline.md`

Bundled API and analytical trap guides:
- `references/traps/absent-is-not-zero.md`
- `references/traps/salesforce-crm-soql-traps.md`
- `references/traps/chain-denominator-seams.md`
- `references/traps/untrusted-content-and-pii.md`

Using persistent `pyrepl`:

```python
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/deal-desk-rfp-engine"),
            Path("skills/user-skills/deal-desk-rfp-engine"),
            Path("skills/rfp-questionnaire-responder"),
            Path("skills/user-skills/rfp-questionnaire-responder"),
            Path("."),
        )
        if (p / "scripts/rfp_matrix_builder.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/rfp_matrix_builder.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.enterprise_io import read_xlsx_workbook, read_docx, read_csv_tsv, read_json_or_jsonl
from scripts.rfp_matrix_builder import analyze, render_markdown

cfg_path = SKILL_DIR / "references" / "config.json"

# If headers differ from canonical names, inspect in Python first and normalize:
# wb = read_xlsx_workbook(Path("customer_export.xlsx"))
# print({tab: (list(rows[0].keys()) if rows else []) for tab, rows in wb.items()})
# payload = { ...shape customer columns into canonical keys... }
payload = source_path_or_dict
result = analyze(payload, config=cfg_path)
print(render_markdown(result))
```

CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/deal-desk-rfp-engine skills/user-skills/deal-desk-rfp-engine skills/*; do
  [ -f "$d/scripts/rfp_matrix_builder.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/rfp_matrix_builder.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/deal_margin_validator.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/pipeline_slippage_auditor.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/rfp_matrix_builder.py" --help
python3 "$SKILL_DIR/scripts/deal_margin_validator.py" --help
python3 "$SKILL_DIR/scripts/pipeline_slippage_auditor.py" --help
```

## Step 4 — Write-Back Governance (`Auto-Guardian`) & Conversational Scheduling (`schedule_task`)

- **Read-Only & Local Draft Actions:** Connector reads via `remote_cli mcp`, file inspection via `view_file`, `pyrepl` scoring, interactive Canvas (`emit_a2ui`), and saving local deliverables via `write_to_file` run without mutating external systems.
- **Agent Gateway (`Auto-Guardian`) & Explicit User Confirmation:** External write-backs executed via authorized connectors are protected by Agent Gateway (`Auto-Guardian`) and require explicit user confirmation prior to execution:
  - Updating Salesforce opportunity forecast categories, close dates, or approved quote statuses
  - Submitting Deal Desk discount/non-standard term exceptions for CFO or VP Sales approval
  - Sending completed customer RFP responses or commercial quote emails externally via Gmail/Outlook
- **Code-Enforced Python Guardrails (`scripts/*.py`):**
  - Mandatory DatedConversionRate FX normalization across mixed-currency CRM rollups
  - Zero-guess abstention when approved RFP answer library contains no verified match
  - Indirect prompt-injection directive quarantine inside external customer RFP rows
- **Conversational Scheduling (`schedule_task`):** Only when the user asks to automate recurring monitoring, invoke `schedule_task(title="Weekly Pipeline Hygiene Audit", cron_expression="0 8 * * 1", time_zone="UTC", instruction="Run the weekly Salesforce pipeline hygiene and slippage audit using scripts/pipeline_slippage_auditor.py. Normalize multi-currency opportunities, identify stale stages, >=2 push-count deals, single-threaded Commit opportunities, and StageName/IsClosed inconsistencies without modifying CRM records autonomously.")`.
