---
name: deal-desk-rfp-engine
description: "Accelerates RFP security/compliance questionnaires with TF-IDF answer matching, validates multi-year SaaS quote discounts and gross margins against Deal Desk approval tiers, and audits CRM pipeline for slippage and multi-currency traps. Use when routing or executing Deal Desk, RFP & Pipeline Hygiene Engine workflows (rfp-questionnaire-responder, deal-desk-quote-guard, pipeline-hygiene-slippage). Don't use for unrelated domains outside deal-desk-rfp-engine or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# Deal Desk, RFP & Pipeline Hygiene Engine (Department Bundle)

Accelerates RFP security/compliance questionnaires with TF-IDF answer matching, validates multi-year SaaS quote discounts and gross margins against Deal Desk approval tiers, and audits CRM pipeline for slippage and multi-currency traps.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `rfp-questionnaire-responder` | [rfp-questionnaire-responder.md](references/workflows/rfp-questionnaire-responder.md) | [rfp_matrix_builder.py](scripts/rfp_matrix_builder.py) | Matches RFP requirement rows against verified answer libraries using TF-IDF cosine similarity and flags mandatory compliance gaps. |
| `deal-desk-quote-guard` | [deal-desk-quote-guard.md](references/workflows/deal-desk-quote-guard.md) | [deal_margin_validator.py](scripts/deal_margin_validator.py) | Computes net effective discount, multi-year ramp ACV/TCV, gross margin floor compliance, non-standard terms, and required Deal Desk tier. |
| `pipeline-hygiene-slippage` | [pipeline-hygiene-slippage.md](references/workflows/pipeline-hygiene-slippage.md) | [pipeline_slippage_auditor.py](scripts/pipeline_slippage_auditor.py) | Audits CRM opportunities for stage staleness, push counts, missing MEDDPICC commit gates, single-threading, and multi-currency FX alignment. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `crm_opportunity_and_quotes` | salesforce_soql_api | Google Sheets, Google Drive, Google Docs (Locate Pipeline Export Sheets, Quote Pricing Calculators, and Deal Desk Guidelines in Revenue Ops Shared Drives.) | .json, .csv |
| `verified_rfp_answer_library` | google_drive_api | Google Sheets, Google Docs, Google Drive (Read the Verified RFP Q&A Library Sheet inside the Deal Desk Shared Drive.) | .json, .csv |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [deal-desk-approval-baseline.md](references/baselines/deal-desk-approval-baseline.md)
- [commercial-contract-baseline.md](references/baselines/commercial-contract-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Because runtime shells start in `/workspace` while bundles and individual skills unpack under `skills/<slug>/` or `skills/user-skills/<slug>/`, always resolve `SKILL_DIR` dynamically before importing scripts or reading references.

Using persistent `pyrepl`:

```python
import json
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/deal-desk-rfp-engine"),
            Path("skills/user-skills/deal-desk-rfp-engine"),
            Path("skills/rfp-questionnaire-responder"),
            Path("skills/user-skills/rfp-questionnaire-responder"),
            Path("."),
        )
        if (p / "scripts/rfp_matrix_builder.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/rfp_matrix_builder.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.rfp_matrix_builder import analyze, render_markdown

cfg = json.loads((SKILL_DIR / "references" / "config.json").read_text(encoding="utf-8"))
# Pass loaded Mode A/B/C payload in RAM without flooding prompt tokens:
# result = analyze(payload, config=SKILL_DIR / "references" / "config.json")
# print(render_markdown(result))
```

Using CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/deal-desk-rfp-engine skills/user-skills/deal-desk-rfp-engine skills/*; do
  [ -f "$d/scripts/rfp_matrix_builder.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/rfp_matrix_builder.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/deal_margin_validator.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/pipeline_slippage_auditor.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
# Or inspect CLI flags directly:
python3 "$SKILL_DIR/scripts/rfp_matrix_builder.py" --help
python3 "$SKILL_DIR/scripts/deal_margin_validator.py" --help
python3 "$SKILL_DIR/scripts/pipeline_slippage_auditor.py" --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [salesforce-crm-soql-traps.md](references/traps/salesforce-crm-soql-traps.md)
- [chain-denominator-seams.md](references/traps/chain-denominator-seams.md)
- [untrusted-content-and-pii.md](references/traps/untrusted-content-and-pii.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `salesforce_soql_query`, `drive_read_sheet`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `sheets_create_rfp_response_draft`, `docs_create_deal_memo_draft`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `salesforce_update_opportunity_or_quote` (scope: `explicit_per_call`) — Updating CRM forecast categories, close dates, or discounted quotes requires explicit user approval.
  - `deal_desk_submit_or_approve_quote` (scope: `explicit_per_call`) — Escalated Deal Desk quotes and margin exceptions require explicit approver sign-off.
  - `portal_submit_rfp_response` (scope: `explicit_per_call`) — Submitting customer RFP packets externally requires explicit human review, especially with open gaps.
