---
name: public-sector-higher-ed
description: "Evaluates citizen benefits/aid eligibility with strict missing-document cure holds (never silent denials) and SSN redaction, scores public procurement tenders after mandatory debarment/COI pass-fail gates, and validates research grant budgets (F&A indirect caps, unallowables, PI effort) plus accreditation evidence freshness. Use when routing or executing Public Sector Casework, Grants & Higher-Ed Ops workflows (citizen-case-eligibility-triager, procurement-tender-evaluator, grant-accreditation-evidence-pack). Don't use for unrelated domains outside public-sector-higher-ed or automated external mutations without explicit user confirmation."
created_by: gemini-agent-plugins
---

# Public Sector Casework, Grants & Higher-Ed Ops (Department Bundle)

Evaluates citizen benefits/aid eligibility with strict missing-document cure holds (never silent denials) and SSN redaction, scores public procurement tenders after mandatory debarment/COI pass-fail gates, and validates research grant budgets (F&A indirect caps, unallowables, PI effort) plus accreditation evidence freshness.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `citizen-case-eligibility-triager` | `references/workflows/citizen-case-eligibility-triager.md` | `scripts/statutory_eligibility_engine.py` | Computes household FPL income eligibility, enforces missing-document cure holds instead of silent denials, and counts PII redactions. |
| `procurement-tender-evaluator` | `references/workflows/procurement-tender-evaluator.md` | `scripts/tender_weighted_scorer.py` | Enforces mandatory debarment/COI/tax pass-fail gates first, then computes lowest-compliant commercial normalization and weighted rank. |
| `grant-accreditation-evidence-pack` | `references/workflows/grant-accreditation-evidence-pack.md` | `scripts/grant_accreditation_validator.py` | Validates MTDC base vs F&A indirect cost caps, flags unallowable expenses, checks PI 100% effort cap, and checks accreditation freshness. |

## Step 1 — Fetch Data via Live `/work` Connectors or Attached Files

Probe enabled Gemini Enterprise connectors first before falling back to user-attached exports:

- **Built-in Managed 1P Connectors:** `ServiceNow`, `BigQuery`, `Google Drive`, `Google Docs`, `Google Sheets`, `Box`.
- **Optional Customer BYO-MCP Servers:** `Grants Management & Procurement Portal MCP server` (discover exposed tools via `remote_cli mcp <connector> list-tools`).
- **Fetch Guidance:** Query citizen benefit case packets, sealed vendor tender matrices, and sponsored research budgets/PI effort logs from ServiceNow, BigQuery, Drive, or Grants/Procurement MCP servers via remote_cli mcp before Python compliance validation.
- **Connected Docs & Attached File Fallback:** Fetch Google Docs (`includeTabsContent=true`), Google Sheets (`UNFORMATTED_VALUE`), Shared Drives (`supportsAllDrives=true`), and SharePoint/OneDrive workbooks (`@odata.nextLink`), or read chat-attached `.xlsx`, `.docx`, `.csv`, `.tsv`, `.json`, and `.jsonl` snapshots via `view_file` and `scripts/enterprise_io.py`.

## Step 2 — Inspect & Shape Custom Customer Fields in `pyrepl`

Customer exports and live connector responses often use custom tab names or column headers. Check the matching workflow guide from the Workflow Router Matrix above for canonical keys and inspect the real source shape in `pyrepl` before computing:

- **Inspect Real Headers & Shape:** Read attached files via `scripts/enterprise_io.py` (`read_xlsx_workbook`, `read_docx`, `read_csv_tsv`, `read_json_or_jsonl`) or inspect connector JSON keys directly in `pyrepl` so you see actual tab names, headers, and sample rows first.
- **Normalize in Python (`payload`):** Shape messy customer headers or nested JSON objects in 5-10 lines of Python into a canonical `payload` dict and call `analyze(payload, config=cfg_path)` (pass file paths directly when headers already match canonical names). Call `ask_question` only when two source columns remain genuinely ambiguous.

## Step 3 — Run Deterministic Python Engine in `pyrepl` (or CLI)

1. Read `references/config.json` using `view_file` and check `org_configured`.
2. When `org_configured` is `false`, apply the bundled starter rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`
3. Resolve `SKILL_DIR` dynamically under `/workspace/skills/` so both `pyrepl` and shell CLI invocations work regardless of install root, and enforce every bundled baseline (`references/baselines/commercial-contract-baseline.md`, `references/baselines/itsm-sla-severity-baseline.md`) and trap sheet (`references/traps/untrusted-content-and-pii.md`, `references/traps/absent-is-not-zero.md`, `references/traps/servicenow-jira-itsm-traps.md`, `references/traps/google-workspace-traps.md`).

Bundled baseline rubrics:
- `references/baselines/commercial-contract-baseline.md`
- `references/baselines/itsm-sla-severity-baseline.md`

Bundled API and analytical trap guides:
- `references/traps/untrusted-content-and-pii.md`
- `references/traps/absent-is-not-zero.md`
- `references/traps/servicenow-jira-itsm-traps.md`
- `references/traps/google-workspace-traps.md`

Using persistent `pyrepl`:

```python
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/public-sector-higher-ed"),
            Path("skills/user-skills/public-sector-higher-ed"),
            Path("skills/citizen-case-eligibility-triager"),
            Path("skills/user-skills/citizen-case-eligibility-triager"),
            Path("."),
        )
        if (p / "scripts/statutory_eligibility_engine.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/statutory_eligibility_engine.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.enterprise_io import read_xlsx_workbook, read_docx, read_csv_tsv, read_json_or_jsonl
from scripts.statutory_eligibility_engine import analyze, render_markdown

cfg_path = SKILL_DIR / "references" / "config.json"

# If headers differ from canonical names, inspect in Python first and normalize:
# wb = read_xlsx_workbook(Path("customer_export.xlsx"))
# print({tab: (list(rows[0].keys()) if rows else []) for tab, rows in wb.items()})
# payload = { ...shape customer columns into canonical keys... }
payload = source_path_or_dict
result = analyze(payload, config=cfg_path)
print(render_markdown(result))
```

CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/public-sector-higher-ed skills/user-skills/public-sector-higher-ed skills/*; do
  [ -f "$d/scripts/statutory_eligibility_engine.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/statutory_eligibility_engine.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/tender_weighted_scorer.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/grant_accreditation_validator.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/statutory_eligibility_engine.py" --help
python3 "$SKILL_DIR/scripts/tender_weighted_scorer.py" --help
python3 "$SKILL_DIR/scripts/grant_accreditation_validator.py" --help
```

## Step 4 — Write-Back Governance (`Auto-Guardian`) & Conversational Scheduling (`schedule_task`)

- **Read-Only & Local Draft Actions:** Connector reads via `remote_cli mcp`, file inspection via `view_file`, `pyrepl` scoring, interactive Canvas (`emit_a2ui`), and saving local deliverables via `write_to_file` run without mutating external systems.
- **Agent Gateway (`Auto-Guardian`) & Explicit User Confirmation:** External write-backs executed via authorized connectors are protected by Agent Gateway (`Auto-Guardian`) and require explicit user confirmation prior to execution:
  - Issuing statutory citizen benefit eligibility determinations or cure notices via ServiceNow/Case MCP
  - Recording procurement tender award selections via customer Procurement Portal MCP
  - Submitting federal/sponsor grant budget certifications via customer Grants Management MCP
- **Code-Enforced Python Guardrails (`scripts/*.py`):**
  - Debarred/ineligible vendor hard disqualification blocking award when zero compliant bids exist
  - MTDC indirect-cost exemption exclusion (equipment/subawards >$25k), unallowable cost blocker, and PI >100% effort cap
  - Deterministic PENDING_CURE_NOTICE handling preventing silent denial of incomplete citizen packets
- **Conversational Scheduling (`schedule_task`):** Only when the user asks to automate recurring monitoring, invoke `schedule_task(title="Weekly Grant & Accreditation Evidence Watch", cron_expression="0 8 * * 1", time_zone="UTC", instruction="Run the weekly sponsored grant allowability and accreditation artifact freshness check via scripts/grant_accreditation_validator.py across active institutional packets.")`.
