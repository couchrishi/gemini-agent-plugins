---
name: public-sector-higher-ed
description: "Evaluates citizen benefits/aid eligibility with strict missing-document cure holds (never silent denials) and SSN redaction, scores public procurement tenders after mandatory debarment/COI pass-fail gates, and validates research grant budgets (F&A indirect caps, unallowables, PI effort) plus accreditation evidence freshness. Use when routing or executing Public Sector Casework, Grants & Higher-Ed Ops workflows (citizen-case-eligibility-triager, procurement-tender-evaluator, grant-accreditation-evidence-pack). Don't use for unrelated domains outside public-sector-higher-ed or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# Public Sector Casework, Grants & Higher-Ed Ops (Department Bundle)

Evaluates citizen benefits/aid eligibility with strict missing-document cure holds (never silent denials) and SSN redaction, scores public procurement tenders after mandatory debarment/COI pass-fail gates, and validates research grant budgets (F&A indirect caps, unallowables, PI effort) plus accreditation evidence freshness.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `citizen-case-eligibility-triager` | `references/workflows/citizen-case-eligibility-triager.md` | `scripts/statutory_eligibility_engine.py` | Computes household FPL income eligibility, enforces missing-document cure holds instead of silent denials, and counts PII redactions. |
| `procurement-tender-evaluator` | `references/workflows/procurement-tender-evaluator.md` | `scripts/tender_weighted_scorer.py` | Enforces mandatory debarment/COI/tax pass-fail gates first, then computes lowest-compliant commercial normalization and weighted rank. |
| `grant-accreditation-evidence-pack` | `references/workflows/grant-accreditation-evidence-pack.md` | `scripts/grant_accreditation_validator.py` | Validates MTDC base vs F&A indirect cost caps, flags unallowable expenses, checks PI 100% effort cap, and checks accreditation freshness. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `case_erp_and_grants_repositories` | servicenow_table_api, bigquery_sql_api | Google Drive, Google Sheets, Google Docs (Read Benefits Intake Packets, Bid Tabulation Sheets (`UNFORMATTED_VALUE`), Grant Budget Sheets, and Accreditation Folders in Shared Drives.) | .json, .csv |

## Org Configuration & Starter Baseline Rule

1. Read `references/config.json` using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- `references/baselines/commercial-contract-baseline.md`
- `references/baselines/itsm-sla-severity-baseline.md`

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Because runtime shells start in `/workspace` while bundles and individual skills unpack under `skills/<slug>/` or `skills/user-skills/<slug>/`, always resolve `SKILL_DIR` dynamically before importing scripts or reading references.

- **Zero-dependency enterprise ingestion:** Every engine uses `scripts/enterprise_io.py` to parse multi-tab `.xlsx`/`.xlsm` workbooks (1900/1904 dates, inline/shared strings, formula cached values), `.docx` documents (sections, headings, embedded tables, footnotes/comments), UTF-8 BOM `.csv`/`.tsv`, `.json`, and `.jsonl` directly from `--input` without needing `openpyxl` or `python-docx`. Pass `--sheet <TabNameOrIndex>` (or `sheet='...'` in `analyze()`) to analyze a specific worksheet by tab name or 0-based index.

Using persistent `pyrepl`:

```python
import json
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/public-sector-higher-ed"),
            Path("skills/user-skills/public-sector-higher-ed"),
            Path("skills/citizen-case-eligibility-triager"),
            Path("skills/user-skills/citizen-case-eligibility-triager"),
            Path("."),
        )
        if (p / "scripts/statutory_eligibility_engine.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/statutory_eligibility_engine.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.statutory_eligibility_engine import analyze, render_markdown

cfg = json.loads((SKILL_DIR / "references" / "config.json").read_text(encoding="utf-8"))
# Pass loaded Mode A/B/C payload in RAM without flooding prompt tokens:
# result = analyze(payload, config=SKILL_DIR / "references" / "config.json")
# print(render_markdown(result))
```

Using CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/public-sector-higher-ed skills/user-skills/public-sector-higher-ed skills/*; do
  [ -f "$d/scripts/statutory_eligibility_engine.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/statutory_eligibility_engine.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/tender_weighted_scorer.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/grant_accreditation_validator.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
# Or pass .xlsx / .docx / .csv directly (optional --sheet "TabName" or --sheet 0):
# python3 "$SKILL_DIR/scripts/statutory_eligibility_engine.py" --input workbook.xlsx --config "$SKILL_DIR/references/config.json" --format markdown
# Inspect CLI flags directly:
python3 "$SKILL_DIR/scripts/statutory_eligibility_engine.py" --help
python3 "$SKILL_DIR/scripts/tender_weighted_scorer.py" --help
python3 "$SKILL_DIR/scripts/grant_accreditation_validator.py" --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- `references/traps/untrusted-content-and-pii.md`
- `references/traps/absent-is-not-zero.md`
- `references/traps/servicenow-jira-itsm-traps.md`
- `references/traps/google-workspace-traps.md`

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `case_read_applicant_packet`, `procurement_read_sealed_bids`, `grants_read_budget_ledger`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `docs_draft_cure_notice`, `sheets_draft_bid_scorecard`, `docs_draft_grant_audit`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `case_issue_benefit_determination` (scope: `explicit_per_call`) — Approving or denying citizen benefits requires licensed public-sector caseworker HITL authorization.
  - `procurement_award_contract` (scope: `explicit_per_call`) — Awarding public procurement tenders requires Evaluation Board Chair HITL sign-off.
  - `grants_submit_sponsor_package` (scope: `explicit_per_call`) — Certifying grant budgets to federal/foundation sponsors requires Sponsored Programs Officer HITL sign-off.
