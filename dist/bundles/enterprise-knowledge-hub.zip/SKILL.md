---
name: enterprise-knowledge-hub
description: "Synthesizes cross-source enterprise knowledge with strict citation conflict detection, jurisdiction-scoped SOP/policy answering with abstention gates, and corpus freshness/duplication auditing across Google Workspace, SharePoint, and Confluence. Use when routing or executing Enterprise Knowledge Hub workflows (cross-source-knowledge-synthesis, policy-sop-answering, knowledge-gap-freshness-audit). Don't use for unrelated domains outside enterprise-knowledge-hub or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# Enterprise Knowledge Hub (Department Bundle)

Synthesizes cross-source enterprise knowledge with strict citation conflict detection, jurisdiction-scoped SOP/policy answering with abstention gates, and corpus freshness/duplication auditing across Google Workspace, SharePoint, and Confluence.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `cross-source-knowledge-synthesis` | [cross-source-knowledge-synthesis.md](references/workflows/cross-source-knowledge-synthesis.md) | [citation_conflict_auditor.py](scripts/citation_conflict_auditor.py) | Scores source authority and recency across multi-repo hits, flags conflicting numerical/date claims, and verifies 100% claim citation coverage. |
| `policy-sop-answering` | [policy-sop-answering.md](references/workflows/policy-sop-answering.md) | [policy_scope_matcher.py](scripts/policy_scope_matcher.py) | Filters policy and SOP clauses by jurisdiction, entity, and effective date, enforcing abstention when active coverage is missing. |
| `knowledge-gap-freshness-audit` | [knowledge-gap-freshness-audit.md](references/workflows/knowledge-gap-freshness-audit.md) | [corpus_hygiene_scanner.py](scripts/corpus_hygiene_scanner.py) | Audits Drive, SharePoint, and Confluence inventories for overdue review dates, departed owners, near-duplicate titles, and unindexed ticket gaps. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `enterprise_document_search` | google_drive_api, microsoft_graph_sharepoint, atlassian_confluence_cloud | Google Drive, Google Docs, Google Sheets (Search Shared Drives with includeItemsFromAllDrives=true and inspect all child tabs in Google Docs.) | .json, .csv, .md, .txt |
| `support_ticket_gap_signal` | servicenow_table_api | Google Sheets, Google Drive (Locate exported ticket topic summary Sheets in the Knowledge Ops Shared Drive folder.) | .csv, .json |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [itsm-sla-severity-baseline.md](references/baselines/itsm-sla-severity-baseline.md)
- [commercial-contract-baseline.md](references/baselines/commercial-contract-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Inspect outputs and optionally visualize metrics with `emit_a2ui` or automate via `schedule_task`.

Using persistent `pyrepl`:

```python
import json
from scripts.citation_conflict_auditor import analyze
with open('references/config.json') as f:
    cfg = json.load(f)
# Pass loaded Mode A/B/C records in RAM without flooding context tokens
```

Using CLI fallback (`python3`):

```bash
python3 scripts/citation_conflict_auditor.py --help
python3 scripts/policy_scope_matcher.py --help
python3 scripts/corpus_hygiene_scanner.py --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [google-workspace-traps.md](references/traps/google-workspace-traps.md)
- [sharepoint-onedrive-kql-traps.md](references/traps/sharepoint-onedrive-kql-traps.md)
- [untrusted-content-and-pii.md](references/traps/untrusted-content-and-pii.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `drive_search`, `docs_read_tabs`, `sharepoint_kql_search`, `confluence_cql_search`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `docs_create_private_brief`, `sheets_write_audit_draft`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `confluence_publish_page` (scope: `explicit_per_call`) — Publishing or overwriting authoritative enterprise SOPs requires explicit human approval.
  - `sharepoint_archive_or_delete_file` (scope: `explicit_per_call`) — Archiving or deleting stale documents across SharePoint/Drive requires owner confirmation.
  - `slack_or_email_broadcast_digest` (scope: `task_sticky`) — Sending corpus audit digests to distribution lists or external emails requires HITL approval.
