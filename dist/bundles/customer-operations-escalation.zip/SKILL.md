---
name: customer-operations-escalation
description: "Scores VIP account escalations by ARR exposure and Sev1 outages, mines CSAT/NPS verbatims into ARR-weighted driver paretos with null-rating hygiene, and validates support troubleshooting decision trees for graph defects. Use when routing or executing Customer Operations, VIP Escalation & Knowledge Quality workflows (critical-escalation-warroom, csat-churn-signal-miner, troubleshooting-tree-author). Don't use for unrelated domains outside customer-operations-escalation or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# Customer Operations, VIP Escalation & Knowledge Quality (Department Bundle)

Scores VIP account escalations by ARR exposure and Sev1 outages, mines CSAT/NPS verbatims into ARR-weighted driver paretos with null-rating hygiene, and validates support troubleshooting decision trees for graph defects.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `critical-escalation-warroom` | [critical-escalation-warroom.md](references/workflows/critical-escalation-warroom.md) | [escalation_exposure_scorer.py](scripts/escalation_exposure_scorer.py) | Scores VIP account escalations (0-100) from Sev1/Sev2 cases, SLA breaches, ARR, imminent renewals, outages, and competitor risk. |
| `csat-churn-signal-miner` | [csat-churn-signal-miner.md](references/workflows/csat-churn-signal-miner.md) | [verbatim_driver_quantifier.py](scripts/verbatim_driver_quantifier.py) | Classifies survey verbatims into ARR-weighted friction drivers, excludes null scores from averages, and catches explicit churn intent. |
| `troubleshooting-tree-author` | [troubleshooting-tree-author.md](references/workflows/troubleshooting-tree-author.md) | [decision_tree_validator.py](scripts/decision_tree_validator.py) | Validates customer support diagnostic trees via BFS/DFS for cycles, dead-end questions, orphan nodes, broken refs, and depth. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `crm_and_support_case_data` | salesforce_soql_api, servicenow_csm_api | Google Sheets, Google Docs, Google Drive (Read VIP Escalation Tracker Sheets, Quarterly Survey Exports, and Support Playbook Docs in CX Shared Drives.) | .json, .csv |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [itsm-sla-severity-baseline.md](references/baselines/itsm-sla-severity-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Inspect outputs and optionally visualize metrics with `emit_a2ui` or automate via `schedule_task`.

Using persistent `pyrepl`:

```python
import json
from scripts.escalation_exposure_scorer import analyze
with open('references/config.json') as f:
    cfg = json.load(f)
# Pass loaded Mode A/B/C records in RAM without flooding context tokens
```

Using CLI fallback (`python3`):

```bash
python3 scripts/escalation_exposure_scorer.py --help
python3 scripts/verbatim_driver_quantifier.py --help
python3 scripts/decision_tree_validator.py --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [salesforce-crm-soql-traps.md](references/traps/salesforce-crm-soql-traps.md)
- [servicenow-jira-itsm-traps.md](references/traps/servicenow-jira-itsm-traps.md)
- [untrusted-content-and-pii.md](references/traps/untrusted-content-and-pii.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `salesforce_query_arr`, `servicenow_read_csm_cases`, `sheets_read_unformatted`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `docs_create_warroom_brief`, `docs_draft_kb_decision_tree`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `servicenow_trigger_exec_escalation` (scope: `explicit_per_call`) — Spinning up executive customer war-rooms or paging VP sponsors requires Support Director confirmation.
  - `kb_publish_troubleshooting_tree` (scope: `explicit_per_call`) — Publishing agent troubleshooting flows to production portals requires Knowledge Lead review.
