---
name: customer-operations-escalation
description: "Scores VIP account escalations by ARR exposure and Sev1 outages, mines CSAT/NPS verbatims into ARR-weighted driver paretos with null-rating hygiene, and validates support troubleshooting decision trees for graph defects. Use when routing or executing Customer Operations, VIP Escalation & Knowledge Quality workflows (critical-escalation-warroom, csat-churn-signal-miner, troubleshooting-tree-author). Don't use for unrelated domains outside customer-operations-escalation or automated external mutations without explicit user confirmation."
created_by: gemini-agent-plugins
---

# Customer Operations, VIP Escalation & Knowledge Quality (Department Bundle)

Scores VIP account escalations by ARR exposure and Sev1 outages, mines CSAT/NPS verbatims into ARR-weighted driver paretos with null-rating hygiene, and validates support troubleshooting decision trees for graph defects.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `critical-escalation-warroom` | `references/workflows/critical-escalation-warroom.md` | `scripts/escalation_exposure_scorer.py` | Scores VIP account escalations (0-100) from Sev1/Sev2 cases, SLA breaches, ARR, imminent renewals, outages, and competitor risk. |
| `csat-churn-signal-miner` | `references/workflows/csat-churn-signal-miner.md` | `scripts/verbatim_driver_quantifier.py` | Classifies survey verbatims into ARR-weighted friction drivers, excludes null scores from averages, and catches explicit churn intent. |
| `troubleshooting-tree-author` | `references/workflows/troubleshooting-tree-author.md` | `scripts/decision_tree_validator.py` | Validates customer support diagnostic trees via BFS/DFS for cycles, dead-end questions, orphan nodes, broken refs, and depth. |

## Step 1 — Fetch Data via Live `/work` Connectors or Attached Files

Probe enabled Gemini Enterprise connectors first before falling back to user-attached exports:

- **Built-in Managed 1P Connectors:** `Salesforce`, `ServiceNow`, `Google Docs`, `Google Sheets`, `Google Drive`, `Slack`.
- **Connector Tool Discovery:** Query enabled 1P/MCP servers via `remote_cli mcp <connector> list-tools` before calling Python engines.
- **Fetch Guidance:** Pull active customer account ARR/renewal windows from Salesforce and open CSM escalation cases, SLA timers, and CSAT verbatims from ServiceNow or Google Sheets via remote_cli mcp before scoring exposure in Python.
- **Connected Docs & Attached File Fallback:** Fetch Google Docs (`includeTabsContent=true`), Google Sheets (`UNFORMATTED_VALUE`), Shared Drives (`supportsAllDrives=true`), and SharePoint/OneDrive workbooks (`@odata.nextLink`), or read chat-attached `.xlsx`, `.docx`, `.csv`, `.tsv`, `.json`, and `.jsonl` snapshots via `view_file` and `scripts/enterprise_io.py`.

## Step 2 — Inspect & Shape Custom Customer Fields in `pyrepl`

Customer exports and live connector responses often use custom tab names or column headers. Check the matching workflow guide from the Workflow Router Matrix above for canonical keys and inspect the real source shape in `pyrepl` before computing:

- **Inspect Real Headers & Shape:** Read attached files via `scripts/enterprise_io.py` (`read_xlsx_workbook`, `read_docx`, `read_csv_tsv`, `read_json_or_jsonl`) or inspect connector JSON keys directly in `pyrepl` so you see actual tab names, headers, and sample rows first.
- **Normalize in Python (`payload`):** Shape messy customer headers or nested JSON objects in 5-10 lines of Python into a canonical `payload` dict and call `analyze(payload, config=cfg_path)` (pass file paths directly when headers already match canonical names). Call `ask_question` only when two source columns remain genuinely ambiguous.

## Step 3 — Run Deterministic Python Engine in `pyrepl` (or CLI)

1. Read `references/config.json` using `view_file` and check `org_configured`.
2. When `org_configured` is `false`, apply the bundled starter rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`
3. Resolve `SKILL_DIR` dynamically under `/workspace/skills/` so both `pyrepl` and shell CLI invocations work regardless of install root, and enforce every bundled baseline (`references/baselines/itsm-sla-severity-baseline.md`) and trap sheet (`references/traps/absent-is-not-zero.md`, `references/traps/salesforce-crm-soql-traps.md`, `references/traps/servicenow-jira-itsm-traps.md`, `references/traps/untrusted-content-and-pii.md`).

Bundled baseline rubrics:
- `references/baselines/itsm-sla-severity-baseline.md`

Bundled API and analytical trap guides:
- `references/traps/absent-is-not-zero.md`
- `references/traps/salesforce-crm-soql-traps.md`
- `references/traps/servicenow-jira-itsm-traps.md`
- `references/traps/untrusted-content-and-pii.md`

Using persistent `pyrepl`:

```python
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/customer-operations-escalation"),
            Path("skills/user-skills/customer-operations-escalation"),
            Path("skills/critical-escalation-warroom"),
            Path("skills/user-skills/critical-escalation-warroom"),
            Path("."),
        )
        if (p / "scripts/escalation_exposure_scorer.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/escalation_exposure_scorer.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.enterprise_io import read_xlsx_workbook, read_docx, read_csv_tsv, read_json_or_jsonl
from scripts.escalation_exposure_scorer import analyze, render_markdown

cfg_path = SKILL_DIR / "references" / "config.json"

# If headers differ from canonical names, inspect in Python first and normalize:
# wb = read_xlsx_workbook(Path("customer_export.xlsx"))
# print({tab: (list(rows[0].keys()) if rows else []) for tab, rows in wb.items()})
# payload = { ...shape customer columns into canonical keys... }
payload = source_path_or_dict
result = analyze(payload, config=cfg_path)
print(render_markdown(result))
```

CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/customer-operations-escalation skills/user-skills/customer-operations-escalation skills/*; do
  [ -f "$d/scripts/escalation_exposure_scorer.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/escalation_exposure_scorer.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/verbatim_driver_quantifier.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/decision_tree_validator.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/escalation_exposure_scorer.py" --help
python3 "$SKILL_DIR/scripts/verbatim_driver_quantifier.py" --help
python3 "$SKILL_DIR/scripts/decision_tree_validator.py" --help
```

## Step 4 — Write-Back Governance (`Auto-Guardian`) & Conversational Scheduling (`schedule_task`)

- **Read-Only & Local Draft Actions:** Connector reads via `remote_cli mcp`, file inspection via `view_file`, `pyrepl` scoring, interactive Canvas (`emit_a2ui`), and saving local deliverables via `write_to_file` run without mutating external systems.
- **Agent Gateway (`Auto-Guardian`) & Explicit User Confirmation:** External write-backs executed via authorized connectors are protected by Agent Gateway (`Auto-Guardian`) and require explicit user confirmation prior to execution:
  - Creating executive customer war-rooms or paging VP sponsors via ServiceNow or Slack
  - Publishing interactive troubleshooting decision trees to customer-facing portals
- **Code-Enforced Python Guardrails (`scripts/*.py`):**
  - Decision-tree DAG cycle, unreachable node, and broken transition reference blocker
  - Simpson's paradox separation preventing aggregate CSAT averages from hiding enterprise churn signals
  - Absent ARR/renewal date null preservation (never coercing unknown ARR to zero)
- **Conversational Scheduling (`schedule_task`):** Only when the user asks to automate recurring monitoring, invoke `schedule_task(title="Hourly VIP Escalation Radar", cron_expression="0 * * * *", time_zone="UTC", instruction="Run the hourly VIP escalation exposure check via scripts/escalation_exposure_scorer.py across open Sev1/Sev2 accounts and renewal windows.")`.
