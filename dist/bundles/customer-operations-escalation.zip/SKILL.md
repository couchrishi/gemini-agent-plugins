---
name: customer-operations-escalation
description: "Scores VIP account escalations by ARR exposure and Sev1 outages, mines CSAT/NPS verbatims into ARR-weighted driver paretos with null-rating hygiene, and validates support troubleshooting decision trees for graph defects. Use when routing or executing Customer Operations, VIP Escalation & Knowledge Quality workflows (critical-escalation-warroom, csat-churn-signal-miner, troubleshooting-tree-author). Don't use for unrelated domains outside customer-operations-escalation or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# Customer Operations, VIP Escalation & Knowledge Quality (Department Bundle)

Scores VIP account escalations by ARR exposure and Sev1 outages, mines CSAT/NPS verbatims into ARR-weighted driver paretos with null-rating hygiene, and validates support troubleshooting decision trees for graph defects.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `critical-escalation-warroom` | [critical-escalation-warroom.md](references/workflows/critical-escalation-warroom.md) | [escalation_exposure_scorer.py](scripts/escalation_exposure_scorer.py) | Scores VIP account escalations (0-100) from Sev1/Sev2 cases, SLA breaches, ARR, imminent renewals, outages, and competitor risk. |
| `csat-churn-signal-miner` | [csat-churn-signal-miner.md](references/workflows/csat-churn-signal-miner.md) | [verbatim_driver_quantifier.py](scripts/verbatim_driver_quantifier.py) | Classifies survey verbatims into ARR-weighted friction drivers, excludes null scores from averages, and catches explicit churn intent. |
| `troubleshooting-tree-author` | [troubleshooting-tree-author.md](references/workflows/troubleshooting-tree-author.md) | [decision_tree_validator.py](scripts/decision_tree_validator.py) | Validates customer support diagnostic trees via BFS/DFS for cycles, dead-end questions, orphan nodes, broken refs, and depth. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `crm_and_support_case_data` | salesforce_soql_api, servicenow_csm_api | Google Sheets, Google Docs, Google Drive (Read VIP Escalation Tracker Sheets, Quarterly Survey Exports, and Support Playbook Docs in CX Shared Drives.) | .json, .csv |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [itsm-sla-severity-baseline.md](references/baselines/itsm-sla-severity-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Because runtime shells start in `/workspace` while bundles and individual skills unpack under `skills/<slug>/` or `skills/user-skills/<slug>/`, always resolve `SKILL_DIR` dynamically before importing scripts or reading references.

Using persistent `pyrepl`:

```python
import json
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/customer-operations-escalation"),
            Path("skills/user-skills/customer-operations-escalation"),
            Path("skills/critical-escalation-warroom"),
            Path("skills/user-skills/critical-escalation-warroom"),
            Path("."),
        )
        if (p / "scripts/escalation_exposure_scorer.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/escalation_exposure_scorer.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.escalation_exposure_scorer import analyze, render_markdown

cfg = json.loads((SKILL_DIR / "references" / "config.json").read_text(encoding="utf-8"))
# Pass loaded Mode A/B/C payload in RAM without flooding prompt tokens:
# result = analyze(payload, config=SKILL_DIR / "references" / "config.json")
# print(render_markdown(result))
```

Using CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/customer-operations-escalation skills/user-skills/customer-operations-escalation skills/*; do
  [ -f "$d/scripts/escalation_exposure_scorer.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/escalation_exposure_scorer.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/verbatim_driver_quantifier.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/decision_tree_validator.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
# Or inspect CLI flags directly:
python3 "$SKILL_DIR/scripts/escalation_exposure_scorer.py" --help
python3 "$SKILL_DIR/scripts/verbatim_driver_quantifier.py" --help
python3 "$SKILL_DIR/scripts/decision_tree_validator.py" --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [salesforce-crm-soql-traps.md](references/traps/salesforce-crm-soql-traps.md)
- [servicenow-jira-itsm-traps.md](references/traps/servicenow-jira-itsm-traps.md)
- [untrusted-content-and-pii.md](references/traps/untrusted-content-and-pii.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `salesforce_query_arr`, `servicenow_read_csm_cases`, `sheets_read_unformatted`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `docs_create_warroom_brief`, `docs_draft_kb_decision_tree`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `servicenow_trigger_exec_escalation` (scope: `explicit_per_call`) — Spinning up executive customer war-rooms or paging VP sponsors requires Support Director confirmation.
  - `kb_publish_troubleshooting_tree` (scope: `explicit_per_call`) — Publishing agent troubleshooting flows to production portals requires Knowledge Lead review.
