---
name: conversational-bi-analyst
description: "Guards SQL generation against missing partition filters and join fanout explosions, computes exact Volume-Mix-Rate KPI bridges with z-score anomaly detection, and profiles datasets in RAM to emit verified A2UI chart payloads. Use when routing or executing Conversational BI & Variance Analyst workflows (schema-grounded-sql-analyst, kpi-anomaly-driver-tree, executive-data-story-pack). Don't use for unrelated domains outside conversational-bi-analyst or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# Conversational BI & Variance Analyst (Department Bundle)

Guards SQL generation against missing partition filters and join fanout explosions, computes exact Volume-Mix-Rate KPI bridges with z-score anomaly detection, and profiles datasets in RAM to emit verified A2UI chart payloads.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `schema-grounded-sql-analyst` | [schema-grounded-sql-analyst.md](references/workflows/schema-grounded-sql-analyst.md) | [sql_safety_and_fanout_checker.py](scripts/sql_safety_and_fanout_checker.py) | Inspects SQL queries and table metadata for missing partition filters, M:N join fanout risks, destructive DDL/DML, and denominator seams. |
| `kpi-anomaly-driver-tree` | [kpi-anomaly-driver-tree.md](references/workflows/kpi-anomaly-driver-tree.md) | [mix_rate_volume_bridge.py](scripts/mix_rate_volume_bridge.py) | Computes exact zero-residual Volume-Mix-Rate variance decomposition and segment z-score anomaly detection. |
| `executive-data-story-pack` | [executive-data-story-pack.md](references/workflows/executive-data-story-pack.md) | [dataset_profiler_guard.py](scripts/dataset_profiler_guard.py) | Profiles tabular datasets in RAM for completeness, null rates, quantiles, outliers, truncation ceilings, and A2UI Canvas payloads. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `analytical_warehouse_query` | bigquery_api, snowflake_sql_api, looker_api | Google Sheets, Google Drive (Read Connected Sheets exports or KPI Extracts stored in BI & Finance Shared Drives.) | .json, .csv, .sql |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [finance-materiality-baseline.md](references/baselines/finance-materiality-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Because runtime shells start in `/workspace` while bundles and individual skills unpack under `skills/<slug>/` or `skills/user-skills/<slug>/`, always resolve `SKILL_DIR` dynamically before importing scripts or reading references.

- **Zero-dependency enterprise ingestion:** Every engine uses [enterprise_io.py](scripts/enterprise_io.py) to parse multi-tab `.xlsx`/`.xlsm` workbooks (1900/1904 dates, inline/shared strings, formula cached values), `.docx` documents (sections, headings, embedded tables, footnotes/comments), UTF-8 BOM `.csv`/`.tsv`, `.json`, and `.jsonl` directly from `--input` without needing `openpyxl` or `python-docx`. Pass `--sheet <TabNameOrIndex>` (or `sheet='...'` in `analyze()`) to analyze a specific worksheet by tab name or 0-based index.

Using persistent `pyrepl`:

```python
import json
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/conversational-bi-analyst"),
            Path("skills/user-skills/conversational-bi-analyst"),
            Path("skills/schema-grounded-sql-analyst"),
            Path("skills/user-skills/schema-grounded-sql-analyst"),
            Path("."),
        )
        if (p / "scripts/sql_safety_and_fanout_checker.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/sql_safety_and_fanout_checker.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.sql_safety_and_fanout_checker import analyze, render_markdown

cfg = json.loads((SKILL_DIR / "references" / "config.json").read_text(encoding="utf-8"))
# Pass loaded Mode A/B/C payload in RAM without flooding prompt tokens:
# result = analyze(payload, config=SKILL_DIR / "references" / "config.json")
# print(render_markdown(result))
```

Using CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/conversational-bi-analyst skills/user-skills/conversational-bi-analyst skills/*; do
  [ -f "$d/scripts/sql_safety_and_fanout_checker.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/sql_safety_and_fanout_checker.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/mix_rate_volume_bridge.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/dataset_profiler_guard.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
# Or pass .xlsx / .docx / .csv directly (optional --sheet "TabName" or --sheet 0):
# python3 "$SKILL_DIR/scripts/sql_safety_and_fanout_checker.py" --input workbook.xlsx --config "$SKILL_DIR/references/config.json" --format markdown
# Inspect CLI flags directly:
python3 "$SKILL_DIR/scripts/sql_safety_and_fanout_checker.py" --help
python3 "$SKILL_DIR/scripts/mix_rate_volume_bridge.py" --help
python3 "$SKILL_DIR/scripts/dataset_profiler_guard.py" --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [bigquery-sap-erp-traps.md](references/traps/bigquery-sap-erp-traps.md)
- [chain-denominator-seams.md](references/traps/chain-denominator-seams.md)
- [google-workspace-traps.md](references/traps/google-workspace-traps.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `bigquery_dry_run_and_select`, `looker_run_explore`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `emit_a2ui`, `docs_create_private_brief`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `bigquery_execute_expensive_or_dml` (scope: `explicit_per_call`) — Running DDL/DML or high-scan unpartitioned warehouse queries requires explicit user approval.
  - `slides_or_email_share_executive_pack` (scope: `task_sticky`) — Distributing executive BI packs externally or to leadership aliases requires confirmation.
