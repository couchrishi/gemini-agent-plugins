---
name: conversational-bi-analyst
description: "Guards SQL generation against missing partition filters and join fanout explosions, computes exact Volume-Mix-Rate KPI bridges with z-score anomaly detection, and profiles datasets in RAM to emit verified A2UI chart payloads. Use when routing or executing Conversational BI & Variance Analyst workflows (schema-grounded-sql-analyst, kpi-anomaly-driver-tree, executive-data-story-pack). Don't use for unrelated domains outside conversational-bi-analyst or automated external mutations without explicit user confirmation."
created_by: gemini-agent-plugins
---

# Conversational BI & Variance Analyst (Department Bundle)

Guards SQL generation against missing partition filters and join fanout explosions, computes exact Volume-Mix-Rate KPI bridges with z-score anomaly detection, and profiles datasets in RAM to emit verified A2UI chart payloads.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `schema-grounded-sql-analyst` | `references/workflows/schema-grounded-sql-analyst.md` | `scripts/sql_safety_and_fanout_checker.py` | Inspects SQL queries and table metadata for missing partition filters, M:N join fanout risks, destructive DDL/DML, and denominator seams. |
| `kpi-anomaly-driver-tree` | `references/workflows/kpi-anomaly-driver-tree.md` | `scripts/mix_rate_volume_bridge.py` | Computes exact zero-residual Volume-Mix-Rate variance decomposition and segment z-score anomaly detection. |
| `executive-data-story-pack` | `references/workflows/executive-data-story-pack.md` | `scripts/dataset_profiler_guard.py` | Profiles tabular datasets in RAM for completeness, null rates, quantiles, outliers, truncation ceilings, and A2UI Canvas payloads. |

## Step 1 — Fetch Data via Live `/work` Connectors or Attached Files

Probe enabled Gemini Enterprise connectors first before falling back to user-attached exports:

- **Built-in Managed 1P Connectors:** `BigQuery`, `Snowflake`, `Postgres`, `Google Sheets`, `Google Drive`, `Google Slides`.
- **Optional Customer BYO-MCP Servers:** `Semantic BI Layer / Looker MCP server` (discover exposed tools via `remote_cli mcp <connector> list-tools`).
- **Fetch Guidance:** Fetch dataset metadata, INFORMATION_SCHEMA definitions, dry-run byte estimates, and KPI extract tables from BigQuery, Snowflake, Postgres, or Google Sheets via remote_cli mcp before running Python fanout and mix/rate/volume checks.
- **Connected Docs & Attached File Fallback:** Fetch Google Docs (`includeTabsContent=true`), Google Sheets (`UNFORMATTED_VALUE`), Shared Drives (`supportsAllDrives=true`), and SharePoint/OneDrive workbooks (`@odata.nextLink`), or read chat-attached `.xlsx`, `.docx`, `.csv`, `.tsv`, `.json`, and `.jsonl` snapshots via `view_file` and `scripts/enterprise_io.py`.

## Step 2 — Inspect & Shape Custom Customer Fields in `pyrepl`

Customer exports and live connector responses often use custom tab names or column headers. Check the matching workflow guide from the Workflow Router Matrix above for canonical keys and inspect the real source shape in `pyrepl` before computing:

- **Inspect Real Headers & Shape:** Read attached files via `scripts/enterprise_io.py` (`read_xlsx_workbook`, `read_docx`, `read_csv_tsv`, `read_json_or_jsonl`) or inspect connector JSON keys directly in `pyrepl` so you see actual tab names, headers, and sample rows first.
- **Normalize in Python (`payload`):** Shape messy customer headers or nested JSON objects in 5-10 lines of Python into a canonical `payload` dict and call `analyze(payload, config=cfg_path)` (pass file paths directly when headers already match canonical names). Call `ask_question` only when two source columns remain genuinely ambiguous.

## Step 3 — Run Deterministic Python Engine in `pyrepl` (or CLI)

1. Read `references/config.json` using `view_file` and check `org_configured`.
2. When `org_configured` is `false`, apply the bundled starter rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`
3. Resolve `SKILL_DIR` dynamically under `/workspace/skills/` so both `pyrepl` and shell CLI invocations work regardless of install root, and enforce every bundled baseline (`references/baselines/finance-materiality-baseline.md`) and trap sheet (`references/traps/absent-is-not-zero.md`, `references/traps/bigquery-sap-erp-traps.md`, `references/traps/chain-denominator-seams.md`, `references/traps/google-workspace-traps.md`).

Bundled baseline rubrics:
- `references/baselines/finance-materiality-baseline.md`

Bundled API and analytical trap guides:
- `references/traps/absent-is-not-zero.md`
- `references/traps/bigquery-sap-erp-traps.md`
- `references/traps/chain-denominator-seams.md`
- `references/traps/google-workspace-traps.md`

Using persistent `pyrepl`:

```python
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/conversational-bi-analyst"),
            Path("skills/user-skills/conversational-bi-analyst"),
            Path("skills/schema-grounded-sql-analyst"),
            Path("skills/user-skills/schema-grounded-sql-analyst"),
            Path("."),
        )
        if (p / "scripts/sql_safety_and_fanout_checker.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/sql_safety_and_fanout_checker.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.enterprise_io import read_xlsx_workbook, read_docx, read_csv_tsv, read_json_or_jsonl
from scripts.sql_safety_and_fanout_checker import analyze, render_markdown

cfg_path = SKILL_DIR / "references" / "config.json"

# If headers differ from canonical names, inspect in Python first and normalize:
# wb = read_xlsx_workbook(Path("customer_export.xlsx"))
# print({tab: (list(rows[0].keys()) if rows else []) for tab, rows in wb.items()})
# payload = { ...shape customer columns into canonical keys... }
payload = source_path_or_dict
result = analyze(payload, config=cfg_path)
print(render_markdown(result))
```

CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/conversational-bi-analyst skills/user-skills/conversational-bi-analyst skills/*; do
  [ -f "$d/scripts/sql_safety_and_fanout_checker.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/sql_safety_and_fanout_checker.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/mix_rate_volume_bridge.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/dataset_profiler_guard.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/sql_safety_and_fanout_checker.py" --help
python3 "$SKILL_DIR/scripts/mix_rate_volume_bridge.py" --help
python3 "$SKILL_DIR/scripts/dataset_profiler_guard.py" --help
```

## Step 4 — Write-Back Governance (`Auto-Guardian`) & Conversational Scheduling (`schedule_task`)

- **Read-Only & Local Draft Actions:** Connector reads via `remote_cli mcp`, file inspection via `view_file`, `pyrepl` scoring, interactive Canvas (`emit_a2ui`), and saving local deliverables via `write_to_file` run without mutating external systems.
- **Agent Gateway (`Auto-Guardian`) & Explicit User Confirmation:** External write-backs executed via authorized connectors are protected by Agent Gateway (`Auto-Guardian`) and require explicit user confirmation prior to execution:
  - Executing DDL/DML statements or unpartitioned warehouse queries exceeding max_query_scan_gb
  - Sharing executive KPI briefings or Slides decks to external leadership distribution lists
- **Code-Enforced Python Guardrails (`scripts/*.py`):**
  - SQL AST DDL/DML block, missing partition filter flag, and 1:N join fanout double-count guard
  - Volume + Mix + Rate additive bridge identity check with min_sample_size_guard warnings
  - Strict BigQuery/Sheets UNFORMATTED_VALUE coercion without string display rounding
- **Conversational Scheduling (`schedule_task`):** Only when the user asks to automate recurring monitoring, invoke `schedule_task(title="Daily KPI Anomaly Digest", cron_expression="0 7 * * 1-5", time_zone="UTC", instruction="Run the daily KPI variance and z-score anomaly check using scripts/mix_rate_volume_bridge.py. Decompose revenue/margin changes into exact Volume, Mix, and Rate effects, flag segments exceeding zscore_anomaly_threshold, and save an internal Canvas digest without emailing distribution lists.")`.
