---
name: conversational-bi-analyst
description: "Guards SQL generation against missing partition filters and join fanout explosions, computes exact Volume-Mix-Rate KPI bridges with z-score anomaly detection, and profiles datasets in RAM to emit verified A2UI chart payloads. Use when routing or executing Conversational BI & Variance Analyst workflows (schema-grounded-sql-analyst, kpi-anomaly-driver-tree, executive-data-story-pack). Don't use for unrelated domains outside conversational-bi-analyst or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# Conversational BI & Variance Analyst (Department Bundle)

Guards SQL generation against missing partition filters and join fanout explosions, computes exact Volume-Mix-Rate KPI bridges with z-score anomaly detection, and profiles datasets in RAM to emit verified A2UI chart payloads.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `schema-grounded-sql-analyst` | [schema-grounded-sql-analyst.md](references/workflows/schema-grounded-sql-analyst.md) | [sql_safety_and_fanout_checker.py](scripts/sql_safety_and_fanout_checker.py) | Inspects SQL queries and table metadata for missing partition filters, M:N join fanout risks, destructive DDL/DML, and denominator seams. |
| `kpi-anomaly-driver-tree` | [kpi-anomaly-driver-tree.md](references/workflows/kpi-anomaly-driver-tree.md) | [mix_rate_volume_bridge.py](scripts/mix_rate_volume_bridge.py) | Computes exact zero-residual Volume-Mix-Rate variance decomposition and segment z-score anomaly detection. |
| `executive-data-story-pack` | [executive-data-story-pack.md](references/workflows/executive-data-story-pack.md) | [dataset_profiler_guard.py](scripts/dataset_profiler_guard.py) | Profiles tabular datasets in RAM for completeness, null rates, quantiles, outliers, truncation ceilings, and A2UI Canvas payloads. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `analytical_warehouse_query` | bigquery_api, snowflake_sql_api, looker_api | Google Sheets, Google Drive (Read Connected Sheets exports or KPI Extracts stored in BI & Finance Shared Drives.) | .json, .csv, .sql |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [finance-materiality-baseline.md](references/baselines/finance-materiality-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Inspect outputs and optionally visualize metrics with `emit_a2ui` or automate via `schedule_task`.

Using persistent `pyrepl`:

```python
import json
from scripts.sql_safety_and_fanout_checker import analyze
with open('references/config.json') as f:
    cfg = json.load(f)
# Pass loaded Mode A/B/C records in RAM without flooding context tokens
```

Using CLI fallback (`python3`):

```bash
python3 scripts/sql_safety_and_fanout_checker.py --help
python3 scripts/mix_rate_volume_bridge.py --help
python3 scripts/dataset_profiler_guard.py --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [bigquery-sap-erp-traps.md](references/traps/bigquery-sap-erp-traps.md)
- [chain-denominator-seams.md](references/traps/chain-denominator-seams.md)
- [google-workspace-traps.md](references/traps/google-workspace-traps.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `bigquery_dry_run_and_select`, `looker_run_explore`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `emit_a2ui`, `docs_create_private_brief`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `bigquery_execute_expensive_or_dml` (scope: `explicit_per_call`) — Running DDL/DML or high-scan unpartitioned warehouse queries requires explicit user approval.
  - `slides_or_email_share_executive_pack` (scope: `task_sticky`) — Distributing executive BI packs externally or to leadership aliases requires confirmation.
