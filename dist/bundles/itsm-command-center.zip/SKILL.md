---
name: itsm-command-center
description: "Accelerates incident triage with business-elapsed SLA breach tracking and spike clustering, scores CAB change requests against freeze windows and blast radius, and mines resolved tickets for Problem candidates and KCS deflection savings. Use when routing or executing ITSM & Service Desk Command Center workflows (incident-triage-routing, change-risk-cab-review, problem-rca-kb-generator). Don't use for unrelated domains outside itsm-command-center or automated external mutations without HITL confirmation."
created_by: gemini-agent-plugins
---

# ITSM & Service Desk Command Center (Department Bundle)

Accelerates incident triage with business-elapsed SLA breach tracking and spike clustering, scores CAB change requests against freeze windows and blast radius, and mines resolved tickets for Problem candidates and KCS deflection savings.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `incident-triage-routing` | [incident-triage-routing.md](references/workflows/incident-triage-routing.md) | [sla_cluster_triage.py](scripts/sla_cluster_triage.py) | Computes business-elapsed vs wall-clock SLA risk, clusters correlated incident spikes by CI and error signature, and ranks matching runbooks. |
| `change-risk-cab-review` | [change-risk-cab-review.md](references/workflows/change-risk-cab-review.md) | [cab_risk_scorer.py](scripts/cab_risk_scorer.py) | Scores ServiceNow and Jira change requests across blast radius, freeze-window collisions, rollback validation, CI failure history, and CAB tier. |
| `problem-rca-kb-generator` | [problem-rca-kb-generator.md](references/workflows/problem-rca-kb-generator.md) | [kcs_deflection_analyzer.py](scripts/kcs_deflection_analyzer.py) | Groups repeat resolved tickets into Problem candidates, calculates MTTR and annualized L1 deflection savings, and validates KCS draft completeness. |

## Three-Mode Connector Graceful Degradation

Inspect available tools first and degrade cleanly without failing when enterprise connectors are absent:

| Capability | Mode A — Live Enterprise Connectors | Mode B — Google Workspace Fallback | Mode C — Direct Local File Upload |
| :--- | :--- | :--- | :--- |
| `itsm_ticketing_and_cmdb` | servicenow_table_api, jira_service_management_api | Google Sheets, Google Drive, Google Docs (Locate exported ServiceNow/Jira Incident, Change, and CMDB Sheets in IT Ops Shared Drives.) | .json, .csv |
| `runbook_and_kcs_kb` | atlassian_confluence_cloud | Google Docs, Google Drive (Read Runbook Docs inside the SRE & Service Desk Shared Drive.) | .json, .md, .csv |

## Org Configuration & Starter Baseline Rule

1. Read [config.json](references/config.json) using `view_file` (or check a user-supplied organization playbook file).
2. Check the boolean flag `org_configured`.
3. When `org_configured` is `false`, evaluate strictly against the bundled starter baseline rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`

Bundled baseline rubrics:
- [itsm-sla-severity-baseline.md](references/baselines/itsm-sla-severity-baseline.md)

## In-Memory Python RAM Execution Pattern

Always run deterministic calculations in Python RAM rather than estimating tables or totals in prompt tokens. Because runtime shells start in `/workspace` while bundles and individual skills unpack under `skills/<slug>/` or `skills/user-skills/<slug>/`, always resolve `SKILL_DIR` dynamically before importing scripts or reading references.

Using persistent `pyrepl`:

```python
import json
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/itsm-command-center"),
            Path("skills/user-skills/itsm-command-center"),
            Path("skills/incident-triage-routing"),
            Path("skills/user-skills/incident-triage-routing"),
            Path("."),
        )
        if (p / "scripts/sla_cluster_triage.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/sla_cluster_triage.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.sla_cluster_triage import analyze, render_markdown

cfg = json.loads((SKILL_DIR / "references" / "config.json").read_text(encoding="utf-8"))
# Pass loaded Mode A/B/C payload in RAM without flooding prompt tokens:
# result = analyze(payload, config=SKILL_DIR / "references" / "config.json")
# print(render_markdown(result))
```

Using CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/itsm-command-center skills/user-skills/itsm-command-center skills/*; do
  [ -f "$d/scripts/sla_cluster_triage.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/sla_cluster_triage.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/cab_risk_scorer.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/kcs_deflection_analyzer.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
# Or inspect CLI flags directly:
python3 "$SKILL_DIR/scripts/sla_cluster_triage.py" --help
python3 "$SKILL_DIR/scripts/cab_risk_scorer.py" --help
python3 "$SKILL_DIR/scripts/kcs_deflection_analyzer.py" --help
```

## Enterprise API & Analytical Traps

Apply every bundled trap sheet before interpreting missing records, API page limits, currency scales, or untrusted external text:

- [absent-is-not-zero.md](references/traps/absent-is-not-zero.md)
- [servicenow-jira-itsm-traps.md](references/traps/servicenow-jira-itsm-traps.md)
- [untrusted-content-and-pii.md](references/traps/untrusted-content-and-pii.md)

## HITL Mutation & Policy Guardrails

- **Read-only operations (auto-run):** `servicenow_query_incidents`, `servicenow_query_changes`, `servicenow_query_cmdb`, `jira_jql_search`, `view_file`, `pyrepl`
- **Draft-only operations (auto-run):** `servicenow_create_kcs_draft`, `docs_create_private_brief`, `write_to_file`
- **HITL-gated external mutations (require explicit user confirmation):**
  - `servicenow_update_incident_or_assign` (scope: `explicit_per_call`) — Reassigning P1/P2 incidents or updating tickets in bulk requires explicit engineer confirmation.
  - `servicenow_approve_or_reject_change` (scope: `explicit_per_call`) — Approving or rejecting CAB change requests requires human CAB authority sign-off.
  - `servicenow_publish_kcs_article` (scope: `task_sticky`) — Publishing KCS knowledge articles externally requires explicit approval.
