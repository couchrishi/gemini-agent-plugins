---
name: itsm-command-center
description: "Accelerates incident triage with business-elapsed SLA breach tracking and spike clustering, scores CAB change requests against freeze windows and blast radius, and mines resolved tickets for Problem candidates and KCS deflection savings. Use when routing or executing ITSM & Service Desk Command Center workflows (incident-triage-routing, change-risk-cab-review, problem-rca-kb-generator). Don't use for unrelated domains outside itsm-command-center or automated external mutations without explicit user confirmation."
created_by: gemini-agent-plugins
---

# ITSM & Service Desk Command Center (Department Bundle)

Accelerates incident triage with business-elapsed SLA breach tracking and spike clustering, scores CAB change requests against freeze windows and blast radius, and mines resolved tickets for Problem candidates and KCS deflection savings.

## Workflow Router Matrix

Select the workflow guide and Python engine matching the user's request:

| Skill ID | Workflow Guide | Deterministic Engine | Purpose |
| :--- | :--- | :--- | :--- |
| `incident-triage-routing` | `references/workflows/incident-triage-routing.md` | `scripts/sla_cluster_triage.py` | Computes business-elapsed vs wall-clock SLA risk, clusters correlated incident spikes by CI and error signature, and ranks matching runbooks. |
| `change-risk-cab-review` | `references/workflows/change-risk-cab-review.md` | `scripts/cab_risk_scorer.py` | Scores ServiceNow and Jira change requests across blast radius, freeze-window collisions, rollback validation, CI failure history, and CAB tier. |
| `problem-rca-kb-generator` | `references/workflows/problem-rca-kb-generator.md` | `scripts/kcs_deflection_analyzer.py` | Groups repeat resolved tickets into Problem candidates, calculates MTTR and annualized L1 deflection savings, and validates KCS draft completeness. |

## Step 1 — Fetch Data via Live `/work` Connectors or Attached Files

Probe enabled Gemini Enterprise connectors first before falling back to user-attached exports:

- **Built-in Managed 1P Connectors:** `ServiceNow`, `Jira`, `Confluence`, `Google Drive`, `Google Sheets`, `Google Docs`, `Slack`.
- **Connector Tool Discovery:** Query enabled 1P/MCP servers via `remote_cli mcp <connector> list-tools` before calling Python engines.
- **Fetch Guidance:** Query active ServiceNow incidents (sysparm_display_value=all), CAB changes, and CMDB CIs, Jira issues, and Confluence KCS runbooks via remote_cli mcp (capped to targeted batch lookups) before Python SLA clustering and CAB scoring.
- **Connected Docs & Attached File Fallback:** Fetch Google Docs (`includeTabsContent=true`), Google Sheets (`UNFORMATTED_VALUE`), Shared Drives (`supportsAllDrives=true`), and SharePoint/OneDrive workbooks (`@odata.nextLink`), or read chat-attached `.xlsx`, `.docx`, `.csv`, `.tsv`, `.json`, and `.jsonl` snapshots via `view_file` and `scripts/enterprise_io.py`.
- **Single-Pass Multi-Surface Execution Budget:** Batch all workbook tab reads via `scripts/enterprise_io.py` and execute all ITSM scoring engines in a single `pyrepl` pass while capping external ServiceNow, Jira, Calendar, and Confluence lookups to at most 3 targeted queries so 6-tab workbooks and ITSM/KB cross-joins complete within turn timeouts.

## Step 2 — Inspect & Shape Custom Customer Fields in `pyrepl`

Customer exports and live connector responses often use custom tab names or column headers. Check the matching workflow guide from the Workflow Router Matrix above for canonical keys and inspect the real source shape in `pyrepl` before computing:

- **Inspect Real Headers & Shape:** Read attached files via `scripts/enterprise_io.py` (`read_xlsx_workbook`, `read_docx`, `read_csv_tsv`, `read_json_or_jsonl`) or inspect connector JSON keys directly in `pyrepl` so you see actual tab names, headers, and sample rows first.
- **Normalize in Python (`payload`):** Shape messy customer headers or nested JSON objects in 5-10 lines of Python into a canonical `payload` dict and call `analyze(payload, config=cfg_path)` (pass file paths directly when headers already match canonical names). Call `ask_question` only when two source columns remain genuinely ambiguous.

## Step 3 — Run Deterministic Python Engine in `pyrepl` (or CLI)

1. Read `references/config.json` using `view_file` and check `org_configured`.
2. When `org_configured` is `false`, apply the bundled starter rubrics and stamp the top of every deliverable verbatim with:
   `[EVALUATED AGAINST STANDARD BASELINE — BIND ORG CONFIG TO CUSTOMIZE]`
3. Resolve `SKILL_DIR` dynamically under `/workspace/skills/` so both `pyrepl` and shell CLI invocations work regardless of install root, and enforce every bundled baseline (`references/baselines/itsm-sla-severity-baseline.md`) and trap sheet (`references/traps/absent-is-not-zero.md`, `references/traps/servicenow-jira-itsm-traps.md`, `references/traps/untrusted-content-and-pii.md`).

Bundled baseline rubrics:
- `references/baselines/itsm-sla-severity-baseline.md`

Bundled API and analytical trap guides:
- `references/traps/absent-is-not-zero.md`
- `references/traps/servicenow-jira-itsm-traps.md`
- `references/traps/untrusted-content-and-pii.md`

Using persistent `pyrepl`:

```python
import sys
from pathlib import Path

SKILL_DIR = next(
    (
        p
        for p in (
            Path("skills/itsm-command-center"),
            Path("skills/user-skills/itsm-command-center"),
            Path("skills/incident-triage-routing"),
            Path("skills/user-skills/incident-triage-routing"),
            Path("."),
        )
        if (p / "scripts/sla_cluster_triage.py").is_file()
    ),
    next((p.parent.parent for p in Path("skills").rglob("scripts/sla_cluster_triage.py")), Path(".")),
)
sys.modules.pop("scripts", None)
sys.path.insert(0, str(SKILL_DIR))
from scripts.enterprise_io import read_xlsx_workbook, read_docx, read_csv_tsv, read_json_or_jsonl
from scripts.sla_cluster_triage import analyze, render_markdown

cfg_path = SKILL_DIR / "references" / "config.json"

# If headers differ from canonical names, inspect in Python first and normalize:
# wb = read_xlsx_workbook(Path("customer_export.xlsx"))
# print({tab: (list(rows[0].keys()) if rows else []) for tab, rows in wb.items()})
# payload = { ...shape customer columns into canonical keys... }
payload = source_path_or_dict
result = analyze(payload, config=cfg_path)
print(render_markdown(result))
```

CLI fallback (`python3` from `/workspace` or bundle root):

```bash
SKILL_DIR="."
for d in skills/itsm-command-center skills/user-skills/itsm-command-center skills/*; do
  [ -f "$d/scripts/sla_cluster_triage.py" ] && SKILL_DIR="$d" && break
done
python3 "$SKILL_DIR/scripts/sla_cluster_triage.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/cab_risk_scorer.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/kcs_deflection_analyzer.py" --input payload.json --config "$SKILL_DIR/references/config.json" --format markdown
python3 "$SKILL_DIR/scripts/sla_cluster_triage.py" --help
python3 "$SKILL_DIR/scripts/cab_risk_scorer.py" --help
python3 "$SKILL_DIR/scripts/kcs_deflection_analyzer.py" --help
```

## Step 4 — Write-Back Governance (`Auto-Guardian`) & Conversational Scheduling (`schedule_task`)

- **Read-Only & Local Draft Actions:** Connector reads via `remote_cli mcp`, file inspection via `view_file`, `pyrepl` scoring, interactive Canvas (`emit_a2ui`), and saving local deliverables via `write_to_file` run without mutating external systems.
- **Agent Gateway (`Auto-Guardian`) & Explicit User Confirmation:** External write-backs executed via authorized connectors are protected by Agent Gateway (`Auto-Guardian`) and require explicit user confirmation prior to execution:
  - Reassigning P1/P2 incidents or updating ServiceNow/Jira tickets in bulk
  - Approving or rejecting CAB change requests in ServiceNow
  - Publishing KCS knowledge articles to external service portals in Confluence or ServiceNow
- **Code-Enforced Python Guardrails (`scripts/*.py`):**
  - ServiceNow state=8 canceled exclusion and business_elapsed_minutes vs wall-clock SLA enforcement
  - CAB freeze-window collision, missing backout-plan verification, and blast-radius risk scoring
  - Single-pass multi-tab workbook and capped <=3 ITSM/KB search execution discipline
- **Conversational Scheduling (`schedule_task`):** Only when the user asks to automate recurring monitoring, invoke `schedule_task(title="Hourly SLA Breach Watch", cron_expression="0 * * * *", time_zone="UTC", instruction="Execute hourly incident triage and SLA breach scan via scripts/sla_cluster_triage.py. Highlight active P1/P2 tickets above 75% business-elapsed SLA budget, flag emerging CI/error spike clusters, and recommend top matching runbooks without mutating ticket assignments automatically.")`.
